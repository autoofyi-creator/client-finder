"""Database engine/session handling. PostgreSQL (Supabase) in production; SQLite only for local dev/tests."""
from __future__ import annotations

from contextlib import contextmanager

from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import NullPool

from config import env, is_vercel
from models.orm import Base

_engine: Engine | None = None
_Session: sessionmaker | None = None
_schema_ready = False


class DatabaseNotConfigured(RuntimeError):
    pass


def database_url() -> str | None:
    url = env("DATABASE_URL")
    if not url:
        if env("ALLOW_LOCAL_SQLITE") == "1" and not is_vercel():
            return "sqlite:///./local_dev.db"
        return None
    if url.startswith("postgres://"):
        url = "postgresql+psycopg://" + url[len("postgres://"):]
    elif url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url[len("postgresql://"):]
    if url.startswith("sqlite") and is_vercel():
        raise DatabaseNotConfigured("SQLite is not allowed on Vercel (no persistent disk). Use Supabase PostgreSQL.")
    return url


def reset_engine() -> None:
    global _engine, _Session, _schema_ready
    if _engine is not None:
        _engine.dispose()
    _engine = _Session = None
    _schema_ready = False


def get_engine() -> Engine:
    global _engine, _Session
    if _engine is None:
        url = database_url()
        if not url:
            raise DatabaseNotConfigured("DATABASE_URL is not set.")
        if url.startswith("sqlite"):
            _engine = create_engine(url, connect_args={"check_same_thread": False})
        else:
            kwargs = dict(pool_pre_ping=True, connect_args={"prepare_threshold": None})  # pgbouncer/Supavisor safe
            if is_vercel():
                kwargs["poolclass"] = NullPool
            else:
                kwargs.update(pool_size=3, max_overflow=2)
            _engine = create_engine(url, **kwargs)
        _Session = sessionmaker(bind=_engine, expire_on_commit=False, autoflush=True)
    return _engine


def ensure_schema() -> None:
    global _schema_ready
    if not _schema_ready:
        Base.metadata.create_all(get_engine())
        _schema_ready = True


def new_session() -> Session:
    get_engine()
    ensure_schema()
    assert _Session is not None
    return _Session()


@contextmanager
def session_scope():
    s = new_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def get_db():
    """FastAPI dependency."""
    try:
        s = new_session()
    except DatabaseNotConfigured as e:
        raise HTTPException(503, f"NEEDS CONFIGURATION: {e}")
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()
