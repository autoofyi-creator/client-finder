"""Reply Analysis Agent: syncs Gmail, keeps ONLY replies that match our outreach, classifies them, applies suppression rules."""
from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import AgentResult
from integrations import anthropic_client as llm
from integrations import gmail
from integrations.base import IntegrationError, NotConfigured
from models.orm import Contact, Lead, Message, Reply
from services import settings_store as ss
from services.email_checks import extract_emails
from services.suppression import suppress

Cls = Literal["interested", "question", "not_interested", "unsubscribe", "bounce", "out_of_office", "other"]


class ReplyClass(BaseModel):
    classification: Cls
    summary: str = ""


RULES = [
    ("bounce", r"mailer-daemon|postmaster|delivery status notification|undeliverable|returned mail|delivery has failed|failure notice"),
    ("out_of_office", r"out of (the )?office|automatic reply|auto-?reply|on (annual )?leave|on vacation"),
    ("unsubscribe", r"\b(unsubscribe|remove me|stop (emailing|contacting|sending)|do not (contact|email)|take me off|opt.?out)\b"),
    ("not_interested", r"not interested|no thanks|no thank you|not looking|we(?:'|’)re all set|already (have|work)|not at this time|not a good fit|\bpass\b"),
    ("interested", r"interested|sounds good|let(?:'|’)s (talk|chat|schedule|connect)|send (me )?(more|details|pricing|examples)|how much|available|book a|happy to (chat|talk)|yes,? please"),
]


def classify_heuristic(sender: str, subject: str, text: str) -> ReplyClass:
    blob = f"{sender} {subject} {text}".lower()
    for label, pat in RULES:
        if re.search(pat, blob):
            return ReplyClass(classification=label, summary="Keyword rule match (no AI judgement)")
    return ReplyClass(classification="question" if "?" in text else "other", summary="No rule matched; review manually")


def classify(sender: str, subject: str, text: str) -> tuple[ReplyClass, str]:
    h = classify_heuristic(sender, subject, text)
    if h.classification in ("bounce", "unsubscribe"):
        return h, "heuristic"  # safety-critical: deterministic rules win
    try:
        return llm.complete_json("Classify this reply to a cold email. classification one of: interested, question, not_interested, unsubscribe, bounce, out_of_office, other. "
                                 'JSON: {"classification","summary"}.', llm.wrap("reply", f"From: {sender}\nSubject: {subject}\n{text}", 2000), ReplyClass, 300), "claude"
    except (NotConfigured, IntegrationError):
        return h, "heuristic"


def apply_effects(db: Session, reply: Reply, lead: Lead | None, contact_email: str | None) -> None:
    c = reply.classification
    if c == "unsubscribe" and contact_email:
        suppress(db, email=contact_email, reason="unsubscribed")
        if lead:
            lead.status = "suppressed"
    elif c == "bounce" and contact_email:
        suppress(db, email=contact_email, reason="bounce")
        for ct in db.execute(select(Contact).where(Contact.email == contact_email)).scalars():
            ct.email_status = "INVALID"
    elif lead and c in ("interested", "question"):
        lead.status = "interested" if c == "interested" else "replied"
    elif lead and c == "not_interested":
        lead.status = "lost"
    elif lead and c == "other" and lead.status in ("contacted",):
        lead.status = "replied"


def process(db: Session, items: list[dict], own_address: str | None) -> dict:
    new = 0
    sent = db.execute(select(Message).where(Message.channel == "email", Message.status == "sent")).scalars().all()
    by_thread = {m.thread_id: m for m in sent if m.thread_id}
    by_addr = {(m.to_email or "").lower(): m for m in sent}
    known = {r for (r,) in db.execute(select(Reply.gmail_message_id))}
    for it in items:
        if it["id"] in known or (own_address and it["from"] == own_address.lower()):
            continue
        is_bounce = classify_heuristic(it["from"], it["subject"], "").classification == "bounce"
        msg, addr = by_thread.get(it["thread_id"]), None
        if is_bounce:
            for e in extract_emails(it["snippet"]):
                if e in by_addr:
                    msg, addr = by_addr[e], e
                    break
        elif msg is None:
            msg = by_addr.get(it["from"])
        if msg is None:
            continue  # unrelated mail: never stored
        addr = addr or msg.to_email
        cls, method = classify(it["from"], it["subject"], it["snippet"])
        lead = db.get(Lead, msg.lead_id)
        r = Reply(lead_id=msg.lead_id, message_id=msg.id, gmail_message_id=it["id"], thread_id=it["thread_id"], from_email=it["from"],
                  subject=it["subject"][:480], snippet=it["snippet"], classification=cls.classification, method=method,
                  summary=cls.summary, received_at=it["date"])
        db.add(r)
        db.flush()
        apply_effects(db, r, lead, addr)
        new += 1
    return {"new_replies": new, "checked": len(items)}


def run(db: Session) -> AgentResult:
    if not gmail.is_connected(db):
        return AgentResult("skipped", "Gmail NOT CONNECTED")
    try:
        items = gmail.list_inbox(db)
    except (IntegrationError, NotConfigured) as e:
        return AgentResult("error", str(e))
    out = process(db, items, ss.get(db, "gmail_address"))
    return AgentResult("ok", f"{out['new_replies']} new replies from {out['checked']} inbox messages checked", out)
