from __future__ import annotations

from dataclasses import dataclass, field
from urllib.parse import urlparse


@dataclass
class AgentResult:
    status: str = "ok"  # ok | skipped | error
    message: str = ""
    details: dict = field(default_factory=dict)


def domain_from_url(url: str | None) -> str | None:
    if not url:
        return None
    host = urlparse(url if "//" in url else "//" + url).hostname
    if not host:
        return None
    return host.lower().removeprefix("www.")


DIRECTORY_DOMAINS = {
    "linkedin.com", "facebook.com", "instagram.com", "twitter.com", "x.com", "youtube.com", "reddit.com", "yelp.com",
    "crunchbase.com", "wikipedia.org", "glassdoor.com", "indeed.com", "tripadvisor.com", "pinterest.com", "tiktok.com",
    "clutch.co", "upwork.com", "fiverr.com", "medium.com", "quora.com", "github.com", "yellowpages.com", "trustpilot.com",
    "bbb.org", "g2.com", "capterra.com", "ycombinator.com", "news.ycombinator.com",
}
