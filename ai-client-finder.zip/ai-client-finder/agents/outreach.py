"""Outreach Agent: human approval, suppression, daily limits and duplicate prevention. Only Gmail via official OAuth."""
from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from integrations import gmail
from integrations.base import IntegrationError, NotConfigured
from models.orm import Contact, Lead, Message, aware, utcnow
from services import settings_store as ss
from services.suppression import is_suppressed


class SendBlocked(Exception):
    def __init__(self, reasons: list[str]):
        super().__init__("; ".join(reasons))
        self.reasons = reasons


def sent_today(db: Session) -> int:
    start = utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    return db.execute(select(func.count()).select_from(Message).where(
        Message.channel == "email", Message.status == "sent", Message.sent_at >= start)).scalar_one()


def blockers(db: Session, msg: Message, *, for_draft: bool = False) -> list[str]:
    r: list[str] = []
    if msg.channel != "email":
        return ["Only email can be sent by the app; LinkedIn and public replies are sent by you manually"]
    if msg.is_sample:
        r.append("Sample data can never be sent")
    if not for_draft:
        auto_ok = (not ss.get(db, "require_approval")) and msg.status in ("draft", "pending_approval")
        if msg.status != "approved" and not auto_ok:
            r.append("Message is not approved yet (human approval required)")
    if msg.status in ("sent",):
        r.append("Already sent")
    contact = db.get(Contact, msg.contact_id) if msg.contact_id else None
    lead = db.get(Lead, msg.lead_id)
    to = (msg.to_email or (contact.email if contact else "") or "").lower()
    if not to:
        r.append("No recipient email")
        return r
    if contact and contact.email_status not in (ss.get(db, "allowed_email_statuses") or ["VERIFIED"]):
        r.append(f"Recipient email status is {contact.email_status}; only {', '.join(ss.get(db, 'allowed_email_statuses'))} may be emailed")
    sup = is_suppressed(db, to)
    if sup:
        r.append(sup.capitalize())
    if lead and lead.status in ("suppressed", "discarded"):
        r.append(f"Lead status is {lead.status}")
    if not msg.followup_of:
        prior = db.execute(select(Message.id).where(Message.to_email == to, Message.status == "sent", Message.id != msg.id)).first()
        if prior:
            r.append("Duplicate: this address was already emailed")
    elif lead and lead.status in ("replied", "interested", "meeting", "converted", "lost"):
        r.append(f"Lead already {lead.status}; follow-up cancelled")
    if for_draft:
        return r
    if not ss.get(db, "sender_name") or not ss.get(db, "postal_address"):
        r.append("Settings: sender name and postal address are required before sending")
    if sent_today(db) >= int(ss.get(db, "daily_send_limit") or 0):
        r.append("Daily sending limit reached")
    if not gmail.is_connected(db):
        r.append("Gmail is NOT CONNECTED")
    return r


def approve(db: Session, msg: Message) -> Message:
    if msg.status not in ("pending_approval", "draft"):
        raise SendBlocked([f"Cannot approve a message that is {msg.status}"])
    msg.status, msg.approved_at = "approved", utcnow()
    return msg


def reject(db: Session, msg: Message) -> Message:
    msg.status = "rejected"
    return msg


def save_draft(db: Session, msg: Message) -> Message:
    b = blockers(db, msg, for_draft=True)
    if b:
        raise SendBlocked(b)
    try:
        d = gmail.create_draft(db, msg.to_email, msg.subject or "", msg.body, msg.thread_id)
    except NotConfigured:
        raise SendBlocked(["Gmail is NOT CONNECTED"])
    msg.gmail_draft_id, msg.thread_id = d["draft_id"], d["thread_id"] or msg.thread_id
    return msg


def send(db: Session, msg: Message) -> Message:
    b = blockers(db, msg)
    if b:
        raise SendBlocked(b)
    try:
        res = gmail.send(db, msg.to_email, msg.subject or "", msg.body, msg.thread_id)
    except (IntegrationError, NotConfigured) as e:
        msg.status, msg.error = "failed", str(e)
        raise SendBlocked([str(e)])
    msg.status, msg.sent_at, msg.error = "sent", utcnow(), None
    msg.gmail_message_id, msg.thread_id = res["message_id"], res["thread_id"]
    lead = db.get(Lead, msg.lead_id)
    if lead and lead.status in ("new", "qualified"):
        lead.status = "contacted"
    return msg


def mark_manual_sent(db: Session, msg: Message) -> Message:
    if msg.is_sample:
        raise SendBlocked(["Sample data cannot be marked sent"])
    if msg.status not in ("approved", "pending_approval"):
        raise SendBlocked([f"Message is {msg.status}"])
    if msg.channel == "email":
        raise SendBlocked(["Email must be sent through Gmail"])
    msg.status, msg.sent_at = "sent", utcnow()
    lead = db.get(Lead, msg.lead_id)
    if lead and lead.status in ("new", "qualified"):
        lead.status = "contacted"
    return msg
