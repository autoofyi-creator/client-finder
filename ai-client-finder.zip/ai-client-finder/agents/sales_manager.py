"""Sales Manager Agent: schedules follow-ups (as drafts needing approval) and writes a pipeline report with next actions."""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from agents import message_writer
from agents.base import AgentResult
from agents.outreach import sent_today
from models.orm import Contact, Lead, Message, aware, utcnow
from services import settings_store as ss
from services.suppression import is_suppressed


def schedule_followups(db: Session) -> int:
    days, maxf = int(ss.get(db, "followup_days")), int(ss.get(db, "max_followups"))
    made = 0
    for m in db.execute(select(Message).where(Message.channel == "email", Message.status == "sent", Message.is_sample.is_(False))).scalars():
        if m.sequence_no >= maxf or aware(m.sent_at) > utcnow() - timedelta(days=days):
            continue
        if db.execute(select(Message.id).where(Message.followup_of == m.id)).first():
            continue
        lead = db.get(Lead, m.lead_id)
        contact = db.get(Contact, m.contact_id) if m.contact_id else None
        if not lead or lead.status != "contacted" or not contact or is_suppressed(db, m.to_email or ""):
            continue
        message_writer.write_followup(db, m, lead, contact)
        made += 1
    return made


def report(db: Session) -> dict:
    def count(*where):
        return db.execute(select(func.count()).select_from(Lead).where(Lead.is_sample.is_(False), *where)).scalar_one()
    high_no_email = db.execute(select(func.count()).select_from(Lead).where(
        Lead.is_sample.is_(False), Lead.intent == "HIGH", Lead.status.in_(["new", "qualified"]),
        ~Lead.id.in_(select(Contact.lead_id).where(Contact.email_status == "VERIFIED")))).scalar_one()
    pending = db.execute(select(func.count()).select_from(Message).where(Message.status == "pending_approval", Message.is_sample.is_(False))).scalar_one()
    rec = []
    if pending:
        rec.append(f"{pending} message(s) are waiting in the Approval Queue.")
    if high_no_email:
        rec.append(f"{high_no_email} HIGH-intent lead(s) have no VERIFIED email: connect Hunter/ZeroBounce or contact them via the original post / LinkedIn.")
    if sent_today(db):
        rec.append(f"{sent_today(db)} email(s) sent today (limit {ss.get(db, 'daily_send_limit')}).")
    interested = count(Lead.status == "interested")
    if interested:
        rec.append(f"{interested} interested lead(s): reply personally and propose a call.")
    return {"generated_at": utcnow().isoformat(), "leads": count(), "high_intent": count(Lead.intent == "HIGH"),
            "interested": interested, "pending_approvals": pending, "recommendations": rec or ["Nothing urgent. Run a discovery search."]}


def run(db: Session) -> AgentResult:
    made = schedule_followups(db)
    rep = report(db)
    rep["followups_created"] = made
    ss.set_value(db, "sales_manager_report", rep)
    return AgentResult("ok", f"{made} follow-up draft(s) created for approval", rep)
