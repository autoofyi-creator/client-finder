"""Company Research Agent: finds the official site (never guesses) and summarises only what the pages say."""
from __future__ import annotations

import re
from typing import Optional

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import DIRECTORY_DOMAINS, AgentResult, domain_from_url
from integrations import anthropic_client as llm
from integrations import search as search_api
from integrations.base import IntegrationError, NotConfigured
from models.orm import Company, Lead
from services import htmlx, http


class CompanySummary(BaseModel):
    summary: Optional[str] = None
    what_they_sell: Optional[str] = None
    country: Optional[str] = None
    notable_signals: list[str] = []


def find_website(company_name: str) -> tuple[Optional[str], Optional[str]]:
    hits = search_api.search(f'"{company_name}" official website', num=6, recent=False)
    key = re.sub(r"[^a-z0-9]", "", company_name.lower())
    for h in hits:
        dom = domain_from_url(h.url)
        if not dom or dom in DIRECTORY_DOMAINS:
            continue
        # require the company name (or its compact form) to be visible in the domain or result title
        if key[:6] and (key[:6] in re.sub(r"[^a-z0-9]", "", dom) or key[:8] in re.sub(r"[^a-z0-9]", "", h.title.lower())):
            return f"https://{dom}/", f"matched search result: {h.url}"
    return None, None


def run(db: Session, lead: Lead) -> AgentResult:
    company: Company | None = db.get(Company, lead.company_id) if lead.company_id else None
    site = company.website_url if company else (lead.meta or {}).get("website")
    how = "already known" if site else None
    if not site and lead.company_name:
        try:
            site, how = find_website(lead.company_name)
        except NotConfigured:
            return AgentResult("skipped", "Search API not connected; cannot locate website (add it manually)")
        except IntegrationError as e:
            return AgentResult("error", str(e))
    if not site:
        return AgentResult("skipped", "No company name/website available for this lead (person-only lead: contact via the original post)")
    if company is None:
        dom = domain_from_url(site)
        company = db.execute(select(Company).where(Company.domain == dom)).scalar_one_or_none()
        if company is None:
            company = Company(name=lead.company_name or dom or "Unknown", domain=dom, website_url=site, is_sample=lead.is_sample)
            db.add(company)
            db.flush()
        lead.company_id = company.id
    res = http.safe_get(site)
    research = dict(company.research or {})
    research.update({"website_found_by": how, "homepage_status": res.status, "homepage_error": res.error})
    if res.ok:
        s = htmlx.soup(res.text)
        title = s.title.get_text(strip=True) if s.title else None
        md = s.find("meta", attrs={"name": "description"})
        desc = md.get("content", "").strip() if md else None
        text = htmlx.visible_text(s, 3500)
        company.description = desc or company.description
        research.update({"title": title, "meta_description": desc})
        try:
            out = llm.complete_json("Summarise this company strictly from the page text. country only if explicitly stated.",
                                    llm.wrap(site, f"{title}\n{desc}\n{text}"), CompanySummary, 700)
            research.update(out.model_dump())
            company.country = company.country or out.country
        except (NotConfigured, IntegrationError):
            research["summary"] = desc or (text[:240] if text else None)
            research["method"] = "page metadata (no AI summary)"
    company.research = research
    if company.country and not lead.country:
        lead.country = company.country
    return AgentResult("ok", f"Website {'reachable' if res.ok else 'NOT reachable'}: {site}", {"website": site, "found_by": how})
