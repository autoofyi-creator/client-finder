"""Personalized Message Agent. Uses only recorded facts; opt-out + postal address footer is added by code, not the model."""
from __future__ import annotations

import re
from typing import Optional

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import AgentResult, domain_from_url
from config import SERVICES
from integrations import anthropic_client as llm
from integrations.base import IntegrationError, NotConfigured
from models.orm import Audit, Company, Contact, Lead, Message
from services import settings_store as ss

PITCH = {
    "website_development": "I build fast, mobile-friendly websites that turn visitors into enquiries.",
    "website_redesign": "I redesign existing websites so they look current, load quickly and convert better.",
    "digital_marketing": "I run digital marketing campaigns focused on measurable leads rather than vanity metrics.",
    "seo": "I help businesses rank for the searches their customers actually use.",
    "social_media": "I manage social media presence and content so businesses show up consistently.",
    "ai_video": "I create and edit AI-assisted video content quickly and affordably for businesses.",
    "ai_automation": "I build AI automations that remove repetitive manual work from day-to-day operations.",
}
GUIDE = {
    "website_development": "Offer to build a website. Focus on speed, mobile, enquiry capture.",
    "website_redesign": "Offer a redesign. Refer to observed audit findings only.",
    "digital_marketing": "Offer digital marketing. Tie to their stated goal or growth signal.",
    "seo": "Offer SEO. Refer to observed on-page findings only.",
    "social_media": "Offer social media management.",
    "ai_video": "Offer AI video creation/editing; mention the type of video they asked for.",
    "ai_automation": "Offer AI automation; mention the workflow they described.",
}


class EmailDraft(BaseModel):
    subject: str
    body: str
    facts_used: list[str] = []


class LinkedInDraft(BaseModel):
    connection_note: str
    message: str
    followup: str


def sender(db: Session) -> dict:
    return {k: ss.get(db, k) or "" for k in ("sender_name", "sender_title", "business_name", "postal_address", "website_url")}


def footer(db: Session) -> str:
    s = sender(db)
    sig = "\n".join(x for x in [s["sender_name"], s["sender_title"], s["business_name"], s["website_url"], s["postal_address"]] if x)
    return f"\n\n--\n{sig}\n\nIf you'd rather not hear from me, just reply \"unsubscribe\" and I won't contact you again."


def first_name(contact: Optional[Contact], lead: Lead) -> Optional[str]:
    n = contact.name if contact and contact.name else (None if lead.name_is_handle else lead.name)
    return n.split()[0] if n else None


def lc(s: str) -> str:
    """Lowercase a service name for mid-sentence use, keeping acronyms (SEO, AI) intact."""
    first = s.split()[0] if s else ""
    return s if first.isupper() and len(first) > 1 else s.lower()


def _date(lead: Lead) -> str:
    return lead.source_date.strftime("%d %b %Y") if lead.source_date else "an unknown date"


def build_facts(db: Session, lead: Lead, contact: Optional[Contact], service: str) -> dict:
    company = db.get(Company, lead.company_id) if lead.company_id else None
    audit = db.execute(select(Audit).where(Audit.lead_id == lead.id).order_by(Audit.id.desc())).scalars().first()
    top = []
    if audit and audit.findings:
        order = {"high": 0, "medium": 1, "low": 2}
        top = [f["observed"] for f in sorted(audit.findings, key=lambda f: order[f["severity"]])[:3]]
    return {"prospect_first_name": first_name(contact, lead), "company": company.name if company else lead.company_name,
            "role": contact.title if contact else None, "service": SERVICES.get(service, service),
            "source_url": lead.source_url, "source_date": _date(lead) if lead.source_date else None,
            "their_words": lead.evidence_quote, "company_summary": (company.research or {}).get("summary") if company else None,
            "website": company.website_url if company else None, "observed_website_issues": top,
            "intent": lead.intent, "approach": lead.approach}


def _template_email(f: dict, service: str) -> EmailDraft:
    hi = f"Hi {f['prospect_first_name']}," if f["prospect_first_name"] else "Hello,"
    company = f["company"]
    if f["their_words"]:
        why = f"I came across your post ({_host(f['source_url'])}, {f['source_date'] or 'date unknown'}) where you wrote: \"{f['their_words'][:200]}\""
        subj = f"Re: your request for {lc(f['service'])}"
    elif f["observed_website_issues"]:
        why = f"I took a quick look at {f['website'] or 'your website'} and noticed: {f['observed_website_issues'][0]}"
        subj = f"A quick observation about {company or 'your website'}"
    else:
        why = f"I came across {company or 'your business'} while researching businesses that might benefit from {lc(f['service'])}."
        subj = f"{f['service']} for {company}" if company else f"{f['service']} idea"
    body = f"{hi}\n\n{why}\n\n{PITCH[service]}\n\nWould you be open to a short 15-minute call this week to see whether I can help{' ' + company if company else ''}? A one-line reply is enough."
    return _facts(EmailDraft(subject=subj, body=body, facts_used=[k for k in ("their_words", "observed_website_issues", "company") if f.get(k)]))


def _facts(d: EmailDraft) -> EmailDraft:
    return d


def _host(url: Optional[str]) -> str:
    return domain_from_url(url) or "a public page"


def write_email(db: Session, lead: Lead, contact: Optional[Contact], service: str, *, status: str = "pending_approval") -> Message:
    service = service if service in SERVICES else (lead.service_needed if lead.service_needed in SERVICES else "website_development")
    f = build_facts(db, lead, contact, service)
    s = sender(db)
    method = "template"
    try:
        d = llm.complete_json(
            f"Write a short (90-140 words) personalised cold email from {s['sender_name'] or 'the sender'} ({s['business_name'] or 'a freelance digital agency'}). "
            f"Service: {SERVICES[service]}. {GUIDE[service]} Start with a greeting. Mention the specific reason for contacting (from facts), the actual opportunity, "
            "and end with one clear call to action. Do NOT write a signature or unsubscribe line (added automatically). Do not invent facts, results, clients or prices. "
            'JSON: {"subject": str, "body": str, "facts_used": [names of fact keys you relied on]}.',
            "FACTS (JSON):\n" + llm.wrap("facts", str(f)), EmailDraft, 800)
        method = "claude"
        if not f["company"] and not f["prospect_first_name"]:
            pass
        elif (f["company"] or "").lower() not in d.body.lower() and (f["prospect_first_name"] or "").lower() not in d.body.lower():
            raise ValueError("draft mentions neither prospect nor company")
    except (NotConfigured, IntegrationError, ValueError):
        d, method = _template_email(f, service), "template"
    to = contact.email if contact else None
    msg = Message(lead_id=lead.id, contact_id=contact.id if contact else None, channel="email", service=service, subject=d.subject[:480],
                  body=d.body.strip() + footer(db), status=status, generated_by=method, facts_used=d.facts_used, to_email=to,
                  is_sample=lead.is_sample)
    db.add(msg)
    db.flush()
    return msg


def write_public_reply(db: Session, lead: Lead, service: str) -> Message:
    f = build_facts(db, lead, None, service)
    body = (f"Hi{' ' + f['prospect_first_name'] if f['prospect_first_name'] else ''} - I saw your post and this is something I do: {PITCH[service]} "
            "Happy to share relevant examples or jump on a quick call. Want me to send a couple of ideas?")
    msg = Message(lead_id=lead.id, channel="public_reply", service=service, subject=None, body=body, status="pending_approval",
                  generated_by="template", facts_used=["their_words"] if f["their_words"] else [], is_sample=lead.is_sample)
    db.add(msg)
    db.flush()
    return msg


def write_linkedin(db: Session, lead: Lead, contact: Contact, service: str) -> list[Message]:
    f = build_facts(db, lead, contact, service)
    fn = first_name(contact, lead) or "there"
    company = f["company"] or "your company"
    tmpl = LinkedInDraft(
        connection_note=f"Hi {fn}, I help businesses like {company} with {lc(f['service'])}. Would be glad to connect."[:300],
        message=f"Thanks for connecting, {fn}. {PITCH[service]} " + (f"I noticed: {f['observed_website_issues'][0]} " if f["observed_website_issues"] else "")
                + "Open to a quick chat?",
        followup=f"Hi {fn}, following up on my note about {lc(f['service'])} for {company}. Happy to share a few ideas if useful.")
    d, method = tmpl, "template"
    try:
        d = llm.complete_json("Write LinkedIn outreach. connection_note must be <=280 characters. Use only the facts. No emojis, no invented claims. "
                              'JSON: {"connection_note","message","followup"}.', "FACTS:\n" + llm.wrap("facts", str(f)), LinkedInDraft, 700)
        method = "claude"
        if len(d.connection_note) > 300:
            d = tmpl
            method = "template"
    except (NotConfigured, IntegrationError):
        pass
    out = []
    for ch, text in (("linkedin_connect", d.connection_note), ("linkedin_message", d.message), ("linkedin_followup", d.followup)):
        m = Message(lead_id=lead.id, contact_id=contact.id, channel=ch, service=service, body=text, status="pending_approval",
                    generated_by=method, is_sample=lead.is_sample)
        db.add(m)
        out.append(m)
    db.flush()
    return out


def write_followup(db: Session, prev: Message, lead: Lead, contact: Contact) -> Message:
    fn = first_name(contact, lead)
    body = (f"{'Hi ' + fn + ',' if fn else 'Hello,'}\n\nJust following up on my earlier note about {lc(SERVICES.get(prev.service, 'my services'))}"
            f"{' for ' + lead.company_name if lead.company_name else ''}. If it's not a priority right now, no problem at all - "
            "a quick yes/no helps me know whether to check back later.") + footer(db)
    m = Message(lead_id=lead.id, contact_id=contact.id, channel="email", service=prev.service,
                subject=prev.subject if (prev.subject or "").lower().startswith("re:") else f"Re: {prev.subject}", body=body,
                status="pending_approval", generated_by="template", followup_of=prev.id, sequence_no=prev.sequence_no + 1,
                to_email=prev.to_email, thread_id=prev.thread_id, is_sample=lead.is_sample)
    db.add(m)
    db.flush()
    return m


def run(db: Session, lead: Lead) -> AgentResult:
    service = lead.service_needed if lead.service_needed in SERVICES else "website_development"
    contacts = db.execute(select(Contact).where(Contact.lead_id == lead.id)).scalars().all()
    allowed = ss.get(db, "allowed_email_statuses")
    made = []
    sendable = [c for c in contacts if c.email and c.email_status in allowed]
    if db.execute(select(Message.id).where(Message.lead_id == lead.id)).first():
        return AgentResult("skipped", "Messages already exist for this lead")
    if sendable:
        pref = sorted(sendable, key=lambda c: (not c.is_decision_maker, bool(re.match(r"(info|contact|hello|admin)@", c.email))))[0]
        made.append(write_email(db, lead, pref, service).channel)
    elif lead.source_type in ("hackernews", "web_search", "rss") and lead.intent == "HIGH":
        made.append(write_public_reply(db, lead, service).channel)
    li = [c for c in contacts if c.linkedin_url]
    if li:
        pref = sorted(li, key=lambda c: not c.is_decision_maker)[0]
        write_linkedin(db, lead, pref, service)
        made.append("linkedin x3")
    return AgentResult("ok" if made else "skipped", f"Drafted: {', '.join(made) or 'nothing (no sendable email, LinkedIn contact or public-reply route)'}", {"made": made})
