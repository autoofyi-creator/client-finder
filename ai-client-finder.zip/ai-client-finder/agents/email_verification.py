"""Email Verification Agent. VERIFIED requires an explicit provider verdict; syntax/DNS alone => UNKNOWN."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import AgentResult
from integrations import hunter, snov, zerobounce
from integrations.base import IntegrationError, NotConfigured
from models.orm import Contact, Lead
from services import email_checks
from services.suppression import is_suppressed

HUNTER_MAP = {"valid": "VERIFIED", "invalid": "INVALID", "accept_all": "CATCH-ALL", "webmail": "UNKNOWN", "disposable": "INVALID", "unknown": "UNKNOWN"}
ZB_MAP = {"valid": "VERIFIED", "invalid": "INVALID", "catch-all": "CATCH-ALL", "unknown": "UNKNOWN", "spamtrap": "INVALID",
          "abuse": "RISKY", "do_not_mail": "INVALID"}
SNOV_MAP = {"valid": "VERIFIED", "not_valid": "INVALID", "invalid": "INVALID", "unknown": "UNKNOWN", "catch_all": "CATCH-ALL", "catch-all": "CATCH-ALL"}


def map_provider(provider: str, raw: str | None) -> str:
    raw = (raw or "unknown").lower()
    return {"hunter": HUNTER_MAP, "zerobounce": ZB_MAP, "snov": SNOV_MAP}[provider].get(raw, "UNKNOWN")


def verify_email(email: str) -> dict:
    local = email_checks.local_check(email)
    result = {"status": "UNKNOWN", "local": local, "provider": None, "level": "syntax+dns only (NOT provider-verified)"}
    if not local["syntax_ok"]:
        result.update(status="INVALID", level="syntax")
        return result
    if local["disposable"]:
        result.update(status="INVALID", level="disposable domain")
        return result
    if local["dns_ok"] is False:
        result.update(status="INVALID", level="dns: " + "; ".join(local["notes"]))
        return result
    for mod, name in ((zerobounce, "zerobounce"), (hunter, "hunter"), (snov, "snov")):
        if not mod.configured():
            continue
        try:
            v = mod.verify(local["email"])
        except (IntegrationError, NotConfigured) as e:
            result.setdefault("provider_errors", []).append(str(e))
            continue
        status = map_provider(name, v.get("raw_status"))
        result.update(status=status, provider=name, provider_raw=v, level=f"provider verified by {name}")
        if status == "VERIFIED" and local["role_account"]:
            result["note"] = "role account (e.g. info@): deliverable but less personal"
        return result
    return result


def run(db: Session, lead: Lead) -> AgentResult:
    rows = db.execute(select(Contact).where(Contact.lead_id == lead.id, Contact.email.is_not(None))).scalars().all()
    if not rows:
        return AgentResult("skipped", "No emails to verify")
    counts: dict[str, int] = {}
    for c in rows:
        if c.verification and c.verification.get("provider") and c.email_status != "UNKNOWN":
            continue
        v = verify_email(c.email)
        c.email_status, c.verification = v["status"], v
        sup = is_suppressed(db, c.email)
        if sup:
            c.verification["suppressed"] = sup
        counts[c.email_status] = counts.get(c.email_status, 0) + 1
    return AgentResult("ok", f"Verification results: {counts or 'nothing new'}", {"counts": counts})
