"""Orchestrator: runs agents in order, persists each stage, records errors in agent_runs, resumes across invocations."""
from __future__ import annotations

import time

from sqlalchemy import select
from sqlalchemy.orm import Session

from agents import (company_research, discovery, email_finder, email_verification, intent, lead_scoring, linkedin_research,
                    message_writer, reply_analysis, sales_manager, website_audit)
from agents.base import AgentResult
from models.orm import AgentRun, Job, Lead, STAGES
from services import jobs
from services import settings_store as ss

STAGE_AGENTS = {
    "intent": ("buying_intent", intent.run),
    "research": ("company_research", company_research.run),
    "linkedin": ("linkedin_research", linkedin_research.run),
    "email_find": ("email_finder", email_finder.run),
    "email_verify": ("email_verification", email_verification.run),
    "audit": ("website_audit", website_audit.run),
    "scoring": ("lead_scoring", lead_scoring.run),
    "messaging": ("personalized_message", message_writer.run),
}
ENRICH = {"research", "linkedin", "email_find", "email_verify", "audit", "messaging"}
RANK = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "NONE": 0, "UNCLASSIFIED": 0}


def log(db: Session, agent: str, res: AgentResult, lead_id=None, job_id=None, ms=None) -> None:
    db.add(AgentRun(agent=agent, lead_id=lead_id, job_id=job_id, status=res.status, message=res.message[:1000],
                    details=res.details if res.details else None, duration_ms=ms))


def next_stage(db: Session, lead: Lead) -> str | None:
    i = STAGES.index(lead.stage) if lead.stage in STAGES else 0
    for s in STAGES[i + 1:]:
        if s not in STAGE_AGENTS:
            continue
        if lead.intent == "NONE" and s != "scoring":
            return None
        if s in ENRICH and not (lead.meta or {}).get("force"):
            if RANK.get(lead.intent, 0) < RANK[ss.get(db, "min_intent_for_enrichment")]:
                continue
        return s
    return None


def process_lead(db: Session, lead_id: int, budget_s: float, job_id: int | None = None) -> dict:
    start, ran = time.monotonic(), []
    while True:
        lead = db.get(Lead, lead_id)
        if lead is None:
            return {"error": "lead not found"}
        stage = next_stage(db, lead)
        if stage is None:
            lead.stage = "complete"
            db.commit()
            return {"complete": True, "ran": ran}
        if time.monotonic() - start > budget_s - 8:
            return {"complete": False, "resume": True, "ran": ran}
        name, fn = STAGE_AGENTS[stage]
        t0 = time.monotonic()
        try:
            res = fn(db, lead)
            lead.stage = stage
            lead.last_error = None if res.status != "error" else res.message
            log(db, name, res, lead.id, job_id, int((time.monotonic() - t0) * 1000))
            db.commit()
            ran.append((name, res.status))
        except Exception as e:  # noqa: BLE001
            db.rollback()
            lead = db.get(Lead, lead_id)
            lead.last_error = f"{name}: {type(e).__name__}: {e}"[:1000]
            log(db, name, AgentResult("error", lead.last_error), lead_id, job_id)
            db.commit()
            return {"complete": False, "error": lead.last_error, "ran": ran}


def h_discovery(db: Session, job: Job, budget: float) -> dict:
    p = job.payload or {}
    if p.get("business"):
        res = discovery.discover_businesses(db, p["business"]["category"], p["business"]["location"])
    else:
        res = discovery.run(db, p)
    log(db, "discovery", res, job_id=job.id)
    for lid in res.details.get("new_lead_ids", []):
        jobs.enqueue(db, "pipeline_lead", {"lead_id": lid})
    return {"message": res.message, **{k: v for k, v in res.details.items() if k != "new_lead_ids"}, "new_leads": len(res.details.get("new_lead_ids", []))}


def h_pipeline(db: Session, job: Job, budget: float) -> dict:
    out = process_lead(db, job.payload["lead_id"], budget, job.id)
    if out.get("resume"):
        jobs.enqueue(db, "pipeline_lead", {"lead_id": job.payload["lead_id"]})
    if out.get("error"):
        raise RuntimeError(out["error"])
    return {"complete": out.get("complete"), "stages": out.get("ran")}


def h_reply_sync(db: Session, job: Job, budget: float) -> dict:
    res = reply_analysis.run(db)
    log(db, "reply_analysis", res, job_id=job.id)
    return {"message": res.message}


def h_sales_manager(db: Session, job: Job, budget: float) -> dict:
    res = sales_manager.run(db)
    log(db, "sales_manager", res, job_id=job.id)
    return {"message": res.message}


HANDLERS = {"discovery": h_discovery, "pipeline_lead": h_pipeline, "reply_sync": h_reply_sync, "sales_manager": h_sales_manager}


def requeue_incomplete(db: Session) -> int:
    n = 0
    for lead in db.execute(select(Lead).where(Lead.stage != "complete", Lead.is_sample.is_(False), Lead.status != "discarded")).scalars():
        jobs.enqueue(db, "pipeline_lead", {"lead_id": lead.id})
        n += 1
    return n
