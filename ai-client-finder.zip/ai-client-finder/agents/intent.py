"""Buying Intent Agent: HIGH / MEDIUM / LOW / NONE. Claude when available; auditable keyword rules otherwise."""
from __future__ import annotations

import re
from datetime import timedelta
from typing import Literal, Optional

from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from agents.base import AgentResult
from config import SERVICES
from integrations import anthropic_client as llm
from integrations.base import IntegrationError, NotConfigured
from models.orm import Lead

ServiceKey = Literal["website_development", "website_redesign", "digital_marketing", "seo", "social_media", "ai_video", "ai_automation", "other"]


class IntentResult(BaseModel):
    relevant: bool
    intent: Literal["HIGH", "MEDIUM", "LOW", "NONE"]
    confidence: float = Field(ge=0, le=1)
    service_needed: Optional[ServiceKey] = None
    person_name: Optional[str] = None
    company_name: Optional[str] = None
    country: Optional[str] = None
    evidence_quote: Optional[str] = None
    reasoning: str = ""
    recommended_approach: str = ""


SERVICE_KEYWORDS = [
    ("website_redesign", r"redesign|revamp|rebuild (my|our) (web)?site|new look for (my|our) site|outdated (web)?site"),
    ("seo", r"\bseo\b|search engine optimi[sz]ation|rank (on|in) google"),
    ("ai_automation", r"automat|chatbot|workflow|zapier|make\.com|n8n|ai agent"),
    ("ai_video", r"ai video|video edit|video production|explainer video|reels?|youtube editor|video creator|animation"),
    ("social_media", r"social media|instagram|tiktok|facebook ads|community manager"),
    ("digital_marketing", r"digital marketing|marketing agency|ppc|google ads|lead gen|growth marketer|email marketing|marketing (expert|manager|consultant)"),
    ("website_development", r"web ?site|web ?developer|web ?designer|landing page|shopify|wordpress|webflow|e-?commerce (site|store)|web ?app"),
]
HIGH_PATTERNS = [
    r"\b(i|we)(?:'m|’m| am|'re|’re| are)?\s*(really\s+)?(need|needs|looking for|searching for|seeking|want|require|hiring|in need of)\b[^.\n]{0,60}",
    r"\[hiring\]|\bwe(?:'re|’re| are) hiring\b",
    r"\b(anyone|can anyone|does anyone|who) (know|recommend|can)\b[^.\n]{0,50}(developer|designer|agency|freelancer|expert|editor)",
    r"\bseeking freelancer\b",
]
MEDIUM_PATTERNS = [r"\b(launching|launch(ed)? (a )?new|opening|expanding|rebrand(ing)?|new (store|product|business|venture)|raised|funding round)\b"]
NOT_DEMAND = re.compile(r"\b(i offer|we offer|our services|hire me|available for (hire|work)|for hire|\[for hire\]|top \d+|best \d+)\b", re.I)


def guess_service(text: str) -> Optional[str]:
    t = text.lower()
    for key, pat in SERVICE_KEYWORDS:
        if re.search(pat, t):
            return key
    return None


def heuristic(text: str) -> IntentResult:
    svc = guess_service(text)
    if NOT_DEMAND.search(text) and not re.search(r"\[hiring\]|we(?:'re|’re| are) hiring", text, re.I):
        return IntentResult(relevant=False, intent="NONE", confidence=0.6, reasoning="Looks like a seller/advert or list article, not a buyer.")
    if svc:
        for pat in HIGH_PATTERNS:
            m = re.search(pat, text, re.I)
            if m:
                s = text.rfind(".", 0, m.start()) + 1
                e = text.find(".", m.end())
                quote = text[s: e if e != -1 else m.end() + 80].strip()[:300]
                return IntentResult(relevant=True, intent="HIGH", confidence=0.55, service_needed=svc, evidence_quote=quote,
                                    reasoning="Keyword rules matched an explicit request for a relevant service (no AI judgement).",
                                    recommended_approach="Reply promptly, referencing their request; verify the post is still open first.")
        for pat in MEDIUM_PATTERNS:
            m = re.search(pat, text, re.I)
            if m:
                return IntentResult(relevant=True, intent="MEDIUM", confidence=0.4, service_needed=svc,
                                    evidence_quote=text[max(0, m.start() - 60): m.end() + 80].strip(),
                                    reasoning="Growth/launch language plus a relevant service keyword.",
                                    recommended_approach="Lead with a specific observation about their growth stage.")
        return IntentResult(relevant=True, intent="LOW", confidence=0.25, service_needed=svc,
                            reasoning="Mentions a relevant topic but no request observed.", recommended_approach="Only pursue if an audit shows a clear gap.")
    return IntentResult(relevant=False, intent="NONE", confidence=0.5, reasoning="No relevant service keywords.")


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").lower()).strip()


def validate_against_source(r: IntentResult, source: str) -> IntentResult:
    """Anti-fabrication: quotes and names must literally appear in the source, else downgrade."""
    src = _norm(source)
    if r.evidence_quote and _norm(r.evidence_quote) not in src:
        r.reasoning += " [Evidence quote could not be verified in the source text and was removed.]"
        r.evidence_quote = None
        r.confidence = min(r.confidence, 0.4)
        if r.intent == "HIGH":
            r.intent = "LOW"
            r.confidence = min(r.confidence, 0.3)
    if r.intent == "HIGH" and not r.evidence_quote:
        r.intent = "LOW"
        r.confidence = min(r.confidence, 0.3)
    for field in ("person_name", "company_name"):
        v = getattr(r, field)
        if v and _norm(v) not in src:
            setattr(r, field, None)
    return r


PROMPT = f"""Classify buying intent for a business that sells: {', '.join(SERVICES.values())}.
HIGH = the author explicitly asks for/hiring for one of these services.
MEDIUM = a company shows a relevant need or growth signal (launch, expansion, rebrand) without asking.
LOW = could plausibly benefit but expressed no demand.
NONE = irrelevant, a seller advertising, a listicle, or an agency page.
Return JSON: relevant(bool), intent, confidence(0-1), service_needed (one of {list(SERVICES)} or "other" or null),
person_name, company_name, country (only if stated), evidence_quote (an EXACT verbatim excerpt from the source, <=300 chars, or null),
reasoning (1-2 sentences), recommended_approach (1-2 sentences)."""


def run(db: Session, lead: Lead) -> AgentResult:
    if lead.intent not in ("UNCLASSIFIED",) and lead.intent_method:
        return AgentResult("skipped", f"Already classified {lead.intent}")
    text = f"{lead.source_title or ''}\n{lead.source_text or ''}".strip()
    if not text:
        lead.intent = "LOW"
        return AgentResult("ok", "No source text; defaulted to LOW")
    method = "heuristic"
    try:
        r = llm.complete_json(PROMPT, f"Source URL: {lead.source_url}\nSource date: {lead.source_date}\n" + llm.wrap("post", text), IntentResult)
        method = "claude"
    except NotConfigured:
        r = heuristic(text)
    except IntegrationError as e:
        r = heuristic(text)
        lead.last_error = f"Claude unavailable, heuristic used: {e}"
    r = validate_against_source(r, text)
    lead.intent = r.intent if r.relevant else "NONE"
    lead.confidence = r.confidence
    lead.intent_method = method
    lead.evidence_quote = r.evidence_quote
    lead.intent_reason = r.reasoning
    lead.approach = r.recommended_approach
    lead.service_needed = r.service_needed if r.service_needed in SERVICES else (guess_service(text) if r.relevant else None)
    if r.person_name and not lead.name:
        lead.name = r.person_name
    if r.company_name and not lead.company_name:
        lead.company_name = r.company_name
    if r.country and not lead.country:
        lead.country = r.country
    if lead.intent == "NONE":
        lead.status = "discarded"
    return AgentResult("ok", f"{lead.intent} ({method}, confidence {r.confidence:.2f})", {"service": lead.service_needed})
