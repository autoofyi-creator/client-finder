"""Website Audit Agent: reports only problems actually observed in fetched HTML (plus optional PageSpeed)."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Optional

from pydantic import BaseModel
from sqlalchemy.orm import Session

from agents.base import AgentResult
from config import env
from integrations import anthropic_client as llm
from integrations import pagespeed
from integrations.base import IntegrationError, NotConfigured
from models.orm import Audit, Company, Lead
from services import htmlx, http

CAVEAT = "Checked on static HTML from our server; content added by JavaScript is not visible to this audit."


def finding(area: str, severity: str, observed: str, impact: str) -> dict:
    return {"area": area, "severity": severity, "observed": observed, "impact": impact}


def analyze(url: str, home: http.Fetch, contact_pages: list[http.Fetch], sitemap_status: Optional[int]) -> list[dict]:
    f: list[dict] = []
    if home.error or not home.ok:
        reason = home.error or f"HTTP {home.status}"
        return [finding("availability", "high", f"Homepage could not be loaded ({reason}).", "Visitors and search engines may not be able to reach the site.")]
    s = htmlx.soup(home.text)
    final = home.final_url or url
    if final.startswith("http://"):
        f.append(finding("security", "high", "Site is served over http:// (no HTTPS).", "Browsers label the site 'Not secure'; hurts trust and rankings."))
    if home.elapsed_ms and home.elapsed_ms > 3000:
        f.append(finding("performance", "medium", f"Homepage took {home.elapsed_ms} ms to respond from our server.", "Slow pages lose visitors. (Single measurement, from one location.)"))
    if not s.find("meta", attrs={"name": "viewport"}):
        f.append(finding("mobile", "high", "No viewport meta tag found.", "The page is not declared mobile-responsive; likely poor on phones."))
    title = s.title.get_text(strip=True) if s.title else ""
    if not title:
        f.append(finding("seo", "high", "Page has no <title>.", "Search results will show an auto-generated title."))
    elif len(title) < 15 or len(title) > 70:
        f.append(finding("seo", "low", f"Title is {len(title)} characters (“{title[:60]}”).", "Titles of roughly 30-65 characters display best in search results."))
    if not s.find("meta", attrs={"name": "description"}):
        f.append(finding("seo", "medium", "No meta description.", "Search engines will pick arbitrary text for the result snippet."))
    h1 = s.find_all("h1")
    if len(h1) == 0:
        f.append(finding("seo", "medium", "No <h1> heading on the homepage.", "Weaker topical signal for search engines and screen readers."))
    elif len(h1) > 1:
        f.append(finding("seo", "low", f"{len(h1)} <h1> headings on the homepage.", "Ambiguous page structure."))
    imgs = s.find_all("img")
    noalt = [i for i in imgs if not (i.get("alt") or "").strip()]
    if imgs and len(noalt) >= 3:
        f.append(finding("seo", "low", f"{len(noalt)} of {len(imgs)} images have no alt text.", "Lost image-search traffic and accessibility problems."))
    robots_meta = s.find("meta", attrs={"name": "robots"})
    if robots_meta and "noindex" in (robots_meta.get("content") or "").lower():
        f.append(finding("seo", "high", "Homepage has a robots meta tag containing noindex.", "The page asks search engines not to index it."))
    if not s.find("link", rel="canonical"):
        f.append(finding("seo", "low", "No canonical link tag.", "Risk of duplicate-URL dilution."))
    if sitemap_status == 404:
        f.append(finding("seo", "low", "/sitemap.xml returned 404.", "Search engines get no sitemap at the standard location."))
    if not s.find("script", type="application/ld+json"):
        f.append(finding("seo", "low", "No JSON-LD structured data on the homepage.", "Not eligible for some rich results."))
    all_pages = [home] + contact_pages
    has_form = any(htmlx.soup(p.text).find("form") for p in all_pages if p.ok)
    has_tel_mail = bool(s.select('a[href^="tel:"], a[href^="mailto:"]'))
    if not has_form:
        f.append(finding("conversion", "high" if not has_tel_mail else "medium",
                         "No <form> element found on the homepage or the contact-type pages checked" + ("" if not has_tel_mail else "; only tel:/mailto: links exist") + ".",
                         "No on-site enquiry form (it may be injected by JavaScript or live on a page we did not check)."))
    ctas = [a for a in s.find_all(["a", "button"]) if htmlx.CTA_RE.search(a.get_text(" ", strip=True) or "")]
    if not ctas:
        f.append(finding("conversion", "high", "No link/button with call-to-action wording (contact, book, get a quote...) on the homepage.", "Visitors are not told what to do next."))
    header_links = len(s.select("header a, nav a"))
    if not s.find("nav") and header_links < 3:
        f.append(finding("navigation", "medium", "No <nav> element and fewer than 3 links in the header.", "Navigation may be hard to find or missing."))
    years = [int(y) for y in re.findall(r"(?:©|&copy;|copyright)\s*(?:\d{4}\s*[-–]\s*)?(\d{4})", home.text, re.I)]
    if years and max(years) <= datetime.now().year - 2:
        f.append(finding("freshness", "medium", f"Footer copyright reads {max(years)}.", "Suggests the site has not been maintained."))
    return f


class Opportunity(BaseModel):
    summary: str


def summarize(company_name: str, findings: list[dict]) -> str:
    if not findings:
        return "No issues observed in the checks performed. " + CAVEAT
    order = {"high": 0, "medium": 1, "low": 2}
    top = sorted(findings, key=lambda x: order[x["severity"]])[:4]
    try:
        out = llm.complete_json("Write a 3-4 sentence internal opportunity note for a web agency. Use ONLY the findings listed; do not add problems.",
                                "Company: " + company_name + "\nFindings JSON: " + str(top), Opportunity, 400)
        return out.summary + " " + CAVEAT
    except (NotConfigured, IntegrationError):
        return f"{len(findings)} issues observed. Most important: " + " ".join(f"[{t['area']}] {t['observed']}" for t in top) + " " + CAVEAT




def audit_url(db: Session, url: str, company: Company | None, lead: Lead | None) -> Audit:
    url = http.normalize_url(url)
    home = http.safe_get(url)
    contacts: list[http.Fetch] = []
    sitemap = None
    if home.ok:
        for link in htmlx.same_site_links(htmlx.soup(home.text), home.final_url or url, limit=2):
            r = http.safe_get(link)
            if r.ok:
                contacts.append(r)
        base = "/".join((home.final_url or url).split("/")[:3])
        sm = http.safe_get(base + "/sitemap.xml", respect_robots=False)
        sitemap = sm.status
    findings = analyze(url, home, contacts, sitemap)
    ps = None
    if home.ok and (env("PAGESPEED_API_KEY") or env("RUN_PAGESPEED_WITHOUT_KEY") == "1"):
        try:
            ps = pagespeed.run(home.final_url or url)
            sc = ps.get("mobile_performance_score")
            if sc is not None and sc < 50:
                findings.append(finding("performance", "high", f"Lighthouse mobile performance score is {sc}/100 (LCP {ps.get('lcp')}).", "Poor mobile speed costs conversions and rankings."))
        except IntegrationError as e:
            ps = {"error": str(e)}
    audit = Audit(company_id=company.id if company else None, lead_id=lead.id if lead else None, url=url, reachable=home.ok,
                  status_code=home.status, load_ms=home.elapsed_ms, findings=findings, pagespeed=ps,
                  summary=summarize(company.name if company else url, findings), is_sample=bool(lead and lead.is_sample))
    db.add(audit)
    db.flush()
    return audit


def run(db: Session, lead: Lead) -> AgentResult:
    company = db.get(Company, lead.company_id) if lead.company_id else None
    if not company or not company.website_url:
        return AgentResult("skipped", "No official website known for this lead")
    a = audit_url(db, company.website_url, company, lead)
    return AgentResult("ok", f"{len(a.findings or [])} observed issues; site {'reachable' if a.reachable else 'unreachable'}", {"audit_id": a.id})
