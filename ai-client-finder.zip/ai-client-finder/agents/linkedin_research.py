"""LinkedIn Research Agent. Uses ONLY public search-engine results; never logs in to or scrapes LinkedIn."""
from __future__ import annotations

import re

from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import AgentResult
from integrations import search as search_api
from integrations.base import IntegrationError, NotConfigured
from models.orm import Company, Contact, Lead

ROLES = '("founder" OR "CEO" OR "owner" OR "co-founder" OR "marketing manager" OR "head of marketing" OR "managing director")'
DM_RE = re.compile(r"founder|ceo|owner|managing director|director|head of|marketing|president|principal", re.I)


def parse_profile_title(title: str) -> tuple[str | None, str | None]:
    """LinkedIn result titles look like 'Jane Doe - Founder - Acme | LinkedIn'. Parsed text is UNVERIFIED."""
    t = title.replace("| LinkedIn", "").strip()
    parts = [p.strip() for p in re.split(r"\s[-–—]\s", t)]
    name = parts[0] if parts and 1 < len(parts[0].split()) <= 4 else None
    role = parts[1] if len(parts) > 1 else None
    return name, role


def run(db: Session, lead: Lead) -> AgentResult:
    company = db.get(Company, lead.company_id) if lead.company_id else None
    cname = company.name if company else lead.company_name
    if not cname:
        return AgentResult("skipped", "No company name to research decision-makers for")
    try:
        hits = search_api.search(f'site:linkedin.com/in {ROLES} "{cname}"', num=8, recent=False)
    except NotConfigured:
        return AgentResult("skipped", "Search API not connected (LinkedIn profiles are found via public search results only)")
    except IntegrationError as e:
        return AgentResult("error", str(e))
    added = 0
    for h in hits:
        if "linkedin.com/in/" not in h.url:
            continue
        if cname.lower().split()[0] not in (h.title + " " + h.snippet).lower():
            continue  # profile does not visibly mention the company; don't attribute it
        if db.execute(select(Contact.id).where(Contact.lead_id == lead.id, Contact.linkedin_url == h.url)).first():
            continue
        name, role = parse_profile_title(h.title)
        db.add(Contact(lead_id=lead.id, company_id=lead.company_id, name=name, title=role, linkedin_url=h.url.split("?")[0],
                       linkedin_note=f"Public search snippet (unverified): {h.snippet[:240]}",
                       is_decision_maker=bool(role and DM_RE.search(role)), is_sample=lead.is_sample))
        db.flush()
        added += 1
        if added >= 3:
            break
    return AgentResult("ok", f"{added} possible decision-makers (confirm on LinkedIn before use)", {"added": added})
