"""Lead Scoring Agent: transparent 0-100 score; every point is explained in score_breakdown."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import AgentResult
from models.orm import Audit, Contact, Lead, aware, utcnow
from services import settings_store as ss

BASE = {"HIGH": 45, "MEDIUM": 25, "LOW": 8, "NONE": 0, "UNCLASSIFIED": 0}


def run(db: Session, lead: Lead) -> AgentResult:
    b: dict[str, int] = {}
    conf = lead.confidence if lead.confidence is not None else 0.3
    b["intent"] = round(BASE.get(lead.intent, 0) * (0.5 + 0.5 * conf))
    if lead.source_date:
        age = (utcnow() - aware(lead.source_date)).days
        b["recency"] = 15 if age <= 7 else 10 if age <= 30 else 4 if age <= 90 else -10 if age > 180 else 0
    contacts = db.execute(select(Contact).where(Contact.lead_id == lead.id)).scalars().all()
    if any(c.email_status == "VERIFIED" for c in contacts):
        b["verified_email"] = 15
    elif any(c.email and c.email_status in ("CATCH-ALL", "RISKY") for c in contacts):
        b["risky_email"] = 5
    if any(c.is_decision_maker for c in contacts):
        b["decision_maker"] = 5
    audit = db.execute(select(Audit).where(Audit.lead_id == lead.id).order_by(Audit.id.desc())).scalars().first()
    if audit and audit.findings:
        b["audit_gaps"] = min(10, sum({"high": 4, "medium": 2, "low": 1}.get(f["severity"], 0) for f in audit.findings))
    countries = [c.lower() for c in ss.get(db, "target_countries") or []]
    if countries and lead.country and lead.country.lower() in countries:
        b["target_country"] = 5
    lead.score = max(0, min(100, sum(b.values())))
    lead.score_breakdown = b
    if lead.status == "new" and lead.intent in ("HIGH", "MEDIUM"):
        lead.status = "qualified"
    return AgentResult("ok", f"Score {lead.score}", {"breakdown": b})
