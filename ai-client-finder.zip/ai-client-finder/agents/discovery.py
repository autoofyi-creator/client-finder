"""Discovery Agent: finds public posts/pages where demand is expressed. Does not claim to search the whole internet."""
from __future__ import annotations

import hashlib
import re
from datetime import timedelta
from urllib.parse import urlparse

from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import DIRECTORY_DOMAINS, AgentResult, domain_from_url
from integrations import free_sources, search as search_api
from integrations.base import IntegrationError, NotConfigured
from integrations.search import SearchHit
from models.orm import Company, Lead, utcnow
from services import settings_store as ss

NO_AUTH_SOURCES = {"facebook.com", "instagram.com", "linkedin.com", "tiktok.com", "x.com", "twitter.com", "pinterest.com"}
LISTICLE = re.compile(r"\b(top|best)\s+\d*\s*(web|seo|digital|marketing|ai|video|website)", re.I)


def dedupe_key(url: str) -> str:
    p = urlparse(url)
    q = p.query if p.hostname and "ycombinator" in p.hostname else ""
    norm = f"{(p.hostname or '').lower().removeprefix('www.')}{p.path.rstrip('/')}?{q}"
    return hashlib.sha256(norm.encode()).hexdigest()


def save_candidate(db: Session, hit: SearchHit, via: str, source_type: str, author: str | None = None, is_sample: bool = False) -> Lead | None:
    dom = domain_from_url(hit.url)
    if not dom or dom in NO_AUTH_SOURCES or LISTICLE.search(hit.title or ""):
        return None
    max_age = ss.get(db, "max_lead_age_days")
    if hit.date and max_age and hit.date < utcnow() - timedelta(days=int(max_age)):
        return None
    key = dedupe_key(hit.url)
    if db.execute(select(Lead.id).where(Lead.dedupe_key == key)).first():
        return None
    lead = Lead(dedupe_key=key, source_type=source_type, source_url=hit.url, source_title=(hit.title or "")[:500],
                source_text=(hit.snippet or "")[:4000], source_date=hit.date, discovered_via=via[:300],
                name=author, name_is_handle=bool(author), is_sample=is_sample, stage="discovered", meta={})
    db.add(lead)
    db.flush()
    return lead


def run(db: Session, params: dict | None = None) -> AgentResult:
    params = params or {}
    queries = params.get("queries") or ss.get(db, "search_queries")
    per_run = int(params.get("queries_per_run") or ss.get(db, "queries_per_run"))
    cursor = int(ss.get(db, "discovery_cursor") or 0) if not params.get("queries") else 0
    batch = [queries[(cursor + i) % len(queries)] for i in range(min(per_run, len(queries)))] if queries else []
    if not params.get("queries"):
        ss.set_value(db, "discovery_cursor", (cursor + per_run) % max(len(queries), 1))
    new_ids: list[int] = []
    errors: list[str] = []
    searched = {"search_api": 0, "hackernews": 0, "rss": 0}

    for q in batch:
        try:
            for hit in search_api.search(q, num=10):
                lead = save_candidate(db, hit, f"search: {q}", "web_search")
                searched["search_api"] += 1
                if lead:
                    new_ids.append(lead.id)
        except NotConfigured:
            errors.append("Search API not connected: only free sources used")
            break
        except IntegrationError as e:
            errors.append(str(e))
    if ss.get(db, "enable_hn") and params.get("hn", True):
        for q in batch[:3]:
            try:
                for item in free_sources.hacker_news(q):
                    lead = save_candidate(db, item["hit"], f"hackernews: {q}", "hackernews", author=item["author"])
                    searched["hackernews"] += 1
                    if lead:
                        new_ids.append(lead.id)
            except IntegrationError as e:
                errors.append(str(e))
    for feed in ss.get(db, "rss_feeds") or []:
        try:
            for hit in free_sources.rss(feed):
                text = f"{hit.title} {hit.snippet}".lower()
                if re.search(r"(need|looking for|hiring|seeking|wanted|require)", text) and re.search(
                        r"(web|seo|marketing|video|automation|designer|developer|social media)", text):
                    lead = save_candidate(db, hit, f"rss: {feed}", "rss")
                    searched["rss"] += 1
                    if lead:
                        new_ids.append(lead.id)
        except IntegrationError as e:
            errors.append(str(e))
    db.flush()
    seen = list(dict.fromkeys(errors))
    return AgentResult("ok" if new_ids or not seen else "error", f"{len(new_ids)} new candidate leads",
                       {"new_lead_ids": new_ids, "queries": batch, "scanned": searched, "errors": seen})


def discover_businesses(db: Session, category: str, location: str) -> AgentResult:
    """Public company websites in a category/location -> LOW-intent prospects (need not yet expressed)."""
    q = f"{category} {location}".strip()
    try:
        hits = search_api.search(q, num=10, recent=False)
    except NotConfigured:
        return AgentResult("skipped", "Search API not connected")
    new = []
    for h in hits:
        dom = domain_from_url(h.url)
        if not dom or dom in DIRECTORY_DOMAINS or LISTICLE.search(h.title or ""):
            continue
        key = dedupe_key(f"https://{dom}/")
        if db.execute(select(Lead.id).where(Lead.dedupe_key == key)).first():
            continue
        name = re.split(r"\s[|\-–:]\s", h.title or dom)[0][:200]
        comp = Company(name=name, domain=dom, website_url=f"https://{dom}/", country=None)
        db.add(comp)
        db.flush()
        lead = Lead(dedupe_key=key, source_type="business_search", source_url=h.url, source_title=h.title,
                    source_text=h.snippet, source_date=h.date, discovered_via=f"business search: {q}",
                    company_id=comp.id, company_name=name, intent="LOW", confidence=0.2, intent_method="rule",
                    intent_reason="Public company website; no demand signal observed. Prospect only if the website audit shows a real gap.",
                    stage="intent", meta={"business_search": q})
        db.add(lead)
        db.flush()
        new.append(lead.id)
    return AgentResult("ok", f"{len(new)} companies added", {"new_lead_ids": new})


def add_manual(db: Session, *, url: str | None, text: str | None, name: str | None, company: str | None, website: str | None) -> Lead:
    seed = url or website or f"manual:{(text or '')[:200]}:{name}:{company}"
    key = dedupe_key(seed if "//" in seed else "manual://" + hashlib.sha1(seed.encode()).hexdigest())
    ex = db.execute(select(Lead).where(Lead.dedupe_key == key)).scalar_one_or_none()
    if ex:
        return ex
    lead = Lead(dedupe_key=key, source_type="manual", source_url=url, source_text=text, name=name, company_name=company,
                stage="discovered", discovered_via="manually added", meta={"website": website} if website else {})
    db.add(lead)
    db.flush()
    return lead
