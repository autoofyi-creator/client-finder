"""Email Finder Agent. Sources: addresses published on the company's own pages, Hunter, Snov. Never guesses patterns."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.base import AgentResult
from integrations import hunter, snov
from integrations.base import IntegrationError, NotConfigured
from models.orm import Company, Contact, Lead
from services import htmlx, http
from services.email_checks import extract_emails


def _add(db: Session, lead: Lead, email: str, source: str, name=None, title=None) -> bool:
    email = email.lower().strip()
    if db.execute(select(Contact.id).where(Contact.lead_id == lead.id, Contact.email == email)).first():
        return False
    db.add(Contact(lead_id=lead.id, company_id=lead.company_id, name=name, title=title, email=email, email_source=source[:1000],
                   email_status="UNKNOWN", is_sample=lead.is_sample,
                   is_decision_maker=bool(title and any(k in title.lower() for k in ("founder", "ceo", "owner", "director", "marketing")))))
    db.flush()  # autoflush is off: make the duplicate check above see rows added earlier in this run
    return True


def run(db: Session, lead: Lead) -> AgentResult:
    company = db.get(Company, lead.company_id) if lead.company_id else None
    if not company or not company.domain:
        return AgentResult("skipped", "No company domain known")
    domain, added, notes = company.domain, 0, []
    # 1) public pages of the company's own site
    home = http.safe_get(company.website_url or f"https://{domain}/")
    pages = [home] if home.ok else []
    if home.ok:
        for link in htmlx.same_site_links(htmlx.soup(home.text), home.final_url or home.url, limit=3):
            r = http.safe_get(link)
            if r.ok:
                pages.append(r)
    for p in pages:
        s = htmlx.soup(p.text)
        found = set(extract_emails(p.text))
        for a in s.find_all("a", href=True):
            if a["href"].lower().startswith("mailto:"):
                found.update(extract_emails(a["href"][7:].split("?")[0]))
        for e in found:
            if e.endswith("@" + domain) or e.endswith("." + domain):
                added += _add(db, lead, e, f"published on {p.final_url or p.url}")
    # 2) providers
    if hunter.configured():
        try:
            for e in hunter.domain_search(domain):
                if e["email"]:
                    added += _add(db, lead, e["email"], f"hunter ({e.get('sources') or 'database'})",
                                  " ".join(filter(None, [e.get("first_name"), e.get("last_name")])) or None, e.get("position"))
        except (IntegrationError, NotConfigured) as e:
            notes.append(str(e))
    if snov.configured():
        try:
            for e in snov.domain_emails(domain):
                added += _add(db, lead, e["email"], "snov", " ".join(filter(None, [e.get("first_name"), e.get("last_name")])) or None, e.get("position"))
        except (IntegrationError, NotConfigured) as e:
            notes.append(str(e))
    if not (hunter.configured() or snov.configured()):
        notes.append("No email provider connected: only addresses published on the company site were collected")
    return AgentResult("ok" if not notes or added else "skipped", f"{added} candidate emails found (all unverified until checked)", {"added": added, "notes": notes})
