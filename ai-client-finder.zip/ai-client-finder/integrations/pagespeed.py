from __future__ import annotations

from config import env
from integrations.base import IntegrationError
from services import http


def run(url: str) -> dict:
    params = {"url": url, "strategy": "mobile", "category": "performance"}
    if env("PAGESPEED_API_KEY"):
        params["key"] = env("PAGESPEED_API_KEY")
    try:
        with http.client(60) as c:
            r = c.get("https://www.googleapis.com/pagespeedonline/v5/runPagespeed", params=params)
        r.raise_for_status()
        lh = r.json().get("lighthouseResult", {})
        audits = lh.get("audits", {})
        score = lh.get("categories", {}).get("performance", {}).get("score")
        return {"mobile_performance_score": None if score is None else round(score * 100),
                "lcp": audits.get("largest-contentful-paint", {}).get("displayValue"),
                "cls": audits.get("cumulative-layout-shift", {}).get("displayValue"),
                "tbt": audits.get("total-blocking-time", {}).get("displayValue")}
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"PageSpeed error: {type(e).__name__}") from e
