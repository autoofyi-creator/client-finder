class NotConfigured(Exception):
    """Integration has no credentials; callers mark the stage 'skipped' rather than failing."""


class IntegrationError(Exception):
    pass
