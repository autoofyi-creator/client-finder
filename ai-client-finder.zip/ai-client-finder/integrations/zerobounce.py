from __future__ import annotations

from config import env
from integrations.base import IntegrationError, NotConfigured
from services import http


def configured() -> bool:
    return bool(env("ZEROBOUNCE_API_KEY"))


def verify(email: str) -> dict:
    if not configured():
        raise NotConfigured("ZEROBOUNCE_API_KEY not set")
    try:
        with http.client(25) as c:
            r = c.get("https://api.zerobounce.net/v2/validate", params={"api_key": env("ZEROBOUNCE_API_KEY"), "email": email})
        r.raise_for_status()
        d = r.json()
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"ZeroBounce error: {type(e).__name__}") from e
    if d.get("error"):
        raise IntegrationError(f"ZeroBounce: {d['error']}")
    return {"provider": "zerobounce", "raw_status": d.get("status"), "sub_status": d.get("sub_status")}
