from __future__ import annotations

from config import env
from integrations.base import IntegrationError, NotConfigured
from services import http

BASE = "https://api.hunter.io/v2"


def configured() -> bool:
    return bool(env("HUNTER_API_KEY"))


def _get(path: str, **params) -> dict:
    if not configured():
        raise NotConfigured("HUNTER_API_KEY not set")
    try:
        with http.client(25) as c:
            r = c.get(BASE + path, params=params, headers={"X-API-KEY": env("HUNTER_API_KEY")})
        if r.status_code in (401, 403):
            raise IntegrationError("Hunter rejected the API key")
        if r.status_code == 429:
            raise IntegrationError("Hunter rate/credit limit reached")
        r.raise_for_status()
        return r.json().get("data") or {}
    except IntegrationError:
        raise
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"Hunter error: {type(e).__name__}") from e


def domain_search(domain: str, limit: int = 5) -> list[dict]:
    data = _get("/domain-search", domain=domain, limit=limit)
    out = []
    for e in data.get("emails", []):
        out.append({"email": e.get("value"), "first_name": e.get("first_name"), "last_name": e.get("last_name"),
                    "position": e.get("position"), "type": e.get("type"), "confidence": e.get("confidence"),
                    "sources": [s.get("uri") for s in (e.get("sources") or [])[:2]]})
    return out


def email_finder(domain: str, first_name: str, last_name: str) -> dict | None:
    data = _get("/email-finder", domain=domain, first_name=first_name, last_name=last_name)
    return {"email": data["email"], "score": data.get("score")} if data.get("email") else None


def verify(email: str) -> dict:
    d = _get("/email-verifier", email=email)
    return {"provider": "hunter", "raw_status": d.get("status"), "score": d.get("score"), "accept_all": d.get("accept_all")}
