"""Snov.io v2 async API (start -> poll result). Written from Snov's public docs; verify against your account."""
from __future__ import annotations

import time

from config import env
from integrations.base import IntegrationError, NotConfigured
from services import http

BASE = "https://api.snov.io"


def configured() -> bool:
    return bool(env("SNOV_CLIENT_ID") and env("SNOV_CLIENT_SECRET"))


def _token(c) -> str:
    r = c.post(f"{BASE}/v1/oauth/access_token", data={"grant_type": "client_credentials",
               "client_id": env("SNOV_CLIENT_ID"), "client_secret": env("SNOV_CLIENT_SECRET")})
    r.raise_for_status()
    tok = r.json().get("access_token")
    if not tok:
        raise IntegrationError("Snov did not return an access token")
    return tok


def _async(c, tok: str, start_path: str, data: dict, result_path: str, wait: float = 12.0) -> dict:
    h = {"Authorization": f"Bearer {tok}"}
    r = c.post(BASE + start_path, data=data, headers=h)
    r.raise_for_status()
    task = (r.json().get("meta") or {}).get("task_hash") or r.json().get("task_hash")
    if not task:
        raise IntegrationError("Snov start call returned no task_hash")
    deadline = time.monotonic() + wait
    while time.monotonic() < deadline:
        rr = c.get(BASE + result_path.format(task=task), headers=h)
        rr.raise_for_status()
        j = rr.json()
        if j.get("status") in ("completed", "complete", "done") or j.get("data"):
            return j
        time.sleep(1.5)
    raise IntegrationError("Snov result not ready in time")


def domain_emails(domain: str) -> list[dict]:
    if not configured():
        raise NotConfigured("Snov credentials not set")
    try:
        with http.client(30) as c:
            j = _async(c, _token(c), "/v2/domain-search/domain-emails/start", {"domain": domain},
                       "/v2/domain-search/domain-emails/result/{task}")
    except IntegrationError:
        raise
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"Snov error: {type(e).__name__}") from e
    out = []
    for e in j.get("data") or []:
        addr = e.get("email") or e.get("value")
        if addr:
            out.append({"email": addr, "first_name": e.get("first_name"), "last_name": e.get("last_name"),
                        "position": e.get("position"), "status": (e.get("smtp_status") or e.get("status"))})
    return out


def verify(email: str) -> dict:
    if not configured():
        raise NotConfigured("Snov credentials not set")
    try:
        with http.client(30) as c:
            j = _async(c, _token(c), "/v2/email-verification/start", {"emails[]": email},
                       "/v2/email-verification/result?task_hash={task}")
    except IntegrationError:
        raise
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"Snov error: {type(e).__name__}") from e
    rows = j.get("data") or []
    first = rows[0] if rows else {}
    res = first.get("result") if isinstance(first.get("result"), dict) else first
    raw = res.get("smtp_status") or res.get("status") or "unknown"
    return {"provider": "snov", "raw_status": raw}
