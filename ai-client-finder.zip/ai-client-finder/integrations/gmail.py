"""Gmail via official OAuth 2.0 + REST API. Refresh token is stored encrypted in the settings table."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
from email.message import EmailMessage
from email.utils import parseaddr, parsedate_to_datetime
from urllib.parse import urlencode

from sqlalchemy.orm import Session

from config import env
from integrations.base import IntegrationError, NotConfigured
from services import crypto, http
from services import settings_store as ss
from models.orm import Setting

SCOPES = ["https://www.googleapis.com/auth/gmail.send", "https://www.googleapis.com/auth/gmail.compose",
          "https://www.googleapis.com/auth/gmail.readonly"]
API = "https://gmail.googleapis.com/gmail/v1/users/me"
TOKEN_KEY = "gmail_refresh_token_enc"


def credentials_present() -> bool:
    return bool(env("GOOGLE_CLIENT_ID") and env("GOOGLE_CLIENT_SECRET"))


def authorize_url(redirect_uri: str, state: str) -> str:
    q = {"client_id": env("GOOGLE_CLIENT_ID"), "redirect_uri": redirect_uri, "response_type": "code",
         "scope": " ".join(SCOPES), "access_type": "offline", "prompt": "consent", "state": state}
    return "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(q)


def exchange_code(db: Session, code: str, redirect_uri: str) -> None:
    with http.client(20) as c:
        r = c.post("https://oauth2.googleapis.com/token", data={
            "code": code, "client_id": env("GOOGLE_CLIENT_ID"), "client_secret": env("GOOGLE_CLIENT_SECRET"),
            "redirect_uri": redirect_uri, "grant_type": "authorization_code"})
    if r.status_code != 200 or "refresh_token" not in r.json():
        raise IntegrationError("Google did not return a refresh token; revoke the app's access and retry")
    ss.set_value(db, TOKEN_KEY, crypto.encrypt(r.json()["refresh_token"]))
    try:
        prof = _api(db, "GET", "/profile", access=r.json()["access_token"])
        ss.set_value(db, "gmail_address", prof.get("emailAddress"))
    except IntegrationError:
        pass


def is_connected(db: Session) -> bool:
    row = db.get(Setting, TOKEN_KEY)
    return bool(row and row.value)


def disconnect(db: Session) -> None:
    ss.set_value(db, TOKEN_KEY, None)
    ss.set_value(db, "gmail_address", None)


def _access_token(db: Session) -> str:
    row = db.get(Setting, TOKEN_KEY)
    if not (credentials_present() and row and row.value):
        raise NotConfigured("Gmail is not connected")
    with http.client(20) as c:
        r = c.post("https://oauth2.googleapis.com/token", data={
            "client_id": env("GOOGLE_CLIENT_ID"), "client_secret": env("GOOGLE_CLIENT_SECRET"),
            "refresh_token": crypto.decrypt(row.value), "grant_type": "refresh_token"})
    if r.status_code != 200:
        raise IntegrationError("Gmail token refresh failed (token revoked or expired; reconnect Gmail)")
    return r.json()["access_token"]


def _api(db: Session, method: str, path: str, *, json=None, params=None, access: str | None = None) -> dict:
    token = access or _access_token(db)
    with http.client(30) as c:
        r = c.request(method, API + path, json=json, params=params, headers={"Authorization": f"Bearer {token}"})
    if r.status_code >= 400:
        raise IntegrationError(f"Gmail API {r.status_code}: {r.text[:200]}")
    return r.json()


def build_raw(to: str, subject: str, body: str, sender: str | None = None, in_reply_to: str | None = None) -> str:
    m = EmailMessage()
    m["To"] = to
    m["Subject"] = subject
    if sender:
        m["From"] = sender
    if in_reply_to:
        m["In-Reply-To"] = in_reply_to
        m["References"] = in_reply_to
    m.set_content(body)
    return base64.urlsafe_b64encode(m.as_bytes()).decode()


def create_draft(db: Session, to: str, subject: str, body: str, thread_id: str | None = None) -> dict:
    msg = {"raw": build_raw(to, subject, body)}
    if thread_id:
        msg["threadId"] = thread_id
    d = _api(db, "POST", "/drafts", json={"message": msg})
    return {"draft_id": d.get("id"), "thread_id": (d.get("message") or {}).get("threadId")}


def send(db: Session, to: str, subject: str, body: str, thread_id: str | None = None) -> dict:
    msg = {"raw": build_raw(to, subject, body)}
    if thread_id:
        msg["threadId"] = thread_id
    d = _api(db, "POST", "/messages/send", json=msg)
    return {"message_id": d.get("id"), "thread_id": d.get("threadId")}


def list_inbox(db: Session, newer_than_days: int = 14, max_results: int = 50) -> list[dict]:
    ids = _api(db, "GET", "/messages", params={"q": f"in:inbox newer_than:{newer_than_days}d", "maxResults": max_results}).get("messages", [])
    out = []
    for m in ids:
        d = _api(db, "GET", f"/messages/{m['id']}", params={"format": "metadata", "metadataHeaders": ["From", "Subject", "Date"]})
        hdr = {h["name"].lower(): h["value"] for h in d.get("payload", {}).get("headers", [])}
        try:
            when = parsedate_to_datetime(hdr["date"]).astimezone(timezone.utc) if "date" in hdr else None
        except Exception:  # noqa: BLE001
            when = None
        out.append({"id": d["id"], "thread_id": d.get("threadId"), "from": parseaddr(hdr.get("from", ""))[1].lower(),
                    "subject": hdr.get("subject", ""), "snippet": d.get("snippet", ""), "date": when,
                    "labels": d.get("labelIds", [])})
    return out
