"""Keyless public sources: Hacker News (Algolia API) and user-configured RSS/Atom feeds."""
from __future__ import annotations

import html
import re
from datetime import datetime, timezone

import feedparser

from integrations.base import IntegrationError
from integrations.search import SearchHit
from services import http


def _strip(t: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", " ", t or "")).strip()


def hacker_news(query: str, limit: int = 15) -> list[dict]:
    try:
        with http.client(15) as c:
            r = c.get("https://hn.algolia.com/api/v1/search_by_date",
                      params={"query": query.replace('"', ""), "tags": "(comment,story)", "hitsPerPage": limit})
            r.raise_for_status()
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"Hacker News search failed: {type(e).__name__}") from e
    out = []
    for h in r.json().get("hits", []):
        text = _strip(h.get("comment_text") or h.get("story_text") or h.get("title") or "")
        if not text:
            continue
        d = None
        if h.get("created_at"):
            d = datetime.fromisoformat(h["created_at"].replace("Z", "+00:00"))
        out.append({"hit": SearchHit(h.get("story_title") or h.get("title") or "Hacker News post",
                                     f"https://news.ycombinator.com/item?id={h['objectID']}", text[:1500], d, "hackernews"),
                    "author": h.get("author")})
    return out


def rss(feed_url: str, limit: int = 30) -> list[SearchHit]:
    res = http.safe_get(feed_url, respect_robots=False)
    if not res.ok:
        raise IntegrationError(f"RSS fetch failed for {feed_url}: {res.error or res.status}")
    parsed = feedparser.parse(res.text)
    out = []
    for e in parsed.entries[:limit]:
        d = None
        if getattr(e, "published_parsed", None):
            d = datetime(*e.published_parsed[:6], tzinfo=timezone.utc)
        out.append(SearchHit(e.get("title", ""), e.get("link", ""), _strip(e.get("summary", ""))[:1500], d, "rss"))
    return out
