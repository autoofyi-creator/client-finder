"""Web search providers (Serper / Tavily / Brave) normalised to SearchHit."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from config import env, search_provider
from integrations.base import IntegrationError, NotConfigured
from services import http


@dataclass
class SearchHit:
    title: str
    url: str
    snippet: str
    date: Optional[datetime] = None
    provider: str = ""


def parse_date(s) -> Optional[datetime]:
    if not s or not isinstance(s, str):
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d", "%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(s.strip(), fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    try:  # ISO with offset
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None  # relative dates ("3 days ago") are NOT guessed


def search(query: str, num: int = 10, recent: bool = True) -> list[SearchHit]:
    prov = search_provider()
    if not prov:
        raise NotConfigured("No search API key set (SERPER_API_KEY, TAVILY_API_KEY or BRAVE_SEARCH_API_KEY)")
    try:
        with http.client(20) as c:
            if prov == "serper":
                body = {"q": query, "num": num}
                if recent:
                    body["tbs"] = "qdr:y"
                r = c.post("https://google.serper.dev/search", json=body, headers={"X-API-KEY": env("SERPER_API_KEY")})
                r.raise_for_status()
                return [SearchHit(x.get("title", ""), x.get("link", ""), x.get("snippet", ""), parse_date(x.get("date")), prov)
                        for x in r.json().get("organic", []) if x.get("link")]
            if prov == "tavily":
                r = c.post("https://api.tavily.com/search", json={"query": query, "max_results": min(num, 20)},
                           headers={"Authorization": f"Bearer {env('TAVILY_API_KEY')}"})
                r.raise_for_status()
                return [SearchHit(x.get("title", ""), x.get("url", ""), x.get("content", ""), parse_date(x.get("published_date")), prov)
                        for x in r.json().get("results", []) if x.get("url")]
            r = c.get("https://api.search.brave.com/res/v1/web/search", params={"q": query, "count": min(num, 20)},
                      headers={"X-Subscription-Token": env("BRAVE_SEARCH_API_KEY"), "Accept": "application/json"})
            r.raise_for_status()
            return [SearchHit(x.get("title", ""), x.get("url", ""), x.get("description", ""), parse_date(x.get("page_age")), prov)
                    for x in r.json().get("web", {}).get("results", []) if x.get("url")]
    except Exception as e:  # noqa: BLE001
        raise IntegrationError(f"{prov} search failed: {type(e).__name__}: {e}") from e
