"""Pydantic request models (input validation)."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, HttpUrl, field_validator

from config import SERVICES


class LoginIn(BaseModel):
    password: str = Field(min_length=1, max_length=500)


class DiscoveryIn(BaseModel):
    queries: Optional[list[str]] = Field(default=None, max_length=20)
    queries_per_run: Optional[int] = Field(default=None, ge=1, le=20)
    hn: bool = True


class BusinessDiscoveryIn(BaseModel):
    category: str = Field(min_length=2, max_length=100)
    location: str = Field(default="", max_length=100)


class ManualLeadIn(BaseModel):
    url: Optional[HttpUrl] = None
    text: Optional[str] = Field(default=None, max_length=5000)
    name: Optional[str] = Field(default=None, max_length=200)
    company: Optional[str] = Field(default=None, max_length=200)
    website: Optional[str] = Field(default=None, max_length=500)

    @field_validator("text", "name", "company", "website")
    @classmethod
    def blank_to_none(cls, v):
        return v.strip() or None if isinstance(v, str) else v


class SettingsIn(BaseModel):
    require_approval: Optional[bool] = None
    daily_send_limit: Optional[int] = Field(default=None, ge=0, le=500)
    allowed_email_statuses: Optional[list[Literal["VERIFIED", "RISKY", "CATCH-ALL", "UNKNOWN"]]] = None
    sender_name: Optional[str] = Field(default=None, max_length=200)
    sender_title: Optional[str] = Field(default=None, max_length=200)
    business_name: Optional[str] = Field(default=None, max_length=200)
    postal_address: Optional[str] = Field(default=None, max_length=500)
    website_url: Optional[str] = Field(default=None, max_length=300)
    search_queries: Optional[list[str]] = Field(default=None, max_length=40)
    target_countries: Optional[list[str]] = Field(default=None, max_length=50)
    rss_feeds: Optional[list[HttpUrl]] = Field(default=None, max_length=20)
    min_intent_for_enrichment: Optional[Literal["HIGH", "MEDIUM", "LOW"]] = None
    followup_days: Optional[int] = Field(default=None, ge=1, le=60)
    max_followups: Optional[int] = Field(default=None, ge=0, le=5)
    queries_per_run: Optional[int] = Field(default=None, ge=1, le=20)
    enable_hn: Optional[bool] = None
    max_lead_age_days: Optional[int] = Field(default=None, ge=7, le=730)
    auto_discovery_on_cron: Optional[bool] = None


class GenerateIn(BaseModel):
    lead_id: int
    service: Literal[tuple(SERVICES.keys())]  # type: ignore[valid-type]
    channel: Literal["email", "linkedin"] = "email"
    contact_id: Optional[int] = None


class MessageEditIn(BaseModel):
    subject: Optional[str] = Field(default=None, max_length=480)
    body: str = Field(min_length=1, max_length=8000)


class LeadStatusIn(BaseModel):
    status: Literal["new", "qualified", "contacted", "replied", "interested", "meeting", "converted", "lost", "suppressed"]


class SuppressIn(BaseModel):
    email: Optional[str] = Field(default=None, max_length=320)
    domain: Optional[str] = Field(default=None, max_length=255)
    reason: str = Field(default="manual", max_length=50)


class AuditIn(BaseModel):
    url: str = Field(min_length=3, max_length=500)
    company_id: Optional[int] = None
