"""SQLAlchemy models. Agents communicate only through these records."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


INTENTS = ["HIGH", "MEDIUM", "LOW", "NONE", "UNCLASSIFIED"]
EMAIL_STATUSES = ["VERIFIED", "RISKY", "INVALID", "CATCH-ALL", "UNKNOWN"]
LEAD_STATUSES = ["new", "qualified", "contacted", "replied", "interested", "meeting", "converted", "lost", "suppressed", "discarded"]
STAGES = ["discovered", "intent", "research", "linkedin", "email_find", "email_verify", "audit", "scoring", "messaging", "complete"]


def as_dict(obj: Any) -> dict:
    out = {}
    for c in obj.__table__.columns:
        v = getattr(obj, c.name)
        out[c.name] = v.isoformat() if isinstance(v, datetime) else v
    return out


class Company(Base):
    __tablename__ = "companies"
    id: Mapped[int] = mapped_column(primary_key=True)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    name: Mapped[str] = mapped_column(String(300))
    domain: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    website_url: Mapped[Optional[str]] = mapped_column(String(1000))
    country: Mapped[Optional[str]] = mapped_column(String(100))
    description: Mapped[Optional[str]] = mapped_column(Text)
    linkedin_url: Mapped[Optional[str]] = mapped_column(String(1000))
    research: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    leads: Mapped[list["Lead"]] = relationship(back_populates="company")


class Lead(Base):
    __tablename__ = "leads"
    id: Mapped[int] = mapped_column(primary_key=True)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    dedupe_key: Mapped[str] = mapped_column(String(64), unique=True)
    source_type: Mapped[str] = mapped_column(String(50), default="manual")
    source_url: Mapped[Optional[str]] = mapped_column(String(2000))
    source_title: Mapped[Optional[str]] = mapped_column(String(500))
    source_text: Mapped[Optional[str]] = mapped_column(Text)
    source_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    discovered_via: Mapped[Optional[str]] = mapped_column(String(300))
    name: Mapped[Optional[str]] = mapped_column(String(300))
    name_is_handle: Mapped[bool] = mapped_column(Boolean, default=False)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), index=True)
    company_name: Mapped[Optional[str]] = mapped_column(String(300))
    country: Mapped[Optional[str]] = mapped_column(String(100))
    service_needed: Mapped[Optional[str]] = mapped_column(String(50))
    intent: Mapped[str] = mapped_column(String(20), default="UNCLASSIFIED", index=True)
    confidence: Mapped[Optional[float]] = mapped_column(Float)
    intent_method: Mapped[Optional[str]] = mapped_column(String(20))  # claude | heuristic
    evidence_quote: Mapped[Optional[str]] = mapped_column(Text)
    intent_reason: Mapped[Optional[str]] = mapped_column(Text)
    approach: Mapped[Optional[str]] = mapped_column(Text)
    score: Mapped[Optional[int]] = mapped_column(Integer, index=True)
    score_breakdown: Mapped[Optional[dict]] = mapped_column(JSON)
    stage: Mapped[str] = mapped_column(String(30), default="discovered", index=True)
    status: Mapped[str] = mapped_column(String(30), default="new", index=True)
    meta: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    last_error: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    company: Mapped[Optional[Company]] = relationship(back_populates="leads")
    contacts: Mapped[list["Contact"]] = relationship(back_populates="lead", cascade="all, delete-orphan")


class Contact(Base):
    __tablename__ = "contacts"
    id: Mapped[int] = mapped_column(primary_key=True)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id"), index=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"))
    name: Mapped[Optional[str]] = mapped_column(String(300))
    title: Mapped[Optional[str]] = mapped_column(String(300))
    is_decision_maker: Mapped[bool] = mapped_column(Boolean, default=False)
    linkedin_url: Mapped[Optional[str]] = mapped_column(String(1000))
    linkedin_note: Mapped[Optional[str]] = mapped_column(Text)  # what the public snippet said (unverified)
    email: Mapped[Optional[str]] = mapped_column(String(320), index=True)
    email_source: Mapped[Optional[str]] = mapped_column(String(1000))
    email_status: Mapped[str] = mapped_column(String(20), default="UNKNOWN", index=True)
    verification: Mapped[Optional[dict]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    lead: Mapped[Lead] = relationship(back_populates="contacts")


class Audit(Base):
    __tablename__ = "audits"
    id: Mapped[int] = mapped_column(primary_key=True)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), index=True)
    lead_id: Mapped[Optional[int]] = mapped_column(ForeignKey("leads.id"), index=True)
    url: Mapped[str] = mapped_column(String(1000))
    reachable: Mapped[bool] = mapped_column(Boolean, default=False)
    status_code: Mapped[Optional[int]] = mapped_column(Integer)
    load_ms: Mapped[Optional[int]] = mapped_column(Integer)
    findings: Mapped[Optional[list]] = mapped_column(JSON)
    pagespeed: Mapped[Optional[dict]] = mapped_column(JSON)
    summary: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Message(Base):
    __tablename__ = "messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id"), index=True)
    contact_id: Mapped[Optional[int]] = mapped_column(ForeignKey("contacts.id"))
    channel: Mapped[str] = mapped_column(String(30))  # email | linkedin_connect | linkedin_message | linkedin_followup
    service: Mapped[Optional[str]] = mapped_column(String(50))
    subject: Mapped[Optional[str]] = mapped_column(String(500))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="draft", index=True)
    generated_by: Mapped[Optional[str]] = mapped_column(String(20))  # claude | template | human
    facts_used: Mapped[Optional[list]] = mapped_column(JSON)
    followup_of: Mapped[Optional[int]] = mapped_column(Integer)
    sequence_no: Mapped[int] = mapped_column(Integer, default=0)
    to_email: Mapped[Optional[str]] = mapped_column(String(320))
    gmail_draft_id: Mapped[Optional[str]] = mapped_column(String(200))
    gmail_message_id: Mapped[Optional[str]] = mapped_column(String(200))
    thread_id: Mapped[Optional[str]] = mapped_column(String(200), index=True)
    error: Mapped[Optional[str]] = mapped_column(Text)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Reply(Base):
    __tablename__ = "replies"
    id: Mapped[int] = mapped_column(primary_key=True)
    lead_id: Mapped[Optional[int]] = mapped_column(ForeignKey("leads.id"), index=True)
    message_id: Mapped[Optional[int]] = mapped_column(ForeignKey("messages.id"))
    gmail_message_id: Mapped[str] = mapped_column(String(200), unique=True)
    thread_id: Mapped[Optional[str]] = mapped_column(String(200))
    from_email: Mapped[Optional[str]] = mapped_column(String(320))
    subject: Mapped[Optional[str]] = mapped_column(String(500))
    snippet: Mapped[Optional[str]] = mapped_column(Text)
    classification: Mapped[Optional[str]] = mapped_column(String(30), index=True)
    method: Mapped[Optional[str]] = mapped_column(String(20))
    summary: Mapped[Optional[str]] = mapped_column(Text)
    received_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Suppression(Base):
    __tablename__ = "suppressions"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[Optional[str]] = mapped_column(String(320), unique=True)
    domain: Mapped[Optional[str]] = mapped_column(String(255), unique=True)
    reason: Mapped[str] = mapped_column(String(50), default="manual")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(50))
    payload: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="queued", index=True)  # queued running done failed
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    result: Mapped[Optional[dict]] = mapped_column(JSON)
    error: Mapped[Optional[str]] = mapped_column(Text)
    run_after: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


class AgentRun(Base):
    __tablename__ = "agent_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    agent: Mapped[str] = mapped_column(String(50), index=True)
    lead_id: Mapped[Optional[int]] = mapped_column(Integer, index=True)
    job_id: Mapped[Optional[int]] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20))  # ok | skipped | error
    message: Mapped[Optional[str]] = mapped_column(Text)
    details: Mapped[Optional[dict]] = mapped_column(JSON)
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[Optional[Any]] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


def aware(dt: Optional[datetime]) -> Optional[datetime]:
    """SQLite returns naive datetimes; treat them as UTC."""
    if dt is not None and dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt
