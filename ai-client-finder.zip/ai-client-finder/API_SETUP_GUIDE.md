# API Setup Guide

Never paste secret keys into chat, tickets or git. Put them in **Vercel > Project > Settings > Environment Variables** (or a local `.env`), then redeploy/restart. The dashboard's **API Integrations** page shows each status without ever displaying a key.

Do them in this order. Only steps 1-2 are required.

## 1. App security (required)
Generate three random values (run three times): `python -c "import secrets;print(secrets.token_urlsafe(32))"`
- `ADMIN_PASSWORD`: the password you type to sign in (choose something long)
- `SECRET_KEY`: signs session cookies and encrypts the stored Gmail token (16+ characters; changing it later signs you out and requires reconnecting Gmail)
- `CRON_SECRET`: lets Vercel Cron call `/api/cron/tick`

## 2. Supabase / PostgreSQL (required)
1. https://supabase.com/dashboard > New project (free plan, no card). Save the database password.
2. Project Settings > Database > Connection string > **Transaction pooler** (port 6543) > URI. Replace `[YOUR-PASSWORD]`.
3. Set it as `DATABASE_URL`.

## 3. Anthropic Claude (recommended)
1. https://console.anthropic.com/ > add credits (prepaid, card required) > API Keys > Create key.
2. Set `ANTHROPIC_API_KEY`. Optional `ANTHROPIC_MODEL` (default `claude-sonnet-5-5`).
3. Integrations page > Test connection. Set a spend limit in the Anthropic console.

## 4. A search API (recommended, pick one)
- **Serper** (no card, about 2,500 free queries): https://serper.dev > API key > `SERPER_API_KEY`
- **Tavily** (no card, about 1,000 credits/month): https://app.tavily.com > `TAVILY_API_KEY`
- **Brave** (card required even for the $5 monthly credit; attribution required): https://api-dashboard.search.brave.com > `BRAVE_SEARCH_API_KEY`

If several are set the order is Serper, Tavily, Brave.

## 5. Email finding / verification (optional)
- **Hunter** (50 free credits/month, API included): https://hunter.io > API > `HUNTER_API_KEY`
- **ZeroBounce**: https://www.zerobounce.net > API > `ZEROBOUNCE_API_KEY`
- **Snov.io**: https://snov.io > Account > API > `SNOV_CLIENT_ID`, `SNOV_CLIENT_SECRET` (check that your plan includes API access)

With none connected the app still works: it collects emails published on company sites and leaves them `UNKNOWN` (not sendable by default).

## 6. Gmail (needed only for drafts, sending, reply tracking)
1. https://console.cloud.google.com > create a project > **APIs & Services > Library > Gmail API > Enable**.
2. **OAuth consent screen**: External; add yourself as a test user; add scopes `gmail.send`, `gmail.compose`, `gmail.readonly`.
3. **Credentials > Create credentials > OAuth client ID > Web application**. Authorised redirect URIs: `https://YOUR-APP.vercel.app/api/gmail/callback` (and `http://localhost:8000/api/gmail/callback` for local).
4. Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`; redeploy; Integrations > **Connect Gmail**.
5. While the consent screen is in *Testing*, Google expires the refresh token after 7 days. Set the publishing status to *In production* (you will see an "unverified app" warning for your own account, which is expected for personal use).

## 7. PageSpeed Insights (optional)
Enable "PageSpeed Insights API" in the same Google Cloud project > Credentials > API key > `PAGESPEED_API_KEY`.

## 8. LinkedIn
No setup. LinkedIn provides no general-purpose official API for prospect search or messaging. The app finds public profile snippets through your search API and prepares messages; you open the profile and send them yourself.
