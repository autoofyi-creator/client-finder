import json
from datetime import timedelta
from pathlib import Path

import httpx
import pytest

ROOT = Path(__file__).resolve().parent.parent


def make_lead_with_contact(db, email="owner@acme.test", status="VERIFIED", sample=False, key="L1"):
    from models.orm import Company, Contact, Lead
    co = Company(name="Acme", domain="acme.test", website_url="https://acme.test/", is_sample=sample)
    db.add(co); db.flush()
    lead = Lead(dedupe_key=key, company_id=co.id, company_name="Acme", name="Jo Bloggs", intent="HIGH", service_needed="seo", status="qualified",
                source_url="https://forum.test/1", evidence_quote="need an SEO expert", is_sample=sample, stage="complete")
    db.add(lead); db.flush()
    c = Contact(lead_id=lead.id, company_id=co.id, name="Jo Bloggs", title="Owner", email=email, email_status=status, is_sample=sample, is_decision_maker=True)
    db.add(c); db.flush()
    return lead, c


def configure_sender(db):
    from services import settings_store as ss
    ss.set_value(db, "sender_name", "Sam Sender")
    ss.set_value(db, "postal_address", "1 High Street, Town, AB1 2CD")


# ---------- message writer ----------
def test_email_template_is_specific_and_has_footer(db):
    from agents import message_writer
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = message_writer.write_email(db, lead, c, "seo")
    assert m.generated_by == "template" and m.status == "pending_approval" and m.to_email == c.email
    assert "need an SEO expert" in m.body and "Jo" in m.body and "unsubscribe" in m.body.lower() and "1 High Street" in m.body
    assert m.subject and "SEO" in m.subject


def test_claude_draft_rejected_if_it_ignores_facts(db, monkeypatch):
    from agents import message_writer as mw
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    monkeypatch.setattr(mw.llm, "complete_json", lambda *a, **k: mw.EmailDraft(subject="Hi", body="Generic spam body about nothing"))
    lead, c = make_lead_with_contact(db)
    assert mw.write_email(db, lead, c, "seo").generated_by == "template"  # fell back
    monkeypatch.setattr(mw.llm, "complete_json", lambda *a, **k: mw.EmailDraft(subject="SEO for Acme", body="Hi Jo, saw Acme needs SEO. Call?", facts_used=["company"]))
    m = mw.write_email(db, lead, c, "seo")
    assert m.generated_by == "claude" and "unsubscribe" in m.body.lower()  # footer added by code, not by the model


def test_linkedin_messages_respect_limit(db):
    from agents import message_writer as mw
    lead, c = make_lead_with_contact(db)
    c.linkedin_url = "https://www.linkedin.com/in/jo"
    ms = mw.write_linkedin(db, lead, c, "seo")
    assert [m.channel for m in ms] == ["linkedin_connect", "linkedin_message", "linkedin_followup"]
    assert len(ms[0].body) <= 300 and all(m.status == "pending_approval" for m in ms)


def test_linkedin_title_parsing():
    from agents.linkedin_research import parse_profile_title
    assert parse_profile_title("Jane Doe - Founder - Acme | LinkedIn") == ("Jane Doe", "Founder")


# ---------- outreach gates ----------
@pytest.fixture
def gmail_ok(db, monkeypatch):
    from integrations import gmail
    sent = []
    monkeypatch.setenv("GOOGLE_CLIENT_ID", "a"); monkeypatch.setenv("GOOGLE_CLIENT_SECRET", "b")
    monkeypatch.setattr(gmail, "is_connected", lambda d: True)
    monkeypatch.setattr(gmail, "send", lambda d, to, s, b, t=None: sent.append(to) or {"message_id": f"m{len(sent)}", "thread_id": f"t{len(sent)}"})
    monkeypatch.setattr(gmail, "create_draft", lambda d, to, s, b, t=None: {"draft_id": "d1", "thread_id": "t1"})
    return sent


def test_happy_path_requires_approval_then_sends(db, gmail_ok):
    from agents import message_writer as mw, outreach
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo")
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, m)
    assert any("approved" in r for r in e.value.reasons) and gmail_ok == []
    outreach.approve(db, m)
    outreach.send(db, m)
    assert m.status == "sent" and gmail_ok == ["owner@acme.test"] and lead.status == "contacted" and m.thread_id == "t1"


@pytest.mark.parametrize("status", ["INVALID", "UNKNOWN", "RISKY", "CATCH-ALL"])
def test_non_verified_emails_blocked(db, gmail_ok, status):
    from agents import message_writer as mw, outreach
    configure_sender(db)
    lead, c = make_lead_with_contact(db, status=status)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m)
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, m)
    assert any(status in r for r in e.value.reasons) and gmail_ok == []


def test_suppressed_address_and_domain_blocked(db, gmail_ok):
    from agents import message_writer as mw, outreach
    from services.suppression import suppress
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m)
    suppress(db, domain="acme.test", reason="unsubscribed")
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, m)
    assert any("suppressed" in r.lower() for r in e.value.reasons) and gmail_ok == []


def test_sample_data_can_never_be_sent(db, gmail_ok):
    from agents import message_writer as mw, outreach
    configure_sender(db)
    lead, c = make_lead_with_contact(db, sample=True)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m)
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, m)
    assert any("Sample" in r for r in e.value.reasons) and gmail_ok == []


def test_duplicate_and_daily_limit_and_missing_identity(db, gmail_ok):
    from agents import message_writer as mw, outreach
    from services import settings_store as ss
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m)
    with pytest.raises(outreach.SendBlocked) as e:  # no sender name / postal address yet
        outreach.send(db, m)
    assert any("postal address" in r for r in e.value.reasons)
    configure_sender(db)
    outreach.send(db, m)
    dup = mw.write_email(db, lead, c, "seo"); outreach.approve(db, dup)
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, dup)
    assert any("Duplicate" in r for r in e.value.reasons)
    lead2, c2 = make_lead_with_contact(db, email="b@other.test", key="L2")
    ss.set_value(db, "daily_send_limit", 1)
    m2 = mw.write_email(db, lead2, c2, "seo"); outreach.approve(db, m2)
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, m2)
    assert any("limit" in r.lower() for r in e.value.reasons)


def test_gmail_not_connected_blocks(db):
    from agents import message_writer as mw, outreach
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m)
    with pytest.raises(outreach.SendBlocked) as e:
        outreach.send(db, m)
    assert any("NOT CONNECTED" in r for r in e.value.reasons)


def test_linkedin_cannot_be_auto_sent(db):
    from agents import message_writer as mw, outreach
    lead, c = make_lead_with_contact(db)
    ms = mw.write_linkedin(db, lead, c, "seo")
    with pytest.raises(outreach.SendBlocked):
        outreach.send(db, ms[0])
    outreach.approve(db, ms[0]); outreach.mark_manual_sent(db, ms[0])
    assert ms[0].status == "sent"


def test_followups_are_drafts_and_not_duplicated(db, gmail_ok):
    from agents import message_writer as mw, outreach, sales_manager
    from models.orm import Message, utcnow
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m); outreach.send(db, m)
    assert sales_manager.schedule_followups(db) == 0  # too soon
    m.sent_at = utcnow() - timedelta(days=6)
    assert sales_manager.schedule_followups(db) == 1
    assert sales_manager.schedule_followups(db) == 0  # no duplicate
    f = db.query(Message).filter(Message.followup_of == m.id).one()
    assert f.status == "pending_approval" and f.thread_id == "t1" and f.sequence_no == 1
    lead.status = "replied"
    outreach.approve(db, f)
    with pytest.raises(outreach.SendBlocked):  # replied leads get no follow-up
        outreach.send(db, f)


# ---------- replies ----------
def test_reply_classification_rules():
    from agents.reply_analysis import classify_heuristic as c
    assert c("a@b.com", "Re: hi", "Please unsubscribe me").classification == "unsubscribe"
    assert c("mailer-daemon@googlemail.com", "Delivery Status Notification (Failure)", "").classification == "bounce"
    assert c("a@b.com", "Automatic reply: away", "I am out of office").classification == "out_of_office"
    assert c("a@b.com", "Re: hi", "Not interested, thanks").classification == "not_interested"
    assert c("a@b.com", "Re: hi", "Sounds good, can you send more details?").classification == "interested"


def test_reply_sync_applies_suppression_and_ignores_unrelated(db, gmail_ok):
    from agents import message_writer as mw, outreach, reply_analysis
    from models.orm import Contact, Reply
    from services.suppression import is_suppressed
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m); outreach.send(db, m)
    items = [
        {"id": "g1", "thread_id": "t1", "from": "owner@acme.test", "subject": "Re: SEO", "snippet": "Please remove me from your list, unsubscribe", "date": None},
        {"id": "g2", "thread_id": "zzz", "from": "newsletter@random.test", "subject": "Sale!", "snippet": "50% off", "date": None},
    ]
    out = reply_analysis.process(db, items, "me@gmail.test")
    assert out["new_replies"] == 1 and db.query(Reply).count() == 1  # unrelated inbox mail not stored
    assert is_suppressed(db, "owner@acme.test") and lead.status == "suppressed"


def test_bounce_marks_invalid_and_suppresses(db, gmail_ok):
    from agents import message_writer as mw, outreach, reply_analysis
    from services.suppression import is_suppressed
    configure_sender(db)
    lead, c = make_lead_with_contact(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m); outreach.send(db, m)
    items = [{"id": "b1", "thread_id": "other", "from": "mailer-daemon@googlemail.com", "subject": "Delivery Status Notification (Failure)",
              "snippet": "Your message to owner@acme.test couldn't be delivered", "date": None}]
    reply_analysis.process(db, items, None)
    assert c.email_status == "INVALID" and is_suppressed(db, "owner@acme.test")


# ---------- routes ----------
def test_sample_data_isolated_from_real_metrics(client):
    assert client.post("/api/sample/load").json()["created"] == 4
    assert client.get("/api/stats").json()["funnel"]["discovered"] == 0
    assert client.get("/api/data/leads").json()["total"] == 0
    r = client.get("/api/data/leads?samples=only").json()
    assert r["total"] == 4 and all(x["is_sample"] for x in r["rows"])
    assert client.post("/api/sample/clear").status_code == 200
    assert client.get("/api/data/leads?samples=all").json()["total"] == 0


def test_sample_message_send_endpoint_blocked(client):
    client.post("/api/sample/load")
    mid = client.get("/api/data/messages?samples=only").json()["rows"][0]["id"]
    assert client.post(f"/api/messages/{mid}/approve").status_code == 200
    r = client.post(f"/api/messages/{mid}/send")
    assert r.status_code == 409 and any("Sample" in x for x in r.json()["detail"]["blocked"])


def test_leads_filter_search_pagination(client, db):
    from models.orm import Lead
    for i in range(30):
        db.add(Lead(dedupe_key=f"k{i}", company_name=f"Company {i}", intent="HIGH" if i % 3 == 0 else "LOW", score=i))
    db.commit()
    p1 = client.get("/api/data/leads?page_size=10&page=1").json()
    assert p1["total"] == 30 and len(p1["rows"]) == 10 and p1["rows"][0]["score"] == 29
    assert client.get("/api/data/leads?intent=HIGH").json()["total"] == 10
    assert client.get("/api/data/leads?q=Company 7").json()["total"] == 1
    assert client.get("/api/data/leads?page_size=500").status_code == 422


def test_csv_export_neutralises_formula_injection(client, db):
    from models.orm import Lead
    db.add(Lead(dedupe_key="inj", company_name="=HYPERLINK(\"http://evil\")", name="+cmd|' /C calc'!A0"))
    db.commit()
    r = client.get("/api/data/leads/export.csv")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    body = r.text
    assert "'=HYPERLINK" in body and "'+cmd" in body and "\n=HYPERLINK" not in body


def test_unknown_resource_and_bad_filter(client):
    assert client.get("/api/data/passwords").status_code == 404
    assert client.get("/api/data/leads?intent=HIGH';DROP TABLE leads;--").status_code == 200  # parameterised


def test_settings_roundtrip_and_validation(client):
    r = client.put("/api/settings", json={"daily_send_limit": 5, "sender_name": "Sam", "rss_feeds": ["https://example.com/feed.xml"]})
    assert r.status_code == 200 and r.json()["daily_send_limit"] == 5 and r.json()["rss_feeds"] == ["https://example.com/feed.xml"]
    assert client.put("/api/settings", json={"daily_send_limit": -1}).status_code == 422
    assert client.put("/api/settings", json={"rss_feeds": ["javascript:alert(1)"]}).status_code == 422
    assert "api_key" not in json.dumps(client.get("/api/settings").json()).lower()


def test_manual_lead_runs_through_queue(client):
    r = client.post("/api/leads", json={"text": "I need a website developer for my gym", "company": "Gym Co"})
    assert r.status_code == 200
    run = client.post("/api/jobs/run").json()
    assert all(j["status"] == "done" for j in run["ran"]), run
    leads = client.get("/api/data/leads").json()["rows"]
    assert leads[0]["intent"] == "HIGH" and leads[0]["stage"] == "complete"
    detail = client.get(f"/api/leads/{leads[0]['id']}").json()
    assert detail["lead"]["evidence_quote"]


def test_generate_endpoint_creates_draft_not_pending(client):
    client.post("/api/leads", json={"text": "need an SEO expert", "company": "X"}); client.post("/api/jobs/run")
    lid = client.get("/api/data/leads").json()["rows"][0]["id"]
    r = client.post("/api/messages/generate", json={"lead_id": lid, "service": "seo", "channel": "email"})
    assert r.status_code == 200 and r.json()["messages"][0]["status"] == "draft"
    mid = r.json()["messages"][0]["id"]
    assert client.post(f"/api/messages/{mid}/queue").json()["status"] == "pending_approval"


def test_edit_forces_reapproval(client, db):
    from agents import message_writer as mw, outreach
    lead, c = make_lead_with_contact(db); configure_sender(db)
    m = mw.write_email(db, lead, c, "seo"); outreach.approve(db, m); db.commit()
    r = client.post(f"/api/messages/{m.id}/edit", json={"subject": "New", "body": "Edited body"})
    assert r.json()["status"] == "pending_approval" and r.json()["generated_by"] == "human"


def test_gmail_connect_and_oauth_state(client, monkeypatch):
    assert client.get("/api/gmail/connect").status_code == 400
    monkeypatch.setenv("GOOGLE_CLIENT_ID", "cid"); monkeypatch.setenv("GOOGLE_CLIENT_SECRET", "sec")
    url = client.get("/api/gmail/connect").json()["url"]
    assert url.startswith("https://accounts.google.com/") and "access_type=offline" in url and "gmail.send" in url
    assert client.get("/api/gmail/callback?code=x&state=forged").status_code == 400


def test_gmail_token_encrypted_at_rest(db):
    from services import crypto
    from models.orm import Setting
    t = crypto.encrypt("refresh-token-123")
    assert "refresh-token-123" not in t and crypto.decrypt(t) == "refresh-token-123"


def test_dashboard_html_escapes_nothing_unsafe_and_js_uses_esc():
    js = (ROOT / "public/static/app.js").read_text()
    assert "const esc" in js and "innerHTML" in js
    assert "localStorage" not in js  # nothing sensitive in browser storage


# ---------- deployment config ----------
def test_vercel_config_valid():
    cfg = json.loads((ROOT / "vercel.json").read_text())
    assert (ROOT / "app.py").exists() and "app" in (ROOT / "app.py").read_text()
    for c in cfg["crons"]:
        minute, hour, dom, mon, dow = c["schedule"].split()
        assert minute.isdigit() and hour.isdigit(), "Hobby plan allows at most one run per day: no */n or hourly schedules"
    assert cfg["framework"] == "fastapi"  # verified with `vercel build`: without it nothing but static files is built
    assert cfg["functions"]["app.py"]["maxDuration"] <= 300
    assert (ROOT / "public/static/style.css").exists() and (ROOT / "requirements.txt").exists()


def test_requirements_cover_imports():
    import re
    reqs = (ROOT / "requirements.txt").read_text().lower()
    for pkg in ("fastapi", "sqlalchemy", "pydantic", "httpx", "dnspython", "anthropic", "psycopg", "feedparser", "beautifulsoup4", "itsdangerous", "email-validator", "cryptography"):
        assert pkg in reqs


def test_no_secrets_committed():
    import re
    pat = re.compile(r"(sk-ant-[A-Za-z0-9\-_]{10,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z\-_]{30,})")
    for p in ROOT.rglob("*"):
        if p.is_file() and p.suffix in (".py", ".md", ".json", ".js", ".html", ".example", ".txt") and ".pytest_cache" not in str(p):
            assert not pat.search(p.read_text(errors="ignore")), p
