import json
from pathlib import Path

import httpx
import pytest

ROOT = Path(__file__).resolve().parent.parent


# ---------- config / integrations ----------
def test_registry_has_required_fields_and_env_names():
    from config import INTEGRATIONS
    keys = {i["key"] for i in INTEGRATIONS}
    assert {"database", "anthropic", "serper", "hunter", "snov", "zerobounce", "gmail", "linkedin"} <= keys
    for i in INTEGRATIONS:
        for f in ("name", "purpose", "free", "card", "cost", "mandatory", "env"):
            assert f in i
    example = (ROOT / ".env.example").read_text()
    for i in INTEGRATIONS:
        for v in i["env"]:
            assert v in example, f"{v} missing from .env.example"


def test_integration_status_without_any_keys(client):
    d = client.get("/api/integrations").json()["integrations"]
    st = {i["key"]: i["status"] for i in d}
    assert st["anthropic"] == "NOT CONNECTED" and st["gmail"] == "NOT CONNECTED" and st["database"] == "CONNECTED"
    assert st["linkedin"] == "NOT CONNECTED"


def test_integration_status_partial_and_connected(client, monkeypatch):
    monkeypatch.setenv("SNOV_CLIENT_ID", "abc")
    monkeypatch.setenv("HUNTER_API_KEY", "k")
    monkeypatch.setenv("GOOGLE_CLIENT_ID", "a")
    monkeypatch.setenv("GOOGLE_CLIENT_SECRET", "b")
    st = {i["key"]: i["status"] for i in client.get("/api/integrations").json()["integrations"]}
    assert st["snov"] == "NEEDS CONFIGURATION" and st["hunter"] == "CONNECTED"
    assert st["gmail"] == "NEEDS CONFIGURATION"  # credentials set but not authorized


# ---------- auth ----------
def test_api_requires_login():
    from fastapi.testclient import TestClient
    from app import app
    c = TestClient(app)
    assert c.get("/api/stats").status_code == 401
    assert c.get("/api/data/leads").status_code == 401
    assert c.get("/api/health").status_code == 200
    assert "Sign in" in c.get("/").text


def test_login_wrong_password_and_csrf(client):
    from fastapi.testclient import TestClient
    from app import app
    c = TestClient(app)
    assert c.post("/api/login", json={"password": "nope"}).status_code == 401
    c.post("/api/login", json={"password": "test-password-123"})
    assert c.post("/api/sample/load").status_code == 403  # missing CSRF header
    assert c.post("/api/sample/load", headers={"X-CSRF": "1"}).status_code == 200
    assert "Overview" in c.get("/").text or "AI Client Finder" in c.get("/").text


def test_unconfigured_auth_fails_closed(monkeypatch):
    from fastapi.testclient import TestClient
    from app import app
    monkeypatch.delenv("ADMIN_PASSWORD")
    c = TestClient(app)
    assert c.post("/api/login", json={"password": "x"}).status_code == 503
    assert c.get("/api/stats").status_code == 503


def test_cron_requires_secret(client):
    from fastapi.testclient import TestClient
    from app import app
    c = TestClient(app)
    assert c.get("/api/cron/tick").status_code == 401
    assert c.get("/api/cron/tick", headers={"Authorization": "Bearer wrong"}).status_code == 401
    r = c.get("/api/cron/tick", headers={"Authorization": "Bearer cron-secret-abc"})
    assert r.status_code == 200 and "ran" in r.json()


# ---------- database ----------
def test_sqlite_rejected_on_vercel(monkeypatch):
    from database import db as dbm
    monkeypatch.setenv("VERCEL", "1")
    monkeypatch.setenv("DATABASE_URL", "sqlite:///x.db")
    with pytest.raises(dbm.DatabaseNotConfigured):
        dbm.database_url()


def test_postgres_url_normalised(monkeypatch):
    from database import db as dbm
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@host:6543/postgres")
    assert dbm.database_url().startswith("postgresql+psycopg://")
    monkeypatch.setenv("DATABASE_URL", "postgres://u:p@host:5432/postgres")
    assert dbm.database_url().startswith("postgresql+psycopg://")


def test_no_database_url_gives_503(monkeypatch):
    from fastapi.testclient import TestClient
    from app import app
    from database import db as dbm
    c = TestClient(app)
    c.post("/api/login", json={"password": "test-password-123"})
    monkeypatch.delenv("DATABASE_URL")
    dbm.reset_engine()
    r = c.get("/api/stats", headers={"X-CSRF": "1"})
    assert r.status_code == 503 and "NEEDS CONFIGURATION" in r.text


def test_schema_compiles_for_postgres():
    from sqlalchemy.dialects import postgresql
    from sqlalchemy.schema import CreateTable
    from models.orm import Base
    for t in Base.metadata.sorted_tables:
        assert "CREATE TABLE" in str(CreateTable(t).compile(dialect=postgresql.dialect()))
    assert (ROOT / "database" / "schema.sql").exists()


# ---------- email checks / verification ----------
def test_email_syntax_and_disposable(monkeypatch):
    from services import email_checks as ec
    monkeypatch.setattr(ec, "mx_lookup", lambda d: (True, ["mx." + d], None))
    assert ec.local_check("not-an-email")["syntax_ok"] is False
    assert ec.local_check("a@mailinator.com")["disposable"] is True
    r = ec.local_check("Info@Acme.com")
    assert r["syntax_ok"] and r["dns_ok"] and r["role_account"] and r["email"] == "info@acme.com"


def test_dns_only_never_verified(monkeypatch):
    from agents import email_verification as ev
    from services import email_checks as ec
    monkeypatch.setattr(ec, "mx_lookup", lambda d: (True, ["mx"], None))
    r = ev.verify_email("owner@acme.com")
    assert r["status"] == "UNKNOWN" and "NOT provider-verified" in r["level"]


def test_no_mx_is_invalid(monkeypatch):
    from agents import email_verification as ev
    from services import email_checks as ec
    monkeypatch.setattr(ec, "mx_lookup", lambda d: (False, [], "domain does not exist"))
    assert ev.verify_email("a@nonexistent-domain-xyz.com")["status"] == "INVALID"


@pytest.mark.parametrize("provider,raw,expected", [
    ("hunter", "valid", "VERIFIED"), ("hunter", "accept_all", "CATCH-ALL"), ("hunter", "invalid", "INVALID"), ("hunter", "webmail", "UNKNOWN"),
    ("zerobounce", "valid", "VERIFIED"), ("zerobounce", "catch-all", "CATCH-ALL"), ("zerobounce", "abuse", "RISKY"), ("zerobounce", "spamtrap", "INVALID"),
    ("snov", "valid", "VERIFIED"), ("snov", "not_valid", "INVALID"), ("snov", "weird", "UNKNOWN"),
])
def test_provider_status_mapping(provider, raw, expected):
    from agents.email_verification import map_provider
    assert map_provider(provider, raw) == expected


def test_hunter_verification_with_mocked_http(monkeypatch):
    from agents import email_verification as ev
    from services import email_checks as ec, http
    monkeypatch.setenv("HUNTER_API_KEY", "k")
    monkeypatch.setattr(ec, "mx_lookup", lambda d: (True, ["mx"], None))
    http.set_transport(httpx.MockTransport(lambda req: httpx.Response(200, json={"data": {"status": "valid", "score": 96}})))
    r = ev.verify_email("owner@acme.com")
    assert r["status"] == "VERIFIED" and r["provider"] == "hunter"


def test_provider_outage_leaves_unknown(monkeypatch):
    from agents import email_verification as ev
    from services import email_checks as ec, http
    monkeypatch.setenv("HUNTER_API_KEY", "k")
    monkeypatch.setattr(ec, "mx_lookup", lambda d: (True, ["mx"], None))
    http.set_transport(httpx.MockTransport(lambda req: httpx.Response(429)))
    r = ev.verify_email("owner@acme.com")
    assert r["status"] == "UNKNOWN" and r["provider_errors"]


# ---------- SSRF / robots ----------
def test_ssrf_blocked():
    from services import http
    for u in ["http://127.0.0.1/", "http://localhost/admin", "http://169.254.169.254/latest/meta-data", "http://10.0.0.5/", "ftp://example.com/x"]:
        r = http.safe_get(u)
        assert r.error and not r.ok, u


def test_robots_respected():
    from services import http

    def handler(req):
        if req.url.path == "/robots.txt":
            return httpx.Response(200, text="User-agent: *\nDisallow: /private")
        return httpx.Response(200, text="<html>ok</html>")
    http.set_transport(httpx.MockTransport(handler))
    assert http.safe_get("https://site.test/").ok
    r = http.safe_get("https://site.test/private/x")
    assert r.blocked_by_robots and not r.ok


# ---------- intent ----------
def test_heuristic_intent_levels():
    from agents.intent import heuristic
    h = heuristic("Hi all, I need a website developer for my new bakery. Budget flexible.")
    assert h.intent == "HIGH" and h.service_needed == "website_development" and "need a website developer" in h.evidence_quote
    assert heuristic("We are launching a new store next month and need an SEO plan").intent in ("HIGH", "MEDIUM")
    assert heuristic("I offer web design services. Hire me!").intent == "NONE"
    assert heuristic("Top 10 SEO tips for 2026").intent == "NONE"
    assert heuristic("Nice weather today").intent == "NONE"


def test_fabricated_quote_is_downgraded():
    from agents.intent import IntentResult, validate_against_source
    r = IntentResult(relevant=True, intent="HIGH", confidence=0.95, service_needed="seo", person_name="John Smith",
                     evidence_quote="We urgently need a $5k SEO retainer", reasoning="x")
    out = validate_against_source(r, "Anyone know a good plumber?")
    assert out.intent == "LOW" and out.evidence_quote is None and out.person_name is None and out.confidence <= 0.3


def test_verbatim_quote_kept():
    from agents.intent import IntentResult, validate_against_source
    src = "Hello!  Looking for a   web designer for my shop."
    r = IntentResult(relevant=True, intent="HIGH", confidence=0.9, service_needed="website_development", evidence_quote="Looking for a web designer", reasoning="x")
    assert validate_against_source(r, src).intent == "HIGH"


def test_claude_path_used_when_configured(db, monkeypatch):
    from agents import intent
    from models.orm import Lead
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    monkeypatch.setattr(intent.llm, "complete_json", lambda *a, **k: intent.IntentResult(
        relevant=True, intent="HIGH", confidence=0.9, service_needed="seo", evidence_quote="need an SEO expert", reasoning="asks directly", recommended_approach="reply"))
    lead = Lead(dedupe_key="k1", source_text="We need an SEO expert for our clinic", stage="discovered")
    db.add(lead); db.flush()
    intent.run(db, lead)
    assert lead.intent == "HIGH" and lead.intent_method == "claude" and lead.service_needed == "seo"


# ---------- discovery ----------
def test_discovery_with_mocked_search_preserves_source_and_dedupes(db, monkeypatch):
    from agents import discovery
    from integrations import search as sapi
    from services import http
    monkeypatch.setenv("SERPER_API_KEY", "k")
    payload = {"organic": [
        {"title": "Need a web designer", "link": "https://forum.test/t/1", "snippet": "I need a web designer for my cafe", "date": "2026-10-30"},
        {"title": "Top 10 web design agencies", "link": "https://listicle.test/a", "snippet": "best agencies"},
        {"title": "LinkedIn post", "link": "https://www.linkedin.com/posts/x", "snippet": "need seo"},
    ]}
    http.set_transport(httpx.MockTransport(lambda req: httpx.Response(200, json=payload)))
    res = discovery.run(db, {"queries": ['"need a web designer"'], "hn": False})
    leads = db.query(__import__("models.orm", fromlist=["Lead"]).Lead).all()
    assert len(leads) == 1 and leads[0].source_url == "https://forum.test/t/1"
    assert leads[0].source_date.year == 2026 and leads[0].is_sample is False
    res2 = discovery.run(db, {"queries": ['"need a web designer"'], "hn": False})
    assert res2.details["new_lead_ids"] == []  # deduped


def test_discovery_without_search_key_is_graceful(db):
    from agents import discovery
    res = discovery.run(db, {"queries": ["x"], "hn": False})
    assert "not connected" in " ".join(res.details["errors"]).lower()


def test_hacker_news_source(db, monkeypatch):
    from agents import discovery
    from services import http
    hits = {"hits": [{"objectID": "123", "comment_text": "<p>We are looking for a web developer to rebuild our site</p>", "author": "bob", "created_at": "2026-11-01T10:00:00.000Z", "story_title": "Ask HN"}]}
    http.set_transport(httpx.MockTransport(lambda req: httpx.Response(200, json=hits)))
    res = discovery.run(db, {"queries": ["web developer"], "hn": True})
    from models.orm import Lead
    lead = db.query(Lead).one()
    assert lead.source_url.endswith("id=123") and lead.name == "bob" and lead.name_is_handle


# ---------- website audit ----------
GOOD = """<html><head><title>Acme Plumbing - Emergency plumbers in Leeds</title><meta name="viewport" content="width=device-width">
<meta name="description" content="x"><link rel="canonical" href="/"><script type="application/ld+json">{}</script></head>
<body><nav><a href="/">Home</a><a href="/contact">Contact</a><a href="/about">About</a></nav><h1>Acme</h1><a href="/contact">Get a quote</a>
<form><input name="e"></form><footer>© 2026 Acme</footer></body></html>"""
BAD = """<html><head></head><body><div><img src="a.png"><img src="b.png"><img src="c.png"></div><p>Welcome</p><footer>© 2017 Old Co</footer></body></html>"""


def _fake_site(html):
    def handler(req):
        if req.url.path == "/robots.txt":
            return httpx.Response(404)
        if req.url.path == "/sitemap.xml":
            return httpx.Response(404)
        return httpx.Response(200, text=html)
    return httpx.MockTransport(handler)


def test_audit_reports_only_observed_problems(db):
    from agents.website_audit import audit_url
    from services import http
    http.set_transport(_fake_site(GOOD))
    a = audit_url(db, "https://good.test/", None, None)
    areas = {(f["area"], f["observed"]) for f in a.findings}
    assert a.reachable
    assert not any(ar in ("mobile", "conversion", "navigation", "freshness") for ar, _ in areas)
    assert not any("viewport" in o or "<title>" in o or "<form>" in o for _, o in areas)


def test_audit_detects_real_issues(db):
    from agents.website_audit import audit_url
    from services import http
    http.set_transport(_fake_site(BAD))
    a = audit_url(db, "http://bad.test/", None, None)
    text = " ".join(f["observed"] for f in a.findings)
    for needle in ("viewport", "no <title>", "meta description", "<h1>", "alt text", "No <form>", "call-to-action", "2017", "http://"):
        assert needle.lower() in text.lower(), needle


def test_audit_unreachable_site(db):
    from agents.website_audit import audit_url
    from services import http
    http.set_transport(httpx.MockTransport(lambda r: httpx.Response(404) if r.url.path == "/robots.txt" else httpx.Response(500)))
    a = audit_url(db, "https://down.test/", None, None)
    assert not a.reachable and a.findings[0]["area"] == "availability"


# ---------- email finder never guesses ----------
def test_email_finder_only_published_addresses(db):
    from agents import email_finder
    from models.orm import Company, Contact, Lead
    from services import http
    html = '<html><body><a href="mailto:hello@acme.test">mail</a> sales@acme.test contact other@elsewhere.com <img src="logo@2x.png"></body></html>'
    http.set_transport(_fake_site(html))
    co = Company(name="Acme", domain="acme.test", website_url="https://acme.test/")
    db.add(co); db.flush()
    lead = Lead(dedupe_key="e1", company_id=co.id, stage="research")
    db.add(lead); db.flush()
    res = email_finder.run(db, lead)
    emails = sorted(c.email for c in db.query(Contact).all())
    assert emails == ["hello@acme.test", "sales@acme.test"]
    assert all(c.email_status == "UNKNOWN" and "published on" in c.email_source for c in db.query(Contact).all())
    assert "No email provider connected" in " ".join(res.details["notes"])


# ---------- jobs ----------
def test_job_queue_runs_retries_and_records_errors(db):
    from services import jobs
    calls = []

    def ok(db, job, budget):
        calls.append(job.id)
        return {"x": 1}

    def boom(db, job, budget):
        raise RuntimeError("kaboom")
    j1, j2 = jobs.enqueue(db, "ok"), jobs.enqueue(db, "boom")
    db.commit()
    out = jobs.run_queue(db, {"ok": ok, "boom": boom}, budget_s=20)
    from models.orm import Job
    assert db.get(Job, j1.id).status == "done" and db.get(Job, j1.id).result == {"x": 1}
    assert db.get(Job, j2.id).error and "kaboom" in db.get(Job, j2.id).error
    for _ in range(4):
        jobs.run_queue(db, {"ok": ok, "boom": boom}, budget_s=20)
    assert db.get(Job, j2.id).status == "failed" and db.get(Job, j2.id).attempts == 3


def test_pipeline_runs_end_to_end_with_no_integrations(db):
    """Every integration missing: pipeline must still complete, skipping stages, never crash."""
    from agents import orchestrator
    from models.orm import AgentRun, Lead
    lead = Lead(dedupe_key="p1", source_type="web_search", source_url="https://forum.test/1", source_title="Need help",
                source_text="I need a website developer for my shop", company_name="Shop Co", stage="discovered")
    db.add(lead); db.commit()
    out = orchestrator.process_lead(db, lead.id, 60)
    db.refresh(lead)
    assert out["complete"] and lead.stage == "complete" and lead.intent == "HIGH" and lead.score and lead.score > 0
    runs = {r.agent: r.status for r in db.query(AgentRun).all()}
    assert runs["company_research"] == "skipped" and runs["lead_scoring"] == "ok"
    from models.orm import Message
    assert db.query(Message).filter(Message.channel == "public_reply").count() == 1  # HIGH intent forum lead gets a manual reply draft


def test_pipeline_low_intent_skips_enrichment(db):
    from agents import orchestrator
    from models.orm import AgentRun, Lead
    lead = Lead(dedupe_key="p2", source_text="Our SEO tips blog is popular", stage="discovered", intent="LOW", intent_method="rule", confidence=0.2)
    db.add(lead); db.commit()
    orchestrator.process_lead(db, lead.id, 60)
    agents = {r.agent for r in db.query(AgentRun).all()}
    assert "lead_scoring" in agents and "company_research" not in agents and "email_finder" not in agents
