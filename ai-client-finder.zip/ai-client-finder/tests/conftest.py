import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

CLEAN = ["ANTHROPIC_API_KEY", "SERPER_API_KEY", "TAVILY_API_KEY", "BRAVE_SEARCH_API_KEY", "HUNTER_API_KEY", "SNOV_CLIENT_ID", "SNOV_CLIENT_SECRET",
         "ZEROBOUNCE_API_KEY", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "PAGESPEED_API_KEY", "VERCEL", "CRON_SECRET", "ALLOW_LOCAL_SQLITE"]


@pytest.fixture(autouse=True)
def env(monkeypatch, tmp_path):
    for k in CLEAN:
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("ADMIN_PASSWORD", "test-password-123")
    monkeypatch.setenv("SECRET_KEY", "x" * 40)
    monkeypatch.setenv("CRON_SECRET", "cron-secret-abc")
    monkeypatch.setenv("DATABASE_URL", __import__("os").environ.get("TEST_DATABASE_URL") or f"sqlite:///{tmp_path}/test.db")
    from database import db as dbm
    from services import http
    dbm.reset_engine()
    http.set_transport(None)
    yield
    if os.environ.get("TEST_DATABASE_URL"):
        from models.orm import Base
        try:
            Base.metadata.drop_all(dbm.get_engine())
        except Exception:
            pass
    dbm.reset_engine()
    http.set_transport(None)


@pytest.fixture
def db():
    from database.db import new_session
    s = new_session()
    yield s
    s.rollback()
    s.close()


@pytest.fixture
def client():
    from fastapi.testclient import TestClient
    from app import app
    c = TestClient(app)
    r = c.post("/api/login", json={"password": "test-password-123"})
    assert r.status_code == 200
    c.headers.update({"X-CSRF": "1"})
    return c
