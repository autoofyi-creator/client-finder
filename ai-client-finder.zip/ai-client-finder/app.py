"""AI Client Finder: one FastAPI app serving the dashboard and the API. Vercel entrypoint: app.py -> `app`."""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from config import env, is_vercel
from database.db import DatabaseNotConfigured
from routes import api, data
from services import security

BASE = Path(__file__).parent
app = FastAPI(title="AI Client Finder", docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(api.public)
app.include_router(api.router)
app.include_router(data.router)
app.include_router(api.cron)

if not is_vercel():  # On Vercel, public/** is served by the CDN
    app.mount("/static", StaticFiles(directory=BASE / "public" / "static"), name="static")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    resp.headers.setdefault("Cache-Control", "no-store" if request.url.path.startswith("/api") else "no-cache")
    return resp


@app.exception_handler(DatabaseNotConfigured)
async def db_missing(request: Request, exc: DatabaseNotConfigured):
    return JSONResponse({"detail": f"NEEDS CONFIGURATION: {exc}"}, status_code=503)


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def index(request: Request):
    page = "index.html" if security.session_valid(request.cookies.get(security.COOKIE)) else "login.html"
    return HTMLResponse((BASE / "templates" / page).read_text(encoding="utf-8"))


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return FileResponse(BASE / "public" / "static" / "favicon.svg", media_type="image/svg+xml")
