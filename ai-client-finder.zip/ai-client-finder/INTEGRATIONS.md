# Integrations: how each one behaves

Every integration is independent. Status is computed in `routes/api.py:integration_status`:

| Status | Meaning |
|---|---|
| CONNECTED | All required variables set (and, for Gmail, authorised). If a **Test connection** failed, it shows ERROR instead |
| NEEDS CONFIGURATION | Partly set (e.g. Snov id without secret; Gmail credentials without authorisation) |
| NOT CONNECTED | Nothing set. The dependent stage is skipped and logged as `skipped` |
| ERROR | The last live test failed; the message is shown on the card |

A pipeline with **no** integrations still completes (tested): stages that need an integration record `skipped` in `agent_runs`.

| Integration | Used by | Behaviour / limits |
|---|---|---|
| Anthropic | Intent, Company Research, Message Writer, Reply Analysis, Website Audit summary | Output is validated with Pydantic. Quotes and names must literally appear in the source or the lead is downgraded. Web text is wrapped as untrusted data. On failure the agent falls back to rules/templates and labels the record |
| Serper / Tavily / Brave | Discovery, Company Research, LinkedIn Research | Results carry URL and date only when the provider returns a parseable date; relative dates are never guessed. LinkedIn/Facebook/Instagram/TikTok/X results are dropped from discovery |
| Hacker News (Algolia) / RSS | Discovery | Keyless. RSS feeds you add in Settings are fetched through the SSRF-safe fetcher |
| Hunter | Email Finder, Verification | `domain-search`, `email-verifier`. Statuses mapped: valid=VERIFIED, accept_all=CATCH-ALL, invalid/disposable=INVALID, webmail/unknown=UNKNOWN |
| Snov.io | Email Finder, Verification | v2 async start/poll endpoints. Written from Snov docs; response parsing is defensive and unconfirmed against a live account |
| ZeroBounce | Verification | valid=VERIFIED, catch-all=CATCH-ALL, abuse=RISKY, invalid/spamtrap/do_not_mail=INVALID. Tried first when configured |
| Gmail | Outreach, Reply Analysis | OAuth web flow with signed state; refresh token encrypted with a key derived from `SECRET_KEY`. Scopes: send, compose, readonly. Only replies matching emails we sent are stored (unrelated inbox mail is ignored) |
| PageSpeed | Website Audit | Mobile performance score; a score below 50 becomes a finding |
| LinkedIn | LinkedIn Research, Message Writer | Public search-result snippets only (unverified, flagged in UI). Messages need approval, then you send manually |

## Email status rules (`agents/email_verification.py`)

1. Bad syntax, disposable domain, or no MX/A record: `INVALID`.
2. Otherwise a configured provider's verdict is mapped as above.
3. No provider verdict (none configured, or all failed): `UNKNOWN`, with `level: "syntax+dns only (NOT provider-verified)"`.

Default sending policy allows only `VERIFIED`. Settings can additionally allow `CATCH-ALL`.

## Sending gates (`agents/outreach.py:blockers`)

Not sample data; status approved by a human; recipient status allowed; address and domain not suppressed; lead not suppressed/discarded; not previously emailed (follow-ups exempt but cancelled once the lead replied); sender name and postal address set; daily limit not reached; Gmail connected. LinkedIn and public replies can never be sent by the app.

## Job queue

`jobs` table: `queued -> running -> done/failed` (3 attempts). Stuck `running` jobs older than 10 minutes are re-queued. `POST /api/jobs/run` and the daily cron drain the queue within `JOB_TIME_BUDGET_SECONDS`; a lead's pipeline that runs out of budget re-enqueues itself and resumes at the next stage.
