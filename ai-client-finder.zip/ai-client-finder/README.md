# AI Client Finder: Autonomous Sales Intelligence

A single FastAPI application (dashboard + API) that finds public demand for web development, redesign, digital marketing, SEO, social media, AI video and AI automation services; classifies buying intent; finds and verifies business emails; audits prospect websites; drafts personalised outreach; and manages approvals, replies and a sales pipeline.

**Safety by design:** nothing is sent without your approval, invalid/unverified/suppressed/duplicate recipients are blocked in code, LinkedIn is manual-assist only, and sample data can never be emailed.

> Read [What is verified and what is not](#what-is-verified-and-what-is-not) before relying on this in production.

## Architecture

```
app.py                 FastAPI entrypoint (Vercel: app.py -> `app`), serves dashboard + API
config.py              Integration registry (drives docs + dashboard status)
agents/                12 agents + orchestrator (communicate only via database rows)
integrations/          Claude, Serper/Tavily/Brave, Hunter, Snov, ZeroBounce, Gmail OAuth, PageSpeed, HN/RSS
services/              HTTP (SSRF guard, robots.txt), email checks, jobs queue, security, CSV, settings
models/                SQLAlchemy ORM + Pydantic schemas
routes/                API routes (actions + generic data tables)
database/              Engine/session + schema.sql (run in Supabase if you prefer)
templates/ public/     Dashboard (HTML + CSS + vanilla JS)
tests/                 76 tests
```

Agents: Discovery, Buying Intent, Company Research, LinkedIn Research, Email Finder, Email Verification, Website Audit, Lead Scoring, Personalized Message, Outreach, Reply Analysis, Sales Manager. The orchestrator runs them per lead in order, saves after every stage, logs to `agent_runs`, and resumes across short serverless invocations through a database-backed job queue.

## 1. Local setup

```bash
cd ai-client-finder
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env            # then fill in ADMIN_PASSWORD, SECRET_KEY (and DATABASE_URL)
python -c "import secrets;print(secrets.token_urlsafe(32))"   # use for SECRET_KEY / CRON_SECRET

# Local development can use throwaway SQLite (never on Vercel):
export ALLOW_LOCAL_SQLITE=1
set -a; source .env; set +a
uvicorn app:app --reload --port 8000
```
Open http://localhost:8000, sign in with `ADMIN_PASSWORD`. For real data use a Supabase `DATABASE_URL` even locally.

Run tests: `python -m pytest tests -q`. To run them against PostgreSQL: `TEST_DATABASE_URL=postgresql://user:pass@host:5432/db python -m pytest tests -q` (the suite drops its tables afterwards, so use a scratch database).

## 2. Database (Supabase)

1. Create a project at https://supabase.com/dashboard.
2. **Project Settings > Database > Connection string**. Choose the **pooled / Supavisor** connection (transaction mode, port 6543) for Vercel. Copy it as `DATABASE_URL` (URI form; `postgresql://` is converted automatically).
3. Tables are created automatically on first request. Alternatively paste `database/schema.sql` into the Supabase SQL editor (it also enables Row Level Security so the public Supabase API cannot read your leads; the app connects with the database role and is unaffected).

## 3. GitHub upload

```bash
cd ai-client-finder
git init && git add . && git commit -m "AI Client Finder"
git branch -M main
git remote add origin https://github.com/YOUR-USER/ai-client-finder.git
git push -u origin main
```
`.gitignore` already excludes `.env`, databases and caches. Use a **private** repository.

## 4. Vercel deployment

1. https://vercel.com/new > import the GitHub repo. Vercel detects FastAPI (`vercel.json` also sets `"framework": "fastapi"`).
2. **Settings > Environment Variables**: add at least `ADMIN_PASSWORD`, `SECRET_KEY`, `DATABASE_URL`, `CRON_SECRET`, then any integration keys from `.env.example`. Apply to Production (and Preview if wanted).
3. Deploy. Visit `https://YOUR-APP.vercel.app`, sign in, open **API Integrations** to see status.
4. Gmail only: add `https://YOUR-APP.vercel.app/api/gmail/callback` as an authorised redirect URI in Google Cloud, redeploy, then press **Connect Gmail**.

CLI alternative: `npm i -g vercel && vercel && vercel --prod`.

### Vercel limits this app is built around

| Limit | How the app handles it |
|---|---|
| No persistent process or disk | All state is in Postgres; no SQLite on Vercel (the app refuses to start with it) |
| Function time limits | Work is split into short jobs with a time budget (`JOB_TIME_BUDGET_SECONDS`, default 40s; `maxDuration` 60s). Long leads resume in a new job |
| Hobby cron = at most once per day | `vercel.json` has one daily cron (`0 6 * * *`). **No hourly crons.** A test enforces this |
| Cron only runs on production deployments | Use the dashboard buttons (**Run queued jobs now**) on previews or for faster cycles |

What the daily cron does: syncs Gmail replies, runs the Sales Manager (creates follow-up *drafts* for approval), optionally runs one discovery batch (Settings), and drains queued jobs. **It never sends email.**

Optional: for more frequent background work than Hobby allows, call `GET /api/cron/tick` with header `Authorization: Bearer $CRON_SECRET` from any external scheduler (GitHub Actions, Railway or Render cron). It runs the same short, bounded job pass. Not required for any feature.

## 5. Using it

1. **Settings**: enter your name, business name and postal address (required before sending), daily limit, and review search phrases.
2. **Find Clients**: *Queue discovery*, then *Run queued jobs now*. Or paste a post/URL/company under *Add a prospect*.
3. **Buying Intent Monitor**: review HIGH leads with their verbatim evidence, source link and date. Click a row for the full record.
4. **Approval Queue**: edit, approve, then *Send now* (email) or copy (LinkedIn / public reply) and *Mark as sent*.
5. **Replies**: *Sync Gmail now*. Unsubscribes and bounces are added to the suppression list automatically.
6. **Sales Pipeline / Analytics**: track progress; set meetings/converted yourself.

Try **Settings > Load sample data** first to explore the UI. Sample rows are labelled SAMPLE, excluded from all counts, and cannot be sent.

## Compliance notes

- Discovery reads only public sources through APIs you configure, plus Hacker News and RSS. It never logs in anywhere, solves CAPTCHAs, or scrapes LinkedIn/Facebook/Instagram.
- Website fetches respect `robots.txt`, block private/internal addresses (SSRF), cap size and redirects.
- Every email gets a postal address and opt-out line added by code. Cold email rules (CAN-SPAM, UK PECR/GDPR, CASL, etc.) vary by country and by whether you are contacting companies or individuals; **you** are responsible for lawful use. This is not legal advice.
- Start with a low daily limit from a mailbox you are prepared to protect; poor results hurt deliverability.

## What is verified and what is not

**Verified here (automated):** 76 tests pass on both SQLite and PostgreSQL 16; `database/schema.sql` applies cleanly to PostgreSQL 16; the live server was exercised over HTTP (login, CSRF, jobs, CSV, cron auth); all 15 dashboard pages render without JavaScript errors in a simulated browser (jsdom) against the live API; `vercel build` (Vercel CLI 65.12) completes locally and produces a Python 3.12 function with templates and static assets.

**Not verified:** Nothing has been deployed to Vercel. No real Supabase project, Anthropic, Serper, Hunter, Snov, ZeroBounce or Google account was available, so those integrations are tested only against mocked HTTP responses written from provider documentation. Snov's v2 response shapes in particular are parsed defensively but unconfirmed. The visual design has not been checked in a real browser. Expect to fix small integration details on first contact with live APIs: use **Test connection** on the Integrations page.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Login says NEEDS CONFIGURATION | Set `ADMIN_PASSWORD` and a `SECRET_KEY` of 16+ characters, redeploy |
| API returns 503 NEEDS CONFIGURATION: DATABASE_URL | Set `DATABASE_URL`; on Vercel use Supabase's pooled URI |
| `prepared statement ... already exists` | Use the pooled (port 6543) URI; the app already disables prepared statements |
| Build only serves static files | Ensure `vercel.json` contains `"framework": "fastapi"` |
| Gmail "redirect_uri_mismatch" | The redirect URI in Google Cloud must exactly equal `https://YOUR-APP/api/gmail/callback` (or set `GOOGLE_REDIRECT_URI`) |
| Gmail stops working after ~7 days | Google OAuth apps in *Testing* status expire refresh tokens after 7 days. Publish the consent screen to *In production* (personal use, unverified warning is expected) and reconnect |
| Emails stay UNKNOWN | Connect Hunter, Snov or ZeroBounce. Syntax/DNS checks never produce VERIFIED |
| Discovery finds nothing | Connect a search API (Serper has a no-card free tier) or add RSS feeds; check Analytics > Agent activity for errors |
| Job seems stuck | Press **Run queued jobs now**; jobs stuck as running for 10+ minutes are re-queued automatically |
| Cron did nothing | Hobby crons run daily on production only and require `CRON_SECRET` to be set |
