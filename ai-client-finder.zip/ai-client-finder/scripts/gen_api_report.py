"""Generates API_REQUIREMENTS_REPORT.md from the integration registry in config.py (single source of truth)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from config import INTEGRATIONS

out = ["# API Requirements Report", "",
       "Generated from `config.py`, the same registry that drives the dashboard's **API Integrations** page.",
       "Prices and free tiers change often: confirm on the provider's page before relying on them (figures checked November 2026).", "",
       "| # | Provider | Mandatory | Env variables | Free tier | Card needed | Cost |", "|---|---|---|---|---|---|---|"]
for i, it in enumerate(INTEGRATIONS, 1):
    env = ", ".join(f"`{v}`" for v in it["env"] + it["optional_env"]) or "none"
    out.append(f"| {i} | {it['name']} | {'**Yes**' if it['mandatory'] else 'Optional'} | {env} | {it['free']} | {it['card']} | {it['cost']} |")
out += ["", "## Details", ""]
for it in INTEGRATIONS:
    out += [f"### {it['name']}", "",
            f"- **What it does:** {it['purpose']}",
            f"- **Why the agent needs it:** {it['why']}",
            f"- **Mandatory:** {'Yes' if it['mandatory'] else 'No (the app works without it; the integration shows NOT CONNECTED)'}",
            f"- **Free tier:** {it['free']}",
            f"- **Credit card required:** {it['card']}",
            f"- **Registration URL:** {it['url'] or 'n/a'}",
            f"- **Environment variables:** {', '.join('`'+v+'`' for v in it['env']) or 'none'}"
            + (f" (optional: {', '.join('`'+v+'`' for v in it['optional_env'])})" if it['optional_env'] else ""),
            f"- **Estimated cost:** {it['cost']}",
            f"- **Setup:** {it['setup']}", ""]
out += ["## Accounts you must connect", "",
        "1. **Supabase** (`DATABASE_URL`) and the three app-security values (`ADMIN_PASSWORD`, `SECRET_KEY`, `CRON_SECRET`). Nothing works without these.", "",
        "## Features that need paid or external APIs", "",
        "| Feature | Needs | Without it |", "|---|---|---|",
        "| Semantic intent detection, personalised writing, reply understanding | Anthropic API (pay per token) | Keyword rules and templates, labelled `heuristic` / `template` |",
        "| Search-engine discovery, official-website lookup, public LinkedIn profile snippets | One search API (Serper/Tavily free tiers; Brave needs a card) | Only Hacker News + your RSS feeds + manual leads |",
        "| Emails not published on the company site | Hunter and/or Snov (free tiers are small) | Only published addresses are collected |",
        "| `VERIFIED` email status | Hunter, Snov or ZeroBounce | Addresses stay `UNKNOWN` and cannot be emailed under default settings |",
        "| Draft/send/reply tracking | Google OAuth client (free) | Messages stay in the approval queue; copy and send manually |",
        "| Lighthouse mobile score | PageSpeed API key (free) | HTML-level audit only |",
        "| Background automation | Vercel Cron (daily on Hobby) or an external worker (optional) | Manual runs from the dashboard |", ""]
(ROOT / "API_REQUIREMENTS_REPORT.md").write_text("\n".join(out))
print("wrote API_REQUIREMENTS_REPORT.md")
