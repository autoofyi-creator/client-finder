"""Central configuration + integration registry (single source of truth for docs and the dashboard)."""
from __future__ import annotations

import os


def env(name: str, default: str = "") -> str:
    return (os.environ.get(name) or default).strip()


def is_vercel() -> bool:
    return bool(env("VERCEL"))


SERVICES = {
    "website_development": "Website development",
    "website_redesign": "Website redesign",
    "digital_marketing": "Digital marketing",
    "seo": "SEO",
    "social_media": "Social media marketing",
    "ai_video": "AI video creation and editing",
    "ai_automation": "AI automation services",
}

DEFAULT_QUERIES = [
    '"I need a website developer"',
    '"looking for a web designer"',
    '"need an SEO expert"',
    '"looking for a digital marketing agency"',
    '"need AI videos for my business"',
    '"looking for an AI automation developer"',
    '"need someone to redesign my website"',
    '"looking for a social media manager"',
    '"hiring video editor for my business"',
    '"need to automate my business with AI"',
]

# kind: app | database | llm | search | email_finder | email_verifier | email_send | audit | social | source
INTEGRATIONS: list[dict] = [
    dict(key="app", name="App security (admin login)", kind="app", mandatory=True,
         env=["ADMIN_PASSWORD", "SECRET_KEY"], optional_env=["CRON_SECRET"],
         purpose="Protects the dashboard and signs session cookies. CRON_SECRET authenticates Vercel Cron.",
         why="Without it anyone who finds your URL could read leads or trigger sends.",
         free="Not applicable", card="No", url="", cost="Free",
         setup="Generate long random values: python -c \"import secrets;print(secrets.token_urlsafe(32))\""),
    dict(key="database", name="Supabase (PostgreSQL)", kind="database", mandatory=True,
         env=["DATABASE_URL"], optional_env=[],
         purpose="Persistent database for leads, contacts, messages, jobs and suppression lists.",
         why="Vercel functions have no persistent disk, so every record must live in an external database.",
         free="Yes (free projects; may pause after a period of inactivity)", card="No for the free plan",
         url="https://supabase.com/dashboard", cost="Free; paid plans from about $25/month",
         setup="Project Settings > Database > Connection string > use the pooled (Supavisor) URI."),
    dict(key="anthropic", name="Anthropic Claude API", kind="llm", mandatory=False,
         env=["ANTHROPIC_API_KEY"], optional_env=["ANTHROPIC_MODEL"],
         purpose="Semantic intent classification, company research summaries, personalised message writing, reply analysis.",
         why="Without it the app falls back to keyword rules and templates, clearly labelled 'heuristic'/'template'.",
         free="No ongoing free API tier (prepaid credits)", card="Yes (to buy credits)",
         url="https://console.anthropic.com/", cost="Pay per token; estimate a few US cents per fully processed lead (depends on model)",
         setup="Console > API Keys > Create key."),
    dict(key="serper", name="Serper (Google search results API)", kind="search", mandatory=False,
         env=["SERPER_API_KEY"], optional_env=[],
         purpose="Web discovery: finds public posts/pages where people ask for services, plus company websites and public LinkedIn profile snippets.",
         why="Main discovery engine. Without any search API only Hacker News and your RSS feeds are searched.",
         free="Yes: about 2,500 free queries on signup", card="No",
         url="https://serper.dev/", cost="Free credits, then roughly $1 per 1,000 queries on bundles",
         setup="Sign up > API key."),
    dict(key="tavily", name="Tavily Search API (alternative)", kind="search", mandatory=False,
         env=["TAVILY_API_KEY"], optional_env=[],
         purpose="Alternative search provider.", why="Use instead of / alongside Serper.",
         free="Yes: about 1,000 credits per month", card="No",
         url="https://app.tavily.com/", cost="Free tier, then pay-as-you-go", setup="Dashboard > API key."),
    dict(key="brave", name="Brave Search API (alternative)", kind="search", mandatory=False,
         env=["BRAVE_SEARCH_API_KEY"], optional_env=[],
         purpose="Alternative search provider.", why="Independent index.",
         free="$5/month credit (about 1,000 queries); attribution required", card="Yes (required even for the free credit)",
         url="https://api-dashboard.search.brave.com/", cost="About $5 per 1,000 requests after credit",
         setup="Subscribe to the Search plan, then create a key."),
    dict(key="hunter", name="Hunter.io", kind="email_finder", mandatory=False,
         env=["HUNTER_API_KEY"], optional_env=[],
         purpose="Finds business emails for a domain and verifies addresses.",
         why="Primary provider for emails that are not published on the company's own site.",
         free="Yes: 50 credits/month incl. API", card="No",
         url="https://hunter.io/users/sign_up", cost="Paid from about $49/month (2,000 credits)",
         setup="Dashboard > API."),
    dict(key="snov", name="Snov.io", kind="email_finder", mandatory=False,
         env=["SNOV_CLIENT_ID", "SNOV_CLIENT_SECRET"], optional_env=[],
         purpose="Alternative email finder and verifier (v2 async API).",
         why="Second source / second verification opinion.",
         free="50 credits/month on the free plan; API access on free plans is reported inconsistently, check your account", card="No for free plan",
         url="https://snov.io/", cost="Paid from about $39/month", setup="Account settings > API."),
    dict(key="zerobounce", name="ZeroBounce (email verification)", kind="email_verifier", mandatory=False,
         env=["ZEROBOUNCE_API_KEY"], optional_env=[],
         purpose="Dedicated email verification including catch-all detection.",
         why="Emails are only labelled VERIFIED after a provider says so.",
         free="Small monthly free allowance (verify current amount)", card="No for the free allowance",
         url="https://www.zerobounce.net/", cost="Pay-as-you-go credit packs", setup="API > API keys."),
    dict(key="gmail", name="Google Gmail API (OAuth)", kind="email_send", mandatory=False,
         env=["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"], optional_env=["GOOGLE_REDIRECT_URI"],
         purpose="Save drafts, send approved emails from your own mailbox, read replies and bounces.",
         why="Required only for sending and reply management; the app is fully usable for research without it.",
         free="Yes", card="No (no billing needed for Gmail API)",
         url="https://console.cloud.google.com/apis/credentials", cost="Free (Gmail daily sending limits apply)",
         setup="Create OAuth client (Web). Add redirect URI <your-url>/api/gmail/callback. Then press Connect Gmail in the dashboard."),
    dict(key="pagespeed", name="Google PageSpeed Insights API", kind="audit", mandatory=False,
         env=["PAGESPEED_API_KEY"], optional_env=[],
         purpose="Real mobile performance score for the website audit.",
         why="Without it the audit still checks HTML-level issues but reports no Lighthouse score.",
         free="Yes", card="No", url="https://developers.google.com/speed/docs/insights/v5/get-started",
         cost="Free (quota limits)", setup="Enable PageSpeed Insights API in Google Cloud, create an API key."),
    dict(key="linkedin", name="LinkedIn (manual-assist mode)", kind="social", mandatory=False,
         env=[], optional_env=[],
         purpose="Prepared connection notes/messages and profile links. You send them yourself.",
         why="LinkedIn offers no general-purpose official prospecting/outreach API; scraping is prohibited, so nothing is automated.",
         free="Not applicable", card="No", url="https://www.linkedin.com/", cost="Free",
         setup="No keys. Use the Open profile and Copy message buttons."),
    dict(key="free_sources", name="Hacker News + RSS feeds (built in)", kind="source", mandatory=False,
         env=[], optional_env=[],
         purpose="Public Hacker News search (Algolia API) and RSS feeds you configure.",
         why="Keyless discovery sources.", free="Yes", card="No", url="https://hn.algolia.com/api", cost="Free",
         setup="Add RSS feed URLs in Settings."),
]


def registry() -> dict[str, dict]:
    return {i["key"]: i for i in INTEGRATIONS}


def configured_vars(item: dict) -> tuple[list[str], list[str]]:
    present = [v for v in item["env"] if env(v)]
    missing = [v for v in item["env"] if not env(v)]
    return present, missing


def search_provider() -> str | None:
    for key, var in (("serper", "SERPER_API_KEY"), ("tavily", "TAVILY_API_KEY"), ("brave", "BRAVE_SEARCH_API_KEY")):
        if env(var):
            return key
    return None


def job_time_budget() -> float:
    try:
        return float(env("JOB_TIME_BUDGET_SECONDS", "40"))
    except ValueError:
        return 40.0
