"""Action endpoints: auth, stats, integrations, jobs, messages, settings, Gmail OAuth, cron."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import RedirectResponse
from itsdangerous import BadSignature, URLSafeTimedSerializer
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from agents import discovery, orchestrator, outreach, message_writer, website_audit
from agents.outreach import SendBlocked
from config import INTEGRATIONS, SERVICES, configured_vars, env, job_time_budget, search_provider
from database.db import database_url, get_db
from integrations import anthropic_client, gmail
from integrations.base import IntegrationError
from models import schemas as S
from models.orm import Audit, Company, Contact, Job, Lead, Message, Reply, Setting, as_dict, utcnow
from services import jobs, sample_data, security
from services import settings_store as ss
from services.suppression import suppress

public = APIRouter(prefix="/api")
router = APIRouter(prefix="/api", dependencies=[Depends(security.require_auth)])
cron = APIRouter(prefix="/api/cron", dependencies=[Depends(security.require_cron)])


# ---------- public ----------
@public.get("/health")
def health():
    try:
        db_ok = database_url() is not None
    except Exception:  # noqa: BLE001
        db_ok = False
    return {"status": "ok", "database_configured": db_ok, "auth_configured": security.auth_configured()}


@public.post("/login")
def login(body: S.LoginIn, request: Request, response: Response):
    ip = request.client.host if request.client else "?"
    if not security.auth_configured():
        raise HTTPException(503, "NEEDS CONFIGURATION: set ADMIN_PASSWORD and SECRET_KEY (16+ chars) in your environment.")
    if security.rate_limited(ip):
        raise HTTPException(429, "Too many attempts. Try again later.")
    if not security.check_password(body.password):
        security.record_failure(ip)
        raise HTTPException(401, "Wrong password")
    response.set_cookie(security.COOKIE, security.make_session(), max_age=security.MAX_AGE, httponly=True,
                        samesite="strict", secure=request.url.scheme == "https" or bool(env("VERCEL")))
    return {"ok": True}


@public.post("/logout")
def logout(response: Response):
    response.delete_cookie(security.COOKIE)
    return {"ok": True}


# ---------- integrations ----------
def integration_status(db: Session) -> list[dict]:
    out = []
    for it in INTEGRATIONS:
        present, missing = configured_vars(it)
        key = it["key"]
        if key == "free_sources":
            st, note = "CONNECTED", "No key needed"
        elif key == "linkedin":
            st, note = "NOT CONNECTED", "Manual-assist mode only: no official API is used"
        elif key == "database":
            try:
                st = "CONNECTED" if database_url() else "NEEDS CONFIGURATION"
            except Exception:  # noqa: BLE001
                st = "ERROR"
            note = "" if st == "CONNECTED" else "Set DATABASE_URL"
        elif key == "gmail":
            if not gmail.credentials_present():
                st, note = ("NEEDS CONFIGURATION" if present else "NOT CONNECTED"), "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET"
            elif not gmail.is_connected(db):
                st, note = "NEEDS CONFIGURATION", "Credentials set. Press Connect Gmail to authorize."
            else:
                st, note = "CONNECTED", ss.get(db, "gmail_address") or ""
        elif key == "pagespeed":
            st, note = ("CONNECTED", "") if present else ("NOT CONNECTED", "Optional; audits skip Lighthouse score")
        elif key == "app":
            st = "CONNECTED" if security.auth_configured() else "NEEDS CONFIGURATION"
            note = "" if st == "CONNECTED" else "Set ADMIN_PASSWORD and SECRET_KEY (16+ chars)"
        else:
            if not it["env"] or not missing:
                st, note = "CONNECTED", ""
            elif present:
                st, note = "NEEDS CONFIGURATION", "Missing: " + ", ".join(missing)
            else:
                st, note = "NOT CONNECTED", ""
            if st == "CONNECTED":
                row = db.get(Setting, f"int_error:{key}")
                if row and row.value:
                    st, note = "ERROR", str(row.value)
        out.append({**{k: it[k] for k in ("key", "name", "kind", "mandatory", "env", "optional_env", "purpose", "why", "free", "card", "url", "cost", "setup")},
                    "status": st, "note": note})
    return out


@router.get("/integrations")
def integrations(db: Session = Depends(get_db)):
    return {"integrations": integration_status(db), "search_provider": search_provider(), "claude_model": anthropic_client.model_name()}


@router.post("/integrations/{key}/test")
def test_integration(key: str, db: Session = Depends(get_db)):
    """Makes one tiny live call to prove the credentials work. Errors are stored and shown as ERROR."""
    try:
        if key == "anthropic":
            class P(S.BaseModel):  # type: ignore[attr-defined]
                ok: bool
            anthropic_client.complete_json('Return {"ok": true}', "ping", P, 50)
        elif key in ("serper", "tavily", "brave"):
            from integrations import search
            search.search("test", num=1, recent=False)
        elif key == "hunter":
            from integrations import hunter
            hunter._get("/account")
        elif key == "zerobounce":
            from integrations import zerobounce
            zerobounce.verify("test@example.com")
        elif key == "snov":
            from integrations import snov
            from services import http
            with http.client() as c:
                snov._token(c)
        elif key == "gmail":
            gmail._access_token(db)
        else:
            return {"ok": False, "message": "No live test for this integration"}
    except Exception as e:  # noqa: BLE001
        ss.set_value(db, f"int_error:{key}", str(e)[:300])
        return {"ok": False, "message": str(e)[:300]}
    ss.set_value(db, f"int_error:{key}", None)
    return {"ok": True, "message": "Credentials work"}


# ---------- Gmail OAuth ----------
def _redirect_uri(request: Request) -> str:
    return env("GOOGLE_REDIRECT_URI") or str(request.base_url).rstrip("/") + "/api/gmail/callback"


def _state() -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(env("SECRET_KEY"), salt="gmail-oauth")


@router.get("/gmail/connect")
def gmail_connect(request: Request):
    if not gmail.credentials_present():
        raise HTTPException(400, "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET first")
    return {"url": gmail.authorize_url(_redirect_uri(request), _state().dumps("gmail"))}


@public.get("/gmail/callback")
def gmail_callback(request: Request, code: str | None = None, state: str | None = None, error: str | None = None, db: Session = Depends(get_db)):
    if not security.session_valid(request.cookies.get(security.COOKIE)):
        raise HTTPException(401, "Log in first")
    try:
        _state().loads(state or "", max_age=900)
    except BadSignature:
        raise HTTPException(400, "Invalid OAuth state")
    if error or not code:
        return RedirectResponse(f"/#integrations?gmail=error")
    try:
        gmail.exchange_code(db, code, _redirect_uri(request))
    except IntegrationError as e:
        return RedirectResponse(f"/#integrations?gmail=error")
    return RedirectResponse("/#integrations?gmail=connected")


@router.post("/gmail/disconnect")
def gmail_disconnect(db: Session = Depends(get_db)):
    gmail.disconnect(db)
    return {"ok": True}


# ---------- stats ----------
@router.get("/stats")
def stats(db: Session = Depends(get_db)):
    def cnt(model, *where):
        return db.execute(select(func.count()).select_from(model).where(*where)).scalar_one()
    real_l = Lead.is_sample.is_(False)
    funnel = {
        "discovered": cnt(Lead, real_l, Lead.status != "discarded"),
        "high_intent": cnt(Lead, real_l, Lead.intent == "HIGH"),
        "verified_emails": cnt(Contact, Contact.is_sample.is_(False), Contact.email_status == "VERIFIED"),
        "pending_approval": cnt(Message, Message.is_sample.is_(False), Message.status == "pending_approval"),
        "sent": cnt(Message, Message.is_sample.is_(False), Message.status == "sent", Message.channel == "email"),
        "replies": cnt(Reply, Reply.lead_id.in_(select(Lead.id).where(real_l))),
        "interested": cnt(Lead, real_l, Lead.status == "interested"),
        "meetings": cnt(Lead, real_l, Lead.status == "meeting"),
        "converted": cnt(Lead, real_l, Lead.status == "converted"),
    }
    funnel["invalid_emails"] = cnt(Contact, Contact.is_sample.is_(False), Contact.email_status == "INVALID")

    def grouped(col):
        rows = db.execute(select(col, func.count()).where(real_l, Lead.status != "discarded").group_by(col)).all()
        return {str(k or "unknown"): v for k, v in rows}
    return {"funnel": funnel, "by_intent": grouped(Lead.intent), "by_service": grouped(Lead.service_needed),
            "by_source": grouped(Lead.source_type), "by_country": grouped(Lead.country), "by_status": grouped(Lead.status),
            "sample_rows": cnt(Lead, Lead.is_sample.is_(True)), "sent_today": outreach.sent_today(db),
            "daily_limit": ss.get(db, "daily_send_limit"), "report": ss.get(db, "sales_manager_report")}


# ---------- jobs ----------
@router.post("/discovery/run")
def run_discovery(body: S.DiscoveryIn, db: Session = Depends(get_db)):
    j = jobs.enqueue(db, "discovery", body.model_dump(exclude_none=True))
    return {"job_id": j.id}


@router.post("/discovery/businesses")
def run_business_discovery(body: S.BusinessDiscoveryIn, db: Session = Depends(get_db)):
    j = jobs.enqueue(db, "discovery", {"business": body.model_dump()})
    return {"job_id": j.id}


@router.post("/jobs/run")
def run_jobs(db: Session = Depends(get_db)):
    return jobs.run_queue(db, orchestrator.HANDLERS, job_time_budget())


@router.post("/jobs/retry-incomplete")
def retry_incomplete(db: Session = Depends(get_db)):
    return {"queued": orchestrator.requeue_incomplete(db)}


@router.post("/sales-manager/run")
def run_sales_manager(db: Session = Depends(get_db)):
    jobs.enqueue(db, "sales_manager")
    return jobs.run_queue(db, orchestrator.HANDLERS, job_time_budget())


@router.post("/replies/sync")
def sync_replies(db: Session = Depends(get_db)):
    jobs.enqueue(db, "reply_sync")
    return jobs.run_queue(db, orchestrator.HANDLERS, job_time_budget())


# ---------- leads ----------
@router.post("/leads")
def add_lead(body: S.ManualLeadIn, db: Session = Depends(get_db)):
    if not (body.url or body.text or body.company or body.website):
        raise HTTPException(422, "Provide a URL, text, company or website")
    lead = discovery.add_manual(db, url=str(body.url) if body.url else None, text=body.text, name=body.name, company=body.company, website=body.website)
    jobs.enqueue(db, "pipeline_lead", {"lead_id": lead.id})
    return {"lead_id": lead.id}


@router.get("/leads/{lead_id}")
def lead_detail(lead_id: int, db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead:
        raise HTTPException(404, "Not found")
    q = lambda M: [as_dict(x) for x in db.execute(select(M).where(M.lead_id == lead_id).order_by(M.id)).scalars()]  # noqa: E731
    return {"lead": as_dict(lead), "company": as_dict(db.get(Company, lead.company_id)) if lead.company_id else None,
            "contacts": q(Contact), "audits": q(Audit), "messages": q(Message), "replies": q(Reply)}


@router.post("/leads/{lead_id}/status")
def set_status(lead_id: int, body: S.LeadStatusIn, db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead:
        raise HTTPException(404, "Not found")
    lead.status = body.status
    return {"ok": True}


@router.post("/leads/{lead_id}/process")
def process_now(lead_id: int, force: bool = False, db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead:
        raise HTTPException(404, "Not found")
    if lead.is_sample:
        raise HTTPException(400, "Sample leads are not processed")
    if force:
        lead.meta = {**(lead.meta or {}), "force": True}
    jobs.enqueue(db, "pipeline_lead", {"lead_id": lead_id})
    return {"queued": True}


@router.post("/audits/run")
def run_audit(body: S.AuditIn, db: Session = Depends(get_db)):
    company = db.get(Company, body.company_id) if body.company_id else None
    a = website_audit.audit_url(db, body.url, company, None)
    return as_dict(a)


# ---------- messages ----------
@router.post("/messages/generate")
def generate(body: S.GenerateIn, db: Session = Depends(get_db)):
    lead = db.get(Lead, body.lead_id)
    if not lead:
        raise HTTPException(404, "Lead not found")
    contact = db.get(Contact, body.contact_id) if body.contact_id else None
    if contact is None:
        cs = db.execute(select(Contact).where(Contact.lead_id == lead.id)).scalars().all()
        pick = [c for c in cs if (c.email if body.channel == "email" else c.linkedin_url)]
        contact = pick[0] if pick else None
    if body.channel == "linkedin":
        if not contact:
            raise HTTPException(422, "No LinkedIn contact for this lead")
        msgs = message_writer.write_linkedin(db, lead, contact, body.service)
        return {"messages": [as_dict(m) for m in msgs]}
    m = message_writer.write_email(db, lead, contact, body.service, status="draft")
    return {"messages": [as_dict(m)]}


def _msg(db: Session, mid: int) -> Message:
    m = db.get(Message, mid)
    if not m:
        raise HTTPException(404, "Not found")
    return m


@router.post("/messages/{mid}/edit")
def edit_msg(mid: int, body: S.MessageEditIn, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status == "sent":
        raise HTTPException(400, "Already sent")
    m.subject, m.body, m.generated_by = body.subject if body.subject is not None else m.subject, body.body, "human"
    if m.status == "approved":
        m.status = "pending_approval"  # edits require re-approval
    return as_dict(m)


def _act(fn, db, m):
    try:
        return as_dict(fn(db, m))
    except SendBlocked as e:
        raise HTTPException(409, {"blocked": e.reasons})


@router.post("/messages/{mid}/queue")
def queue_msg(mid: int, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status != "draft":
        raise HTTPException(409, {"blocked": [f"Message is {m.status}"]})
    m.status = "pending_approval"
    return as_dict(m)


@router.post("/messages/{mid}/approve")
def approve_msg(mid: int, db: Session = Depends(get_db)):
    return _act(outreach.approve, db, _msg(db, mid))


@router.post("/messages/{mid}/reject")
def reject_msg(mid: int, db: Session = Depends(get_db)):
    return _act(outreach.reject, db, _msg(db, mid))


@router.post("/messages/{mid}/draft")
def draft_msg(mid: int, db: Session = Depends(get_db)):
    return _act(outreach.save_draft, db, _msg(db, mid))


@router.post("/messages/{mid}/send")
def send_msg(mid: int, db: Session = Depends(get_db)):
    m = _msg(db, mid)
    if m.status in ("draft", "pending_approval") and not ss.get(db, "require_approval"):
        outreach.approve(db, m)
    try:
        return as_dict(outreach.send(db, m))
    except SendBlocked as e:
        db.commit()  # persist 'failed' status/error if Gmail rejected it
        raise HTTPException(409, {"blocked": e.reasons})


@router.post("/messages/{mid}/manual-sent")
def manual_sent(mid: int, db: Session = Depends(get_db)):
    return _act(outreach.mark_manual_sent, db, _msg(db, mid))


@router.get("/messages/preview-blockers/{mid}")
def preview_blockers(mid: int, db: Session = Depends(get_db)):
    return {"blockers": outreach.blockers(db, _msg(db, mid))}


# ---------- settings / suppression / sample ----------
@router.get("/settings")
def get_settings(db: Session = Depends(get_db)):
    s = ss.all_public(db)
    s["services"] = SERVICES
    return s


@router.put("/settings")
def put_settings(body: S.SettingsIn, db: Session = Depends(get_db)):
    for k, v in body.model_dump(exclude_none=True).items():
        if k == "rss_feeds":
            v = [str(x) for x in v]
        ss.set_value(db, k, v)
    return ss.all_public(db)


@router.post("/suppressions")
def add_suppression(body: S.SuppressIn, db: Session = Depends(get_db)):
    if not (body.email or body.domain):
        raise HTTPException(422, "email or domain required")
    return as_dict(suppress(db, email=body.email, domain=body.domain, reason=body.reason))


@router.delete("/suppressions/{sid}")
def del_suppression(sid: int, db: Session = Depends(get_db)):
    from models.orm import Suppression
    row = db.get(Suppression, sid)
    if row:
        db.delete(row)
    return {"ok": True}


@router.post("/sample/load")
def load_sample(db: Session = Depends(get_db)):
    return {"created": sample_data.load(db)}


@router.post("/sample/clear")
def clear_sample(db: Session = Depends(get_db)):
    sample_data.clear(db)
    return {"ok": True}


# ---------- cron (Vercel) ----------
@cron.get("/tick")
def cron_tick(db: Session = Depends(get_db)):
    """Daily on Vercel Hobby. Syncs replies, runs the Sales Manager, optional discovery, then drains queued jobs."""
    jobs.enqueue(db, "reply_sync")
    jobs.enqueue(db, "sales_manager")
    if ss.get(db, "auto_discovery_on_cron"):
        jobs.enqueue(db, "discovery", {})
    db.commit()
    return jobs.run_queue(db, orchestrator.HANDLERS, job_time_budget())


@router.post("/contacts/{cid}/verify")
def reverify(cid: int, db: Session = Depends(get_db)):
    from agents import email_verification
    c = db.get(Contact, cid)
    if not c or not c.email:
        raise HTTPException(404, "No email on this contact")
    v = email_verification.verify_email(c.email)
    c.email_status, c.verification = v["status"], v
    return {"id": c.id, "email_status": c.email_status, "verification": v}
