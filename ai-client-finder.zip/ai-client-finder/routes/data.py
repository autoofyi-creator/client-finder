"""Generic list/search/filter/paginate/CSV endpoints for dashboard tables."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from database.db import get_db
from models.orm import Audit, AgentRun, Company, Contact, Job, Lead, Message, Reply, Suppression, as_dict
from services.csvio import to_csv
from services.security import require_auth

router = APIRouter(prefix="/api", dependencies=[Depends(require_auth)])

LEAD_COLS = ["id", "is_sample", "name", "company_name", "country", "service_needed", "intent", "confidence", "intent_method", "score",
             "status", "stage", "source_type", "source_url", "source_date", "evidence_quote", "approach", "created_at"]


def _lead_view(model):
    return dict(model=model, search=[Lead.name, Lead.company_name, Lead.source_text, Lead.source_title, Lead.country],
                filters=["intent", "status", "service_needed", "stage", "source_type", "country"], cols=LEAD_COLS, order=Lead.score.desc().nullslast())


RES = {
    "leads": _lead_view(Lead),
    "companies": dict(model=Company, search=[Company.name, Company.domain, Company.description], filters=["country"],
                      cols=["id", "is_sample", "name", "domain", "website_url", "country", "description", "linkedin_url", "created_at"], order=Company.id.desc()),
    "contacts": dict(model=Contact, search=[Contact.name, Contact.email, Contact.title, Contact.linkedin_url],
                     filters=["email_status", "lead_id", "is_decision_maker"],
                     cols=["id", "is_sample", "lead_id", "name", "title", "is_decision_maker", "linkedin_url", "linkedin_note", "email", "email_source", "email_status", "verification", "created_at"],
                     order=Contact.id.desc()),
    "audits": dict(model=Audit, search=[Audit.url, Audit.summary], filters=["reachable", "company_id", "lead_id"],
                   cols=["id", "is_sample", "company_id", "lead_id", "url", "reachable", "status_code", "load_ms", "findings", "pagespeed", "summary", "created_at"], order=Audit.id.desc()),
    "messages": dict(model=Message, search=[Message.subject, Message.body, Message.to_email], filters=["status", "channel", "service", "lead_id"],
                     cols=["id", "is_sample", "lead_id", "contact_id", "channel", "service", "subject", "body", "status", "generated_by", "to_email", "sequence_no", "followup_of", "error", "sent_at", "created_at"],
                     order=Message.id.desc()),
    "replies": dict(model=Reply, search=[Reply.snippet, Reply.from_email, Reply.subject], filters=["classification", "lead_id"],
                    cols=["id", "lead_id", "message_id", "from_email", "subject", "snippet", "classification", "method", "summary", "received_at"], order=Reply.id.desc()),
    "jobs": dict(model=Job, search=[Job.type, Job.error], filters=["status", "type"], cols=["id", "type", "status", "attempts", "result", "error", "created_at", "finished_at"], order=Job.id.desc()),
    "agent_runs": dict(model=AgentRun, search=[AgentRun.agent, AgentRun.message], filters=["agent", "status", "lead_id"],
                       cols=["id", "agent", "lead_id", "status", "message", "duration_ms", "created_at"], order=AgentRun.id.desc()),
    "suppressions": dict(model=Suppression, search=[Suppression.email, Suppression.domain], filters=["reason"], cols=["id", "email", "domain", "reason", "created_at"], order=Suppression.id.desc()),
}


def _query(db: Session, name: str, q: str | None, filters: dict[str, str], include_sample: str, extra=None):
    cfg = RES.get(name)
    if not cfg:
        raise HTTPException(404, "Unknown resource")
    M = cfg["model"]
    stmt = select(M)
    if q:
        stmt = stmt.where(or_(*[c.ilike(f"%{q}%") for c in cfg["search"]]))
    for k, v in filters.items():
        if k == "has_linkedin" and name == "contacts" and v == "1":
            stmt = stmt.where(Contact.linkedin_url.is_not(None))
        elif k == "has_email" and name == "contacts" and v == "1":
            stmt = stmt.where(Contact.email.is_not(None))
        elif k in cfg["filters"] and v not in (None, ""):
            col = getattr(M, k)
            stmt = stmt.where(col == (v.lower() == "true" if v.lower() in ("true", "false") else (int(v) if k.endswith("_id") or k == "id" else v)))
    if hasattr(M, "is_sample"):
        if include_sample == "only":
            stmt = stmt.where(M.is_sample.is_(True))
        elif include_sample != "all":
            stmt = stmt.where(M.is_sample.is_(False))
    return cfg, M, stmt


def _filters(request_query: dict) -> dict:
    return {k: v for k, v in request_query.items() if k not in ("q", "page", "page_size", "samples")}


from fastapi import Request  # noqa: E402


@router.get("/data/{name}")
def list_rows(name: str, request: Request, q: str | None = None, page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=200),
              samples: str = "hide", db: Session = Depends(get_db)):
    cfg, M, stmt = _query(db, name, q, _filters(dict(request.query_params)), samples)
    total = db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
    rows = db.execute(stmt.order_by(cfg["order"]).limit(page_size).offset((page - 1) * page_size)).scalars().all()
    data = [{c: as_dict(r).get(c) for c in cfg["cols"]} for r in rows]
    return {"total": total, "page": page, "page_size": page_size, "rows": data}


@router.get("/data/{name}/export.csv")
def export_csv(name: str, request: Request, q: str | None = None, samples: str = "hide", db: Session = Depends(get_db)):
    cfg, M, stmt = _query(db, name, q, _filters(dict(request.query_params)), samples)
    rows = db.execute(stmt.order_by(cfg["order"]).limit(10000)).scalars().all()
    body = to_csv([as_dict(r) for r in rows], cfg["cols"])
    return Response(body, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})
