/* AI Client Finder dashboard. All dynamic text is escaped with esc(); web-sourced content is untrusted. */
const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeUrl = u => /^https?:\/\//i.test(u || '') ? u : '';
const fmtDate = d => d ? new Date(d).toLocaleDateString(undefined, {year:'numeric', month:'short', day:'numeric'}) : 'unknown';
const SERVICES = {website_development:'Website development',website_redesign:'Website redesign',digital_marketing:'Digital marketing',seo:'SEO',social_media:'Social media',ai_video:'AI video',ai_automation:'AI automation'};

async function api(path, opts = {}) {
  const o = {credentials:'same-origin', ...opts, headers:{'X-CSRF':'1', ...(opts.body ? {'Content-Type':'application/json'} : {}), ...(opts.headers||{})}};
  if (o.body && typeof o.body !== 'string') o.body = JSON.stringify(o.body);
  const r = await fetch(path, o);
  if (r.status === 401) { location.reload(); throw new Error('Signed out'); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const d = j.detail; throw new Error(d && d.blocked ? d.blocked.join('; ') : (typeof d === 'string' ? d : JSON.stringify(d || r.statusText))); }
  return j;
}
function toast(msg, bad) { const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg; $('#toasts').append(t); setTimeout(() => t.remove(), bad ? 7000 : 3500); }
const act = async (fn, ok) => { try { const r = await fn(); if (ok) toast(ok); return r; } catch (e) { toast(e.message, true); } };
const badge = (v, label) => `<span class="badge b-${esc(v)}">${esc(label ?? v)}</span>`;
const sampleTag = r => r.is_sample ? ' <span class="badge b-sample">SAMPLE</span>' : '';
const link = (u, t) => safeUrl(u) ? `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${esc(t || u)}</a>` : esc(t || u || '');
const copy = async t => { try { await navigator.clipboard.writeText(t); toast('Copied'); } catch { toast('Copy failed: select the text manually', true); } };

const NAV = [
  ['Overview', [['overview','Overview']]],
  ['Find', [['find','Find Clients'],['intent','Buying Intent Monitor'],['companies','Companies']]],
  ['Prospects', [['linkedin','LinkedIn Prospects'],['emails','Verified Emails'],['audits','Website Audits']]],
  ['Outreach', [['generator','AI Message Generator'],['approvals','Approval Queue'],['campaigns','Email Campaigns'],['replies','Replies']]],
  ['Track', [['pipeline','Sales Pipeline'],['analytics','Analytics']]],
  ['System', [['integrations','API Integrations'],['settings','Settings']]],
];
const PAGES = {};
const main = () => $('#main');

/* ---------- generic table ---------- */
function dataTable(host, o) {
  const st = {page:1, q:'', f:{...(o.fixed||{})}, samples: o.samples || 'hide'};
  host.innerHTML = `<div class="toolbar"><input type="search" placeholder="Search" aria-label="Search" id="q">${(o.filters||[]).map(f =>
    `<select data-f="${f.key}" aria-label="${esc(f.label)}"><option value="">${esc(f.label)}: all</option>${f.options.map(x => `<option ${f.def===x?'selected':''}>${esc(x)}</option>`).join('')}</select>`).join('')}
    <select id="smp" aria-label="Sample data"><option value="hide">Real data only</option><option value="all">Include sample data</option><option value="only">Sample data only</option></select>
    <span class="spacer"></span><a class="btn" id="csv" href="#">Export CSV</a></div><div class="panel tw" id="tb"></div><div class="pager" id="pg"></div>`;
  (o.filters||[]).forEach(f => { if (f.def) st.f[f.key] = f.def; });
  $('#smp', host).value = st.samples;
  const qs = () => { const p = new URLSearchParams({...st.f, q: st.q, samples: st.samples}); [...p.keys()].forEach(k => p.get(k) === '' && p.delete(k)); return p; };
  async function load() {
    const p = qs(); p.set('page', st.page); p.set('page_size', o.pageSize || 25);
    $('#csv', host).href = `/api/data/${o.resource}/export.csv?${qs()}`;
    let d; try { d = await api(`/api/data/${o.resource}?${p}`); } catch (e) { $('#tb', host).innerHTML = `<div class="empty">${esc(e.message)}</div>`; return; }
    if (!d.rows.length) $('#tb', host).innerHTML = `<div class="empty">${esc(o.empty || 'Nothing here yet.')}</div>`;
    else {
      $('#tb', host).innerHTML = `<table><thead><tr>${o.columns.map(c => `<th>${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${d.rows.map((r, i) =>
        `<tr class="${o.onRow ? 'click' : ''}" data-i="${i}">${o.columns.map(c => `<td>${c.render ? c.render(r) : esc(r[c.key])}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
      host.querySelectorAll('tbody tr').forEach(tr => tr.onclick = e => { if (o.onRow && !e.target.closest('a,button,select,input')) o.onRow(d.rows[+tr.dataset.i]); });
      o.after && o.after(host, d.rows, load);
    }
    const pages = Math.max(1, Math.ceil(d.total / d.page_size));
    $('#pg', host).innerHTML = `<span>${d.total} result${d.total===1?'':'s'}</span><button class="btn sm" id="pv" ${st.page<=1?'disabled':''}>Previous</button><span>Page ${st.page} of ${pages}</span><button class="btn sm" id="nx" ${st.page>=pages?'disabled':''}>Next</button>`;
    $('#pv', host).onclick = () => { st.page--; load(); }; $('#nx', host).onclick = () => { st.page++; load(); };
  }
  let t; $('#q', host).oninput = e => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value; st.page = 1; load(); }, 300); };
  host.querySelectorAll('select[data-f]').forEach(s => s.onchange = () => { st.f[s.dataset.f] = s.value; st.page = 1; load(); });
  $('#smp', host).onchange = e => { st.samples = e.target.value; st.page = 1; load(); };
  load(); return load;
}
const INTENTS = ['HIGH','MEDIUM','LOW','NONE','UNCLASSIFIED'];
const LEAD_STATUS = ['new','qualified','contacted','replied','interested','meeting','converted','lost','suppressed','discarded'];
const header = (t, s) => `<h1 class="page">${esc(t)}</h1><p class="sub">${esc(s)}</p>`;

/* ---------- lead drawer ---------- */
async function openLead(id) {
  const d = await act(() => api(`/api/leads/${id}`)); if (!d) return;
  const L = d.lead, C = d.company;
  $('#dbody').innerHTML = `<h2 style="font:400 28px var(--display)">${esc(L.company_name || L.name || 'Lead #' + L.id)}${sampleTag(L)}</h2>
  <div class="row">${badge(L.intent)} ${badge(L.status)} <span class="muted">score ${L.score ?? '–'} · confidence ${L.confidence != null ? Math.round(L.confidence*100)+'%' : '–'} (${esc(L.intent_method || 'n/a')})</span></div>
  <div class="panel" style="margin-top:12px"><dl class="kv"><dt>Who</dt><dd>${esc(L.name || 'unknown')}${L.name_is_handle ? ' (forum handle, not a verified name)' : ''}</dd>
  <dt>Company</dt><dd>${esc(L.company_name || 'unknown')}</dd><dt>Country</dt><dd>${esc(L.country || 'not stated')}</dd>
  <dt>Service needed</dt><dd>${esc(SERVICES[L.service_needed] || L.service_needed || 'unknown')}</dd>
  <dt>Source</dt><dd>${link(L.source_url)}<br><span class="muted">published ${fmtDate(L.source_date)} · found via ${esc(L.discovered_via || '')}</span></dd>
  <dt>Their words</dt><dd>${L.evidence_quote ? '“' + esc(L.evidence_quote) + '”' : '<span class="muted">no verbatim request found</span>'}</dd>
  <dt>Why this intent</dt><dd>${esc(L.intent_reason || '')}</dd><dt>Approach</dt><dd>${esc(L.approach || '')}</dd>
  <dt>Score parts</dt><dd>${esc(JSON.stringify(L.score_breakdown || {}))}</dd>${L.last_error ? `<dt>Last error</dt><dd class="err">${esc(L.last_error)}</dd>` : ''}</dl></div>
  <div class="row"><button class="btn" id="l-proc">Re-run pipeline</button><button class="btn" id="l-force">Force full enrichment</button>
  <select id="l-st">${LEAD_STATUS.slice(0,9).map(s => `<option ${s===L.status?'selected':''}>${s}</option>`).join('')}</select></div>
  ${C ? `<h2 style="margin-top:18px">Company</h2><div class="panel"><b>${esc(C.name)}</b> ${link(C.website_url)}<p>${esc(C.description || '')}</p><p class="muted">${esc((C.research||{}).summary || '')}</p></div>` : ''}
  <h2>Contacts</h2><div class="panel">${d.contacts.length ? d.contacts.map(c => `<p><b>${esc(c.name || 'Unnamed')}</b> ${esc(c.title || '')} ${c.email ? esc(c.email) + ' ' + badge(c.email_status) : ''} ${c.linkedin_url ? link(c.linkedin_url, 'LinkedIn') : ''}</p>`).join('') : '<span class="muted">None found. Contact via the original post if appropriate.</span>'}</div>
  <h2>Website audit</h2>${d.audits.map(a => auditHtml(a)).join('') || '<div class="panel muted">No audit yet.</div>'}
  <h2>Messages</h2>${d.messages.map(m => `<div class="msg"><div class="row">${badge(m.status)} <span>${esc(m.channel)}</span><span class="muted">${esc(m.generated_by||'')}</span></div><pre>${esc((m.subject ? m.subject + '\n\n' : '') + m.body)}</pre></div>`).join('') || '<div class="panel muted">None yet.</div>'}
  <h2>Replies</h2>${d.replies.map(r => `<div class="panel">${badge(r.classification)} ${esc(r.from_email)}<p>${esc(r.snippet)}</p></div>`).join('') || '<div class="panel muted">No replies.</div>'}`;
  $('#drawer').hidden = false;
  $('#l-proc').onclick = () => act(() => api(`/api/leads/${id}/process`, {method:'POST'}), 'Queued. Press "Run queued jobs" on Find Clients.');
  $('#l-force').onclick = () => act(() => api(`/api/leads/${id}/process?force=true`, {method:'POST'}), 'Queued with full enrichment');
  $('#l-st').onchange = e => act(() => api(`/api/leads/${id}/status`, {method:'POST', body:{status:e.target.value}}), 'Status updated');
}
const auditHtml = a => `<div class="panel"><div class="row"><b>${link(a.url)}</b>${badge(a.reachable ? 'ok' : 'error', a.reachable ? 'reachable' : 'unreachable')}<span class="muted">${a.load_ms ?? '–'} ms${a.pagespeed && a.pagespeed.mobile_performance_score != null ? ' · mobile score ' + a.pagespeed.mobile_performance_score : ''}</span>${a.is_sample ? '<span class="badge b-sample">SAMPLE</span>' : ''}</div>
  <p>${esc(a.summary || '')}</p>${(a.findings||[]).map(f => `<p>${badge({high:'INVALID',medium:'MEDIUM',low:'LOW'}[f.severity], f.severity)} <b>${esc(f.area)}</b>: ${esc(f.observed)} <span class="muted">${esc(f.impact)}</span></p>`).join('')}</div>`;
$('#dclose').onclick = () => $('#drawer').hidden = true;
document.querySelector('.drawer-bg').onclick = () => $('#drawer').hidden = true;

const leadCols = [
  {label:'Intent', render:r => badge(r.intent) + sampleTag(r)}, {label:'Score', key:'score'},
  {label:'Who', render:r => `<b>${esc(r.company_name || r.name || '–')}</b><br><span class="muted">${esc(r.company_name && r.name ? r.name : '')}</span>`},
  {label:'Needs', render:r => esc(SERVICES[r.service_needed] || r.service_needed || '–')},
  {label:'Evidence', render:r => `<div class="clip">${r.evidence_quote ? '“' + esc(r.evidence_quote) + '”' : '<span class="muted">none</span>'}</div>`},
  {label:'Source', render:r => link(r.source_url, r.source_type) + `<br><span class="muted">${fmtDate(r.source_date)}</span>`},
  {label:'Status', render:r => badge(r.status)},
];

/* ---------- pages ---------- */
PAGES.overview = async () => {
  const [s, ig] = await Promise.all([api('/api/stats'), api('/api/integrations')]);
  const f = s.funnel, steps = [['discovered','Leads discovered'],['high_intent','High intent'],['verified_emails','Verified emails'],['pending_approval','Pending approval'],['sent','Emails sent'],['replies','Replies'],['interested','Interested'],['meetings','Meetings'],['converted','Converted']];
  const max = Math.max(1, ...steps.map(x => f[x[0]]));
  const need = ig.integrations.filter(i => i.mandatory && i.status !== 'CONNECTED');
  main().innerHTML = header('Overview', 'Where every prospect stands, from first signal to signed client.') +
    (need.length ? `<div class="notice bad"><b>Setup needed:</b> ${need.map(i => esc(i.name) + ' (' + esc(i.status) + ')').join(', ')}. See <a href="#integrations">API Integrations</a>.</div>` : '') +
    (s.sample_rows ? `<div class="notice">Sample data is loaded and excluded from every number below. Remove it in <a href="#settings">Settings</a>.</div>` : '') +
    `<div class="panel"><h2>Pipeline</h2><div class="funnel">${steps.map((x, i) => `<div class="seg" style="flex:${Math.max(.6, f[x[0]] / max * 3)}"><span>${x[1]}</span><b>${f[x[0]]}</b><em>${i && f[steps[i-1][0]] ? Math.round(f[x[0]] / f[steps[i-1][0]] * 100) + '% of previous' : '&nbsp;'}</em></div>`).join('')}</div>
    <p class="hint">Counts exclude sample data. ${esc(f.invalid_emails)} invalid emails were found and blocked from sending.</p></div>
    <div class="grid g2"><div class="panel"><h2>Next actions</h2>${(s.report ? s.report.recommendations : ['Run the Sales Manager from Analytics for tailored recommendations.']).map(r => `<p>${esc(r)}</p>`).join('')}
    <div class="row"><a class="btn primary" href="#find">Find clients</a><a class="btn" href="#approvals">Review approvals</a></div></div>
    <div class="panel"><h2>Today</h2><p>${s.sent_today} of ${s.daily_limit} emails sent today.</p><p class="muted">Sending always requires your approval.</p></div></div>`;
};

PAGES.find = async () => {
  main().innerHTML = header('Find Clients', 'Searches permitted public sources only (search APIs you connect, Hacker News, your RSS feeds). It does not search the whole internet and never bypasses logins, paywalls or CAPTCHAs.') +
  `<div class="grid g2"><div class="panel"><h2>Search for buyers</h2><p class="hint">Runs your saved search phrases in small batches so each run finishes inside serverless time limits.</p>
  <label for="dq">Custom phrases (optional, one per line)</label><textarea id="dq" style="min-height:80px" placeholder='"need a website developer"'></textarea>
  <div class="row"><button class="btn primary" id="drun">Queue discovery</button><button class="btn" id="jrun">Run queued jobs now</button></div><p id="jres" class="hint"></p></div>
  <div class="panel"><h2>Add a prospect</h2><div class="field"><label for="ml-u">Post or page URL</label><input id="ml-u" placeholder="https://…"><label for="ml-t">Pasted text (what they said)</label><textarea id="ml-t" style="min-height:70px"></textarea>
  <label for="ml-c">Company</label><input id="ml-c"><label for="ml-w">Company website</label><input id="ml-w" placeholder="example.com"></div><button class="btn" id="ml-go" style="margin-top:10px">Add and analyse</button></div></div>
  <div class="panel"><h2>Find businesses by category</h2><div class="row"><input id="bc" placeholder="e.g. dental clinic"><input id="bl" placeholder="e.g. Manchester"><button class="btn" id="bgo">Search companies</button></div>
  <p class="hint">Adds public company websites as LOW intent. They only become worth contacting if the audit shows a real gap.</p></div>
  <h2>Latest leads</h2><div id="lt"></div><h2 style="margin-top:22px">Job queue</h2><div id="jt"></div>`;
  $('#drun').onclick = () => act(() => { const q = $('#dq').value.split('\n').map(x => x.trim()).filter(Boolean); return api('/api/discovery/run', {method:'POST', body: q.length ? {queries:q} : {}}); }, 'Discovery queued');
  $('#bgo').onclick = () => act(() => api('/api/discovery/businesses', {method:'POST', body:{category:$('#bc').value, location:$('#bl').value}}), 'Queued');
  $('#ml-go').onclick = () => act(() => api('/api/leads', {method:'POST', body:{url:$('#ml-u').value || null, text:$('#ml-t').value, company:$('#ml-c').value, website:$('#ml-w').value}}), 'Lead added and queued');
  $('#jrun').onclick = async function () { this.disabled = true; $('#jres').textContent = 'Running…'; const r = await act(() => api('/api/jobs/run', {method:'POST'}));
    this.disabled = false; if (r) { $('#jres').textContent = `Ran ${r.ran.length} job(s) in ${r.seconds}s; ${r.remaining_queued} still queued. ${r.ran.filter(x => x.error).map(x => x.error).join(' | ')}`; PAGES.find.reload && PAGES.find.reload(); } };
  const lt = dataTable($('#lt'), {resource:'leads', columns:leadCols, onRow:r => openLead(r.id), empty:'No leads yet. Queue a discovery run, or load sample data in Settings to explore.', pageSize:10});
  dataTable($('#jt'), {resource:'jobs', pageSize:8, columns:[{label:'#', key:'id'},{label:'Type', key:'type'},{label:'Status', render:r => badge(r.status)},{label:'Result', render:r => `<div class="clip">${esc(r.error || JSON.stringify(r.result || {}))}</div>`},{label:'Created', render:r => fmtDate(r.created_at)}]});
};

PAGES.intent = () => {
  main().innerHTML = header('Buying Intent Monitor', 'HIGH means the author explicitly asked for a service. Evidence quotes are verified against the source text; if a quote could not be found the lead is downgraded.') + '<div id="t"></div>';
  dataTable($('#t'), {resource:'leads', columns:leadCols, onRow:r => openLead(r.id), filters:[{key:'intent', label:'Intent', options:INTENTS, def:'HIGH'},{key:'status', label:'Status', options:LEAD_STATUS},{key:'service_needed', label:'Service', options:Object.keys(SERVICES)}]});
};

PAGES.companies = () => {
  main().innerHTML = header('Companies', 'Official websites are only recorded when they match the company name. Nothing is guessed.') + '<div id="t"></div>';
  dataTable($('#t'), {resource:'companies', columns:[{label:'Company', render:r => `<b>${esc(r.name)}</b>${sampleTag(r)}`},{label:'Website', render:r => link(r.website_url, r.domain)},{label:'Country', render:r => esc(r.country || 'not stated')},{label:'About', render:r => `<div class="clip">${esc(r.description || '')}</div>`},
    {label:'', render:r => `<button class="btn sm" data-a="${r.id}" data-u="${esc(r.website_url||'')}">Audit now</button>`}],
    after:(h) => h.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => { if (!b.dataset.u) return toast('No website on record', true); b.disabled = true; const a = await act(() => api('/api/audits/run', {method:'POST', body:{url:b.dataset.u, company_id:+b.dataset.a}}), 'Audit complete'); b.disabled = false; if (a) location.hash = 'audits'; })});
};

PAGES.linkedin = async () => {
  main().innerHTML = header('LinkedIn Prospects', 'Profiles come from public search results and are unverified. This app never logs in to or scrapes LinkedIn. You open the profile and send the message yourself after approving it.') + '<div id="t"></div>';
  const ms = {}; for (const ch of ['linkedin_connect','linkedin_message','linkedin_followup']) { const d = await api(`/api/data/messages?channel=${ch}&page_size=200&samples=all`).catch(() => ({rows:[]})); d.rows.forEach(m => (ms[m.contact_id] ||= {})[ch] = m); }
  dataTable($('#t'), {resource:'contacts', fixed:{has_linkedin:'1'}, columns:[{label:'Person', render:r => `<b>${esc(r.name || 'Unnamed')}</b>${sampleTag(r)}<br><span class="muted">${esc(r.title || '')}${r.is_decision_maker ? ' · decision-maker' : ''}</span>`},
    {label:'Public snippet', render:r => `<div class="clip">${esc(r.linkedin_note || '')}</div>`},
    {label:'Prepared messages', render:r => { const m = ms[r.id] || {}; return ['linkedin_connect','linkedin_message','linkedin_followup'].filter(c => m[c]).map(c => `<div class="row"><span>${c.replace('linkedin_','')}</span>${badge(m[c].status)}<button class="btn sm" data-copy="${m[c].id}">Copy</button>${m[c].status==='pending_approval'?`<button class="btn sm" data-ap="${m[c].id}">Approve</button>`:''}${m[c].status==='approved'?`<button class="btn sm" data-sent="${m[c].id}">Mark sent</button>`:''}</div>`).join('') || '<span class="muted">none</span>'; }},
    {label:'', render:r => link(r.linkedin_url, 'Open profile')}],
    after:(h, rows, reload) => { const byId = {}; Object.values(ms).forEach(o => Object.values(o).forEach(m => byId[m.id] = m));
      h.querySelectorAll('[data-copy]').forEach(b => b.onclick = () => copy(byId[b.dataset.copy].body));
      h.querySelectorAll('[data-ap]').forEach(b => b.onclick = async () => { if (await act(() => api(`/api/messages/${b.dataset.ap}/approve`, {method:'POST'}), 'Approved')) PAGES.linkedin(); });
      h.querySelectorAll('[data-sent]').forEach(b => b.onclick = async () => { if (await act(() => api(`/api/messages/${b.dataset.sent}/manual-sent`, {method:'POST'}), 'Marked as sent')) PAGES.linkedin(); }); }});
};

PAGES.emails = () => {
  main().innerHTML = header('Verified Emails', 'VERIFIED appears only when an email provider said so. Syntax and DNS checks alone leave an address UNKNOWN. Addresses are never guessed.') + '<div id="t"></div>';
  dataTable($('#t'), {resource:'contacts', fixed:{has_email:'1'}, filters:[{key:'email_status', label:'Status', options:['VERIFIED','RISKY','CATCH-ALL','UNKNOWN','INVALID']}],
    columns:[{label:'Email', render:r => `<b>${esc(r.email)}</b>${sampleTag(r)}<br><span class="muted">${esc(r.name || '')} ${esc(r.title || '')}</span>`},{label:'Status', render:r => badge(r.email_status)},
      {label:'How verified', render:r => esc((r.verification || {}).level || '')},{label:'Found via', render:r => `<div class="clip">${esc(r.email_source || '')}</div>`},
      {label:'', render:r => r.is_sample ? '' : `<button class="btn sm" data-v="${r.id}">Re-verify</button> <button class="btn sm danger" data-s="${esc(r.email)}">Suppress</button>`}],
    after:(h, rows, reload) => { h.querySelectorAll('[data-v]').forEach(b => b.onclick = async () => { if (await act(() => api(`/api/contacts/${b.dataset.v}/verify`, {method:'POST'}), 'Checked')) reload(); });
      h.querySelectorAll('[data-s]').forEach(b => b.onclick = async () => { if (await act(() => api('/api/suppressions', {method:'POST', body:{email:b.dataset.s, reason:'manual'}}), 'Added to suppression list')) reload(); }); }});
};

PAGES.audits = () => {
  main().innerHTML = header('Website Audits', 'Only issues observed in the fetched HTML are reported. Pages that disallow our crawler in robots.txt are skipped.') +
    `<div class="panel row"><input id="au" placeholder="Website to audit, e.g. example.com" style="min-width:280px"><button class="btn primary" id="ago">Run audit</button></div><div id="t"></div>`;
  $('#ago').onclick = async function () { this.disabled = true; const a = await act(() => api('/api/audits/run', {method:'POST', body:{url:$('#au').value}}), 'Audit complete'); this.disabled = false; if (a) PAGES.audits(); };
  dataTable($('#t'), {resource:'audits', columns:[{label:'Site', render:r => link(r.url) + sampleTag(r)},{label:'Reachable', render:r => badge(r.reachable ? 'ok' : 'error', r.reachable ? 'yes' : 'no')},{label:'Issues', render:r => (r.findings || []).length},{label:'Summary', render:r => `<div class="clip">${esc(r.summary || '')}</div>`},{label:'Date', render:r => fmtDate(r.created_at)}],
    onRow:r => { $('#dbody').innerHTML = `<h2 style="font:400 28px var(--display)">Audit</h2>${auditHtml(r)}`; $('#drawer').hidden = false; }});
};

PAGES.generator = async () => {
  const leads = (await api('/api/data/leads?page_size=200&samples=hide')).rows;
  main().innerHTML = header('AI Message Generator', 'Messages use only recorded facts. Pick a lead and a service to draft one. Nothing is sent from here; drafts go to the Approval Queue.') +
  `<div class="panel"><div class="grid g3"><div><label for="g-l">Lead</label><select id="g-l">${leads.map(l => `<option value="${l.id}">${esc((l.company_name || l.name || '#' + l.id) + ' · ' + l.intent)}</option>`).join('') || '<option value="">No leads yet</option>'}</select></div>
  <div><label for="g-s">Service</label><select id="g-s">${Object.entries(SERVICES).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select></div>
  <div><label for="g-c">Channel</label><select id="g-c"><option value="email">Email</option><option value="linkedin">LinkedIn (3 messages)</option></select></div></div>
  <div class="row" style="margin-top:12px"><button class="btn primary" id="g-go">Generate</button></div></div><div id="g-out"></div>`;
  const sel = leads.find(l => l.service_needed); if (sel) { $('#g-l').value = sel.id; $('#g-s').value = sel.service_needed in SERVICES ? sel.service_needed : 'website_development'; }
  $('#g-go').onclick = async function () { this.disabled = true; const r = await act(() => api('/api/messages/generate', {method:'POST', body:{lead_id:+$('#g-l').value, service:$('#g-s').value, channel:$('#g-c').value}})); this.disabled = false; if (!r) return;
    $('#g-out').innerHTML = r.messages.map(m => msgCard(m, true)).join(''); wireMsg($('#g-out')); };
};

function msgCard(m, gen) {
  const isEmail = m.channel === 'email';
  return `<div class="msg" data-id="${m.id}"><div class="row">${badge(m.status)} <b>${esc(m.channel)}</b> <span class="muted">${esc(SERVICES[m.service] || '')} · written by ${esc(m.generated_by || '?')}</span>${m.is_sample ? '<span class="badge b-sample">SAMPLE</span>' : ''}<span class="spacer"></span><span class="muted">${esc(m.to_email || '')}</span></div>
  ${isEmail ? `<label>Subject</label><input class="m-sub" value="${esc(m.subject || '')}" style="width:100%">` : ''}<label>Body</label><textarea class="m-body">${esc(m.body)}</textarea><div class="hint blk"></div>
  <div class="row" style="margin-top:8px"><button class="btn sm" data-x="edit">Save edit</button>
  ${m.status === 'draft' ? '<button class="btn sm primary" data-x="queue">Send to approval queue</button>' : ''}
  ${['pending_approval'].includes(m.status) ? '<button class="btn sm good" data-x="approve">Approve</button><button class="btn sm danger" data-x="reject">Reject</button>' : ''}
  ${m.status === 'approved' && isEmail ? '<button class="btn sm" data-x="draft">Save Gmail draft</button><button class="btn sm primary" data-x="send">Send now</button>' : ''}
  ${m.status === 'approved' && !isEmail ? '<button class="btn sm" data-x="copy">Copy</button><button class="btn sm primary" data-x="manual">Mark as sent (I sent it myself)</button>' : ''}
  <button class="btn sm ghost" data-x="copy">Copy text</button><button class="btn sm ghost" data-x="why">Check blockers</button></div></div>`;
}
function wireMsg(root, reload) {
  root.querySelectorAll('.msg').forEach(card => {
    const id = card.dataset.id;
    card.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
      const x = b.dataset.x, body = card.querySelector('.m-body').value, subject = card.querySelector('.m-sub')?.value;
      if (x === 'copy') return copy(body);
      if (x === 'why') { const r = await act(() => api(`/api/messages/preview-blockers/${id}`)); if (r) card.querySelector('.blk').textContent = r.blockers.length ? 'Blocked: ' + r.blockers.join('; ') : 'No blockers: this email can be sent.'; return; }
      const calls = {edit:['edit',{subject, body}, 'Saved (needs re-approval)'], queue:['queue',null,'Queued for approval'], approve:['approve',null,'Approved'], reject:['reject',null,'Rejected'], draft:['draft',null,'Saved as Gmail draft'], send:['send',null,'Sent'], manual:['manual-sent',null,'Marked as sent']}[x];
      if (x === 'send' && !confirm('Send this email now from your Gmail account?')) return;
      b.disabled = true; const r = await act(() => api(`/api/messages/${id}/${calls[0]}`, {method:'POST', body:calls[1] || undefined}), calls[2]); b.disabled = false;
      if (r) { reload ? reload() : (card.outerHTML = msgCard(r)); if (!reload) wireMsg(root); }
    });
  });
}

PAGES.approvals = async () => {
  main().innerHTML = header('Approval Queue', 'Nothing leaves the app until you approve it. Edits send a message back to pending so you always approve the exact text that is sent.') + `<div class="toolbar"><select id="as"><option value="pending_approval">Pending approval</option><option value="approved">Approved, not sent</option><option value="rejected">Rejected</option><option value="failed">Failed</option></select><select id="ach"><option value="">All channels</option><option>email</option><option>linkedin_connect</option><option>linkedin_message</option><option>linkedin_followup</option><option>public_reply</option></select></div><div id="list"></div>`;
  const load = async () => { const d = await api(`/api/data/messages?status=${$('#as').value}&channel=${$('#ach').value}&page_size=50`); $('#list').innerHTML = d.rows.length ? d.rows.map(m => msgCard(m)).join('') : '<div class="panel empty">Queue is empty.</div>'; wireMsg($('#list'), load); };
  $('#as').onchange = $('#ach').onchange = load; load();
};

PAGES.campaigns = async () => {
  const s = await api('/api/stats');
  main().innerHTML = header('Email Campaigns', 'Sent and scheduled email, follow-ups and limits. Duplicates, suppressed contacts and non-verified addresses are blocked automatically.') +
   `<div class="grid g3"><div class="panel stat"><b>${s.sent_today}/${s.daily_limit}</b><span>sent today / daily limit</span></div><div class="panel stat"><b>${s.funnel.sent}</b><span>emails sent in total</span></div><div class="panel stat"><b>${s.funnel.pending_approval}</b><span>waiting for approval</span></div></div>
   <div class="row" style="margin-bottom:12px"><button class="btn" id="fu">Create follow-up drafts now</button><span class="hint">Follow-ups are drafted for contacted leads with no reply after your configured wait, then need approval like everything else.</span></div><div id="t"></div>`;
  $('#fu').onclick = async () => { const r = await act(() => api('/api/sales-manager/run', {method:'POST'}), 'Sales Manager ran'); if (r) PAGES.campaigns(); };
  dataTable($('#t'), {resource:'messages', fixed:{channel:'email'}, filters:[{key:'status', label:'Status', options:['draft','pending_approval','approved','sent','failed','rejected']}],
    columns:[{label:'To', render:r => esc(r.to_email || '–') + sampleTag(r)},{label:'Subject', key:'subject'},{label:'Status', render:r => badge(r.status)},{label:'Step', render:r => r.sequence_no ? 'Follow-up ' + r.sequence_no : 'First email'},{label:'Sent', render:r => r.sent_at ? fmtDate(r.sent_at) : '–'},{label:'Error', render:r => `<span class="err">${esc(r.error || '')}</span>`}]});
};

PAGES.replies = () => {
  main().innerHTML = header('Replies', 'Only replies that match emails sent by this app are stored. Unsubscribes and bounces automatically add the address to the suppression list.') +
  `<div class="row" style="margin-bottom:12px"><button class="btn primary" id="sy">Sync Gmail now</button></div><div id="t"></div>`;
  $('#sy').onclick = async function () { this.disabled = true; const r = await act(() => api('/api/replies/sync', {method:'POST'}), 'Sync finished'); this.disabled = false; if (r) PAGES.replies(); };
  dataTable($('#t'), {resource:'replies', filters:[{key:'classification', label:'Type', options:['interested','question','not_interested','unsubscribe','bounce','out_of_office','other']}],
    columns:[{label:'Type', render:r => badge(r.classification)},{label:'From', key:'from_email'},{label:'Subject', key:'subject'},{label:'Snippet', render:r => `<div class="clip">${esc(r.snippet)}</div>`},{label:'Classified by', key:'method'},{label:'Received', render:r => fmtDate(r.received_at)}],
    onRow:r => openLead(r.lead_id)});
};

PAGES.pipeline = async () => {
  const d = await api('/api/data/leads?page_size=200&samples=hide'); const cols = ['new','qualified','contacted','replied','interested','meeting','converted','lost'];
  main().innerHTML = header('Sales Pipeline', 'Move prospects as conversations progress. Meetings and conversions are recorded by you.') +
   `<div class="kan">${cols.map(c => { const ls = d.rows.filter(l => l.status === c); return `<div class="col"><h3>${c}<span class="muted">${ls.length}</span></h3>${ls.map(l => `<div class="card" data-id="${l.id}"><b>${esc(l.company_name || l.name || '#' + l.id)}</b> ${badge(l.intent)}<div class="muted">${esc(SERVICES[l.service_needed] || '')} · score ${l.score ?? '–'}</div>
     <select data-m="${l.id}" aria-label="Move lead">${cols.map(x => `<option ${x===c?'selected':''}>${x}</option>`).join('')}</select> <button class="btn sm" data-o="${l.id}">Open</button></div>`).join('') || '<div class="muted" style="padding:8px">Empty</div>'}</div>`; }).join('')}</div>`;
  main().querySelectorAll('[data-m]').forEach(s => s.onchange = async () => { if (await act(() => api(`/api/leads/${s.dataset.m}/status`, {method:'POST', body:{status:s.value}}), 'Moved')) PAGES.pipeline(); });
  main().querySelectorAll('[data-o]').forEach(b => b.onclick = () => openLead(b.dataset.o));
};

PAGES.analytics = async () => {
  const s = await api('/api/stats');
  const bars = (title, obj) => { const e = Object.entries(obj).sort((a, b) => b[1] - a[1]); const m = Math.max(1, ...e.map(x => x[1]));
    return `<div class="panel"><h2>${title}</h2><div class="bars">${e.map(([k, v]) => `<div class="bar"><span>${esc(SERVICES[k] || k)}</span><div class="t"><i style="width:${v / m * 100}%"></i></div><b>${v}</b></div>`).join('') || '<span class="muted">No data yet</span>'}</div></div>`; };
  main().innerHTML = header('Analytics', 'Real data only. Sample rows are excluded.') + `<div class="grid g2">${bars('Leads by intent', s.by_intent)}${bars('Leads by service needed', s.by_service)}${bars('Leads by source', s.by_source)}${bars('Leads by country', s.by_country)}${bars('Leads by status', s.by_status)}</div>
  <div class="panel"><h2>Sales Manager report</h2>${s.report ? `<p class="muted">Generated ${fmtDate(s.report.generated_at)}</p>${s.report.recommendations.map(r => `<p>${esc(r)}</p>`).join('')}` : '<p class="muted">Not generated yet.</p>'}<button class="btn" id="smr">Run Sales Manager</button></div>
  <h2>Agent activity and errors</h2><div id="t"></div>`;
  $('#smr').onclick = async () => { if (await act(() => api('/api/sales-manager/run', {method:'POST'}), 'Done')) PAGES.analytics(); };
  dataTable($('#t'), {resource:'agent_runs', filters:[{key:'status', label:'Status', options:['ok','skipped','error']},{key:'agent', label:'Agent', options:['buying_intent','company_research','linkedin_research','email_finder','email_verification','website_audit','lead_scoring','personalized_message','discovery','reply_analysis','sales_manager']}],
    columns:[{label:'Agent', key:'agent'},{label:'Status', render:r => badge(r.status)},{label:'Lead', key:'lead_id'},{label:'Message', render:r => `<div class="clip">${esc(r.message)}</div>`},{label:'ms', key:'duration_ms'},{label:'When', render:r => fmtDate(r.created_at)}]});
};

PAGES.integrations = async () => {
  const d = await api('/api/integrations');
  main().innerHTML = header('API Integrations', 'Keys are set as environment variables (Vercel project settings or your local .env), never typed into this page or into chat. Each integration works independently; missing ones are shown as NOT CONNECTED and the app keeps working.') +
   (location.hash.includes('gmail=connected') ? '<div class="notice">Gmail connected.</div>' : location.hash.includes('gmail=error') ? '<div class="notice bad">Gmail authorization failed. Check the redirect URI and try again.</div>' : '') +
   `<div class="grid g2">${d.integrations.map(i => `<div class="panel"><div class="row"><h2 style="margin:0">${esc(i.name)}</h2><span class="spacer"></span>${badge(i.status)}</div>
   <p>${esc(i.purpose)}</p><p class="muted">${esc(i.why)}</p><dl class="kv"><dt>Required</dt><dd>${i.mandatory ? 'Yes' : 'Optional'}</dd><dt>Env variables</dt><dd>${i.env.concat(i.optional_env).map(v => `<code>${esc(v)}</code>`).join(' ') || 'none'}</dd>
   <dt>Free tier</dt><dd>${esc(i.free)}</dd><dt>Card needed</dt><dd>${esc(i.card)}</dd><dt>Cost</dt><dd>${esc(i.cost)}</dd></dl>
   ${i.note ? `<p class="${i.status==='ERROR'?'err':'hint'}">${esc(i.note)}</p>` : ''}<div class="row">${i.url ? `<a class="btn sm" href="${esc(i.url)}" target="_blank" rel="noopener noreferrer">Open sign-up page</a>` : ''}
   ${['anthropic','serper','tavily','brave','hunter','snov','zerobounce'].includes(i.key) && i.status !== 'NOT CONNECTED' ? `<button class="btn sm" data-t="${i.key}">Test connection</button>` : ''}
   ${i.key === 'gmail' && i.status === 'NEEDS CONFIGURATION' && !i.note.startsWith('Set') && !i.note.startsWith('Missing') ? '<button class="btn sm primary" id="gconn">Connect Gmail</button>' : ''}${i.key === 'gmail' && i.status === 'CONNECTED' ? '<button class="btn sm danger" id="gdis">Disconnect</button>' : ''}</div><p class="hint">${esc(i.setup)}</p></div>`).join('')}</div>`;
  main().querySelectorAll('[data-t]').forEach(b => b.onclick = async () => { b.disabled = true; const r = await act(() => api(`/api/integrations/${b.dataset.t}/test`, {method:'POST'})); b.disabled = false; if (r) { toast(r.message, !r.ok); PAGES.integrations(); } });
  const gc = $('#gconn'); if (gc) gc.onclick = async () => { const r = await act(() => api('/api/gmail/connect')); if (r) location.href = r.url; };
  const gd = $('#gdis'); if (gd) gd.onclick = async () => { if (await act(() => api('/api/gmail/disconnect', {method:'POST'}), 'Disconnected')) PAGES.integrations(); };
};

PAGES.settings = async () => {
  const s = await api('/api/settings');
  const inp = (k, l, h, t = 'text') => `<div class="field"><label for="s-${k}">${l}</label><input id="s-${k}" type="${t}" value="${esc(s[k])}">${h ? `<span class="hint">${h}</span>` : ''}</div>`;
  main().innerHTML = header('Settings', 'Sender identity, safety limits and search behaviour.') + `<div class="grid g2"><div class="panel"><h2>Sender identity</h2>${inp('sender_name','Your name')}${inp('sender_title','Your title')}${inp('business_name','Business name')}${inp('website_url','Website')}
   <div class="field"><label for="s-postal_address">Postal address</label><textarea id="s-postal_address" style="min-height:60px">${esc(s.postal_address)}</textarea><span class="hint">Required before sending. Many jurisdictions (e.g. CAN-SPAM) require a physical address and an opt-out in commercial email.</span></div></div>
   <div class="panel"><h2>Safety</h2><label><input type="checkbox" id="s-require_approval" ${s.require_approval ? 'checked' : ''}> Require approval before every send (recommended)</label>${inp('daily_send_limit','Daily email limit','Start low (10-20) with a new mailbox.','number')}
   <label for="s-allowed">Emails allowed to receive mail</label><select id="s-allowed"><option value="VERIFIED" ${s.allowed_email_statuses.length === 1 ? 'selected' : ''}>VERIFIED only (recommended)</option><option value="VERIFIED,CATCH-ALL" ${s.allowed_email_statuses.includes('CATCH-ALL') && !s.allowed_email_statuses.includes('UNKNOWN') ? 'selected' : ''}>VERIFIED + CATCH-ALL</option></select>
   ${inp('followup_days','Days before a follow-up draft','', 'number')}${inp('max_followups','Maximum follow-ups','', 'number')}</div>
   <div class="panel"><h2>Discovery</h2><div class="field"><label for="s-search_queries">Search phrases (one per line)</label><textarea id="s-search_queries">${esc(s.search_queries.join('\n'))}</textarea></div>
   ${inp('queries_per_run','Phrases per run','Smaller runs finish within serverless time limits.','number')}${inp('max_lead_age_days','Ignore posts older than (days)','', 'number')}
   <div class="field"><label for="s-rss_feeds">RSS feeds (one URL per line)</label><textarea id="s-rss_feeds" style="min-height:70px">${esc(s.rss_feeds.join('\n'))}</textarea></div>
   <div class="field"><label for="s-target_countries">Target countries (comma separated)</label><input id="s-target_countries" value="${esc(s.target_countries.join(', '))}"></div>
   <label><input type="checkbox" id="s-enable_hn" ${s.enable_hn ? 'checked' : ''}> Search Hacker News</label><label><input type="checkbox" id="s-auto_discovery_on_cron" ${s.auto_discovery_on_cron ? 'checked' : ''}> Run one discovery batch on the daily cron</label></div>
   <div class="panel"><h2>Suppression list</h2><div class="row"><input id="sp-e" placeholder="email or @domain"><button class="btn" id="sp-add">Add</button></div><div id="sp-t" style="margin-top:10px"></div>
   <h2 style="margin-top:22px">Sample data</h2><p class="hint">Clearly marked, never mixed into real numbers, never sendable.</p><div class="row"><button class="btn" id="sm-l">Load sample data</button><button class="btn danger" id="sm-c">Remove sample data</button></div></div></div>
   <div class="row end"><button class="btn primary" id="sv">Save settings</button></div>`;
  const lines = id => $(id).value.split('\n').map(x => x.trim()).filter(Boolean), num = id => +$(id).value;
  $('#sv').onclick = () => act(() => api('/api/settings', {method:'PUT', body:{sender_name:$('#s-sender_name').value, sender_title:$('#s-sender_title').value, business_name:$('#s-business_name').value, website_url:$('#s-website_url').value, postal_address:$('#s-postal_address').value,
    require_approval:$('#s-require_approval').checked, daily_send_limit:num('#s-daily_send_limit'), allowed_email_statuses:$('#s-allowed').value.split(','), followup_days:num('#s-followup_days'), max_followups:num('#s-max_followups'),
    search_queries:lines('#s-search_queries'), queries_per_run:num('#s-queries_per_run'), max_lead_age_days:num('#s-max_lead_age_days'), rss_feeds:lines('#s-rss_feeds'),
    target_countries:$('#s-target_countries').value.split(',').map(x => x.trim()).filter(Boolean), enable_hn:$('#s-enable_hn').checked, auto_discovery_on_cron:$('#s-auto_discovery_on_cron').checked}}), 'Settings saved');
  const sp = () => dataTable($('#sp-t'), {resource:'suppressions', pageSize:8, columns:[{label:'Suppressed', render:r => esc(r.email || '@' + r.domain)},{label:'Reason', key:'reason'},{label:'', render:r => `<button class="btn sm" data-d="${r.id}">Remove</button>`}],
    after:(h) => h.querySelectorAll('[data-d]').forEach(b => b.onclick = async () => { if (confirm('Remove from suppression list? Only do this if the person asked to hear from you again.')) { await act(() => api(`/api/suppressions/${b.dataset.d}`, {method:'DELETE'})); sp(); } })}); sp();
  $('#sp-add').onclick = async () => { const v = $('#sp-e').value.trim(); if (!v) return; await act(() => api('/api/suppressions', {method:'POST', body: v.startsWith('@') ? {domain:v.slice(1)} : {email:v}}), 'Added'); sp(); };
  $('#sm-l').onclick = () => act(() => api('/api/sample/load', {method:'POST'}), 'Sample data loaded (marked SAMPLE)');
  $('#sm-c').onclick = () => act(() => api('/api/sample/clear', {method:'POST'}), 'Sample data removed');
};

/* ---------- router ---------- */
function renderNav(cur) {
  $('#nav').innerHTML = NAV.map(([g, items]) => `<div class="grp">${g}</div>` + items.map(([k, l]) => `<a href="#${k}" ${k === cur ? 'aria-current="page"' : ''}>${l}</a>`).join('')).join('');
}
async function route() {
  const key = (location.hash.slice(1).split('?')[0]) || 'overview'; const fn = PAGES[key] || PAGES.overview;
  renderNav(PAGES[key] ? key : 'overview'); $('#side').classList.remove('open'); main().innerHTML = '<p class="muted">Loading…</p>';
  try { await fn(); } catch (e) { main().innerHTML = `<div class="notice bad">${esc(e.message)}</div>`; }
  main().focus({preventScroll:true});
}
$('#menu').onclick = () => $('#side').classList.toggle('open');
$('#logout').onclick = async () => { await fetch('/api/logout', {method:'POST', credentials:'same-origin'}); location.reload(); };
window.addEventListener('hashchange', route); route();
