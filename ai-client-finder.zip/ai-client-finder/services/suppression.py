from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from models.orm import Suppression


def domain_of(email: str) -> str:
    return email.rsplit("@", 1)[-1].lower()


def is_suppressed(db: Session, email: str) -> str | None:
    email = (email or "").lower().strip()
    if not email:
        return None
    row = db.execute(select(Suppression).where(Suppression.email == email)).scalar_one_or_none()
    if row:
        return f"address suppressed ({row.reason})"
    row = db.execute(select(Suppression).where(Suppression.domain == domain_of(email))).scalar_one_or_none()
    if row:
        return f"domain suppressed ({row.reason})"
    return None


def suppress(db: Session, *, email: str | None = None, domain: str | None = None, reason: str = "manual") -> Suppression:
    email = email.lower().strip() if email else None
    domain = domain.lower().strip() if domain else None
    q = select(Suppression).where(Suppression.email == email) if email else select(Suppression).where(Suppression.domain == domain)
    row = db.execute(q).scalar_one_or_none()
    if row:
        return row
    row = Suppression(email=email, domain=domain, reason=reason)
    db.add(row)
    db.flush()
    return row
