"""Encrypts OAuth tokens stored in the database with a key derived from SECRET_KEY."""
from __future__ import annotations

import base64
import hashlib

from cryptography.fernet import Fernet

from config import env


def _fernet() -> Fernet:
    secret = env("SECRET_KEY")
    if not secret:
        raise RuntimeError("SECRET_KEY is not set")
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest()))


def encrypt(text: str) -> str:
    return _fernet().encrypt(text.encode()).decode()


def decrypt(token: str) -> str:
    return _fernet().decrypt(token.encode()).decode()
