"""Clearly marked SAMPLE data. is_sample=True rows are hidden from real metrics and can never be emailed."""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from agents.discovery import dedupe_key
from models.orm import Audit, Company, Contact, Lead, Message, Reply, utcnow


def load(db: Session) -> int:
    if db.execute(select(Lead.id).where(Lead.is_sample.is_(True))).first():
        return 0
    rows = [
        ("Sample Alex", "SAMPLE Brightside Bakery", "HIGH", "website_redesign", "I need someone to redesign my bakery website, it looks outdated on phones.", 3, "VERIFIED"),
        ("Sample Priya", "SAMPLE Northwind Dental", "HIGH", "seo", "Looking for an SEO expert for my dental clinic.", 10, "UNKNOWN"),
        ("Sample Marco", "SAMPLE Atlas Logistics", "MEDIUM", "ai_automation", "We are expanding to two new cities and drowning in manual dispatch spreadsheets.", 25, "CATCH-ALL"),
        ("Sample Dana", "SAMPLE Willow Yoga", "LOW", "social_media", "Boutique studio with no visible social presence.", 60, "INVALID"),
    ]
    for i, (name, comp, intent, svc, text, age, est) in enumerate(rows):
        co = Company(name=comp, domain=f"sample{i}.example.test", website_url=f"https://sample{i}.example.test/", is_sample=True,
                     description="SAMPLE company, not a real business.", research={"summary": "SAMPLE DATA"})
        db.add(co)
        db.flush()
        lead = Lead(is_sample=True, dedupe_key=dedupe_key(f"https://example.test/sample/{i}"), source_type="sample",
                    source_url=f"https://example.test/sample/{i}", source_title="SAMPLE post", source_text=text,
                    source_date=utcnow() - timedelta(days=age), name=name, company_id=co.id, company_name=comp, country="Sampleland",
                    service_needed=svc, intent=intent, confidence=0.8 if intent == "HIGH" else 0.5, intent_method="sample",
                    evidence_quote=text, intent_reason="SAMPLE DATA", approach="SAMPLE: reply referencing the request.",
                    score=[88, 74, 52, 20][i], score_breakdown={"sample": 1}, stage="complete",
                    status=["qualified", "qualified", "contacted", "new"][i], meta={})
        db.add(lead)
        db.flush()
        c = Contact(lead_id=lead.id, company_id=co.id, name=name, title="Owner", is_decision_maker=True, is_sample=True,
                    email=f"owner@sample{i}.example.test", email_status=est, email_source="sample",
                    verification={"level": "sample data"}, linkedin_url=f"https://www.linkedin.com/in/sample-{i}")
        db.add(c)
        db.flush()
        db.add(Audit(company_id=co.id, lead_id=lead.id, url=co.website_url, reachable=True, status_code=200, load_ms=900, is_sample=True,
                     findings=[{"area": "mobile", "severity": "high", "observed": "SAMPLE: No viewport meta tag found.", "impact": "SAMPLE"}],
                     summary="SAMPLE audit. Not a real observation."))
        db.add(Message(lead_id=lead.id, contact_id=c.id, channel="email", service=svc, subject="SAMPLE subject",
                       body=f"Hi {name.split()[1]},\n\nSAMPLE message body.", status="pending_approval", generated_by="sample",
                       to_email=c.email, is_sample=True))
    db.flush()
    return len(rows)


def clear(db: Session) -> None:
    ids = [i for (i,) in db.execute(select(Lead.id).where(Lead.is_sample.is_(True)))]
    if ids:
        db.execute(delete(Reply).where(Reply.lead_id.in_(ids)))
        db.execute(delete(Message).where(Message.lead_id.in_(ids)))
        db.execute(delete(Audit).where(Audit.lead_id.in_(ids)))
        db.execute(delete(Contact).where(Contact.lead_id.in_(ids)))
        db.execute(delete(Lead).where(Lead.id.in_(ids)))
    db.execute(delete(Company).where(Company.is_sample.is_(True)))
    db.flush()
