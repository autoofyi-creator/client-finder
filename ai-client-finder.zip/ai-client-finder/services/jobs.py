"""Database-backed resumable job queue. Safe for serverless: every run is short and bounded by a time budget."""
from __future__ import annotations

import time
from typing import Callable

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from models.orm import Job, utcnow


def enqueue(db: Session, type_: str, payload: dict | None = None, run_after=None) -> Job:
    job = Job(type=type_, payload=payload or {}, run_after=run_after or utcnow())
    db.add(job)
    db.flush()
    return job


def claim_next(db: Session) -> Job | None:
    # recover jobs stuck 'running' (function was killed by the platform timeout)
    cutoff = utcnow().timestamp() - 600
    for j in db.execute(select(Job).where(Job.status == "running")).scalars():
        started = j.started_at.timestamp() if j.started_at else 0
        if started < cutoff:
            j.status = "queued"
    db.flush()
    cand = db.execute(select(Job).where(Job.status == "queued", Job.run_after <= utcnow()).order_by(Job.id).limit(1)).scalar_one_or_none()
    if not cand:
        return None
    res = db.execute(update(Job).where(Job.id == cand.id, Job.status == "queued").values(
        status="running", started_at=utcnow(), attempts=Job.attempts + 1))
    db.commit()
    if res.rowcount != 1:
        return None  # someone else claimed it
    db.refresh(cand)
    return cand


def run_queue(db: Session, handlers: dict[str, Callable[[Session, Job, float], dict]], budget_s: float) -> dict:
    """Run queued jobs until the time budget is nearly used. Handlers get the remaining budget."""
    start = time.monotonic()
    ran = []
    while time.monotonic() - start < budget_s - 3:
        job = claim_next(db)
        if not job:
            break
        remaining = budget_s - (time.monotonic() - start)
        try:
            handler = handlers[job.type]
            result = handler(db, job, remaining) or {}
            job.status = "done"
            job.result = result
            job.error = None
        except Exception as e:  # noqa: BLE001 - record, never crash the queue
            db.rollback()
            job = db.get(Job, job.id)
            job.status = "failed" if job.attempts >= 3 else "queued"
            job.error = f"{type(e).__name__}: {e}"[:2000]
            if job.status == "queued":
                job.run_after = utcnow()
        job.finished_at = utcnow()
        db.commit()
        ran.append({"id": job.id, "type": job.type, "status": job.status, "error": job.error})
    return {"ran": ran, "seconds": round(time.monotonic() - start, 1), "remaining_queued": db.execute(
        select(Job).where(Job.status == "queued")).scalars().all().__len__()}
