"""Local (non-provider) email checks. These can NEVER make an address VERIFIED on their own."""
from __future__ import annotations

import re

import dns.exception
import dns.resolver
from email_validator import EmailNotValidError, validate_email

from config import env

DISPOSABLE = {
    "mailinator.com", "10minutemail.com", "guerrillamail.com", "tempmail.com", "yopmail.com", "trashmail.com",
    "throwawaymail.com", "getnada.com", "sharklasers.com", "maildrop.cc", "dispostable.com", "fakeinbox.com",
    "temp-mail.org", "mintemail.com", "mailnesia.com", "emailondeck.com",
}
ROLE_LOCALS = {"info", "contact", "hello", "sales", "admin", "support", "office", "enquiries", "inquiries", "team", "mail"}
FREE_WEBMAIL = {"gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "icloud.com", "aol.com", "proton.me", "protonmail.com"}
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


def disposable_domains() -> set[str]:
    extra = {d.strip().lower() for d in env("EXTRA_DISPOSABLE_DOMAINS").split(",") if d.strip()}
    return DISPOSABLE | extra


def mx_lookup(domain: str) -> tuple[bool, list[str], str | None]:
    """Returns (has_mail_route, hosts, error). A/AAAA fallback per RFC 5321 implicit MX."""
    try:
        ans = dns.resolver.resolve(domain, "MX", lifetime=5)
        hosts = sorted(str(r.exchange).rstrip(".") for r in ans)
        if hosts == [""]:
            return False, [], "null MX (domain does not accept mail)"
        return True, hosts, None
    except dns.resolver.NoAnswer:
        try:
            dns.resolver.resolve(domain, "A", lifetime=5)
            return True, [domain], None
        except Exception:
            return False, [], "no MX or A record"
    except dns.resolver.NXDOMAIN:
        return False, [], "domain does not exist"
    except (dns.exception.DNSException, Exception) as e:  # timeouts etc. => unknown, not invalid
        return False, [], f"dns_error:{type(e).__name__}"


def local_check(email: str) -> dict:
    out = {"email": email, "syntax_ok": False, "dns_ok": None, "mx_hosts": [], "disposable": False,
           "role_account": False, "webmail": False, "notes": []}
    try:
        v = validate_email(email, check_deliverability=False)
    except EmailNotValidError as e:
        out["notes"].append(f"syntax: {e}")
        return out
    out["syntax_ok"] = True
    out["email"] = v.normalized.lower()
    local, domain = out["email"].rsplit("@", 1)
    out["disposable"] = domain in disposable_domains()
    out["role_account"] = local in ROLE_LOCALS
    out["webmail"] = domain in FREE_WEBMAIL
    ok, hosts, err = mx_lookup(domain)
    out["mx_hosts"] = hosts
    if err and err.startswith("dns_error"):
        out["dns_ok"] = None
        out["notes"].append("DNS lookup inconclusive")
    else:
        out["dns_ok"] = ok
        if err:
            out["notes"].append(err)
    return out


def extract_emails(text: str) -> list[str]:
    found = []
    for m in EMAIL_RE.findall(text or ""):
        m = m.strip(".").lower()
        if m.endswith((".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".css", ".js")):
            continue
        if m not in found:
            found.append(m)
    return found
