"""Single-admin authentication: signed session cookie, CSRF header, Bearer token for cron."""
from __future__ import annotations

import hmac
import time

from fastapi import HTTPException, Request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from config import env

COOKIE = "acf_session"
MAX_AGE = 60 * 60 * 12
_failures: dict[str, list[float]] = {}


def _serializer() -> URLSafeTimedSerializer:
    secret = env("SECRET_KEY")
    if len(secret) < 16:
        raise HTTPException(503, "NEEDS CONFIGURATION: SECRET_KEY must be set (16+ characters).")
    return URLSafeTimedSerializer(secret, salt="acf-session")


def auth_configured() -> bool:
    return bool(env("ADMIN_PASSWORD")) and len(env("SECRET_KEY")) >= 16


def check_password(candidate: str) -> bool:
    expected = env("ADMIN_PASSWORD")
    if not expected:
        return False
    return hmac.compare_digest(candidate.encode(), expected.encode())


def rate_limited(ip: str) -> bool:
    """Best-effort in-memory throttle (per warm instance): 8 failures / 10 minutes."""
    now = time.time()
    recent = [t for t in _failures.get(ip, []) if now - t < 600]
    _failures[ip] = recent
    return len(recent) >= 8


def record_failure(ip: str) -> None:
    _failures.setdefault(ip, []).append(time.time())


def make_session() -> str:
    return _serializer().dumps({"u": "admin"})


def session_valid(token: str | None) -> bool:
    if not token:
        return False
    try:
        _serializer().loads(token, max_age=MAX_AGE)
        return True
    except (BadSignature, SignatureExpired):
        return False


def require_auth(request: Request) -> None:
    """Dependency for all /api routes except login/health/cron."""
    if not auth_configured():
        raise HTTPException(503, "NEEDS CONFIGURATION: set ADMIN_PASSWORD and SECRET_KEY.")
    if not session_valid(request.cookies.get(COOKIE)):
        raise HTTPException(401, "Not authenticated")
    if request.method not in ("GET", "HEAD", "OPTIONS") and request.headers.get("x-csrf") != "1":
        raise HTTPException(403, "Missing CSRF header")


def require_cron(request: Request) -> None:
    secret = env("CRON_SECRET")
    if not secret:
        raise HTTPException(503, "NEEDS CONFIGURATION: CRON_SECRET is not set.")
    given = request.headers.get("authorization", "")
    if not hmac.compare_digest(given.encode(), f"Bearer {secret}".encode()):
        raise HTTPException(401, "Unauthorized")
