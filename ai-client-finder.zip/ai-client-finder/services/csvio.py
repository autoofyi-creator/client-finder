from __future__ import annotations

import csv
import io
import json


def _safe(v):
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        v = json.dumps(v, ensure_ascii=False)
    v = str(v)
    # CSV/Excel formula injection guard: untrusted web text must not execute when opened in a spreadsheet
    if v and v[0] in "=+-@\t\r":
        return "'" + v
    return v


def to_csv(rows: list[dict], columns: list[str]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(columns)
    for r in rows:
        w.writerow([_safe(r.get(c)) for c in columns])
    return buf.getvalue()
