from __future__ import annotations

from sqlalchemy.orm import Session

from config import DEFAULT_QUERIES, SERVICES
from models.orm import Setting

DEFAULTS: dict = {
    "require_approval": True,
    "daily_send_limit": 20,
    "allowed_email_statuses": ["VERIFIED"],
    "sender_name": "",
    "sender_title": "",
    "business_name": "",
    "postal_address": "",
    "website_url": "",
    "services_offered": list(SERVICES.keys()),
    "search_queries": DEFAULT_QUERIES,
    "target_countries": [],
    "min_intent_for_enrichment": "MEDIUM",
    "followup_days": 4,
    "max_followups": 2,
    "queries_per_run": 6,
    "rss_feeds": [],
    "enable_hn": True,
    "max_lead_age_days": 120,
    "auto_discovery_on_cron": False,
}
PUBLIC_KEYS = set(DEFAULTS)  # secrets never live here


def get(db: Session, key: str):
    row = db.get(Setting, key)
    if row is None or row.value is None:
        return DEFAULTS.get(key)
    return row.value


def set_value(db: Session, key: str, value) -> None:
    row = db.get(Setting, key)
    if row is None:
        db.add(Setting(key=key, value=value))
    else:
        row.value = value
    db.flush()


def all_public(db: Session) -> dict:
    return {k: get(db, k) for k in DEFAULTS}
