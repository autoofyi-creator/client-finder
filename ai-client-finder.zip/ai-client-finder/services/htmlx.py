"""HTML helpers built on BeautifulSoup."""
from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

CTA_RE = re.compile(r"\b(contact|get in touch|book|get a quote|free quote|request|schedule|call us|call now|enquir|inquir|buy now|shop now|get started|sign up|order now|talk to)", re.I)
CONTACT_LINK_RE = re.compile(r"(contact|about|team|people|leadership|get-in-touch|reach)", re.I)


def soup(html: str) -> BeautifulSoup:
    return BeautifulSoup(html or "", "html.parser")


def visible_text(s: BeautifulSoup, limit: int = 4000) -> str:
    for t in s(["script", "style", "noscript", "svg"]):
        t.decompose()
    return re.sub(r"\s+", " ", s.get_text(" ")).strip()[:limit]


def same_site_links(s: BeautifulSoup, base_url: str, pattern: re.Pattern = CONTACT_LINK_RE, limit: int = 3) -> list[str]:
    host = (urlparse(base_url).hostname or "").removeprefix("www.")
    out: list[str] = []
    for a in s.find_all("a", href=True):
        href = urljoin(base_url, a["href"])
        p = urlparse(href)
        if p.scheme not in ("http", "https") or (p.hostname or "").removeprefix("www.") != host:
            continue
        if pattern.search(p.path + " " + a.get_text(" ")) and href.split("#")[0] not in out and href.rstrip("/") != base_url.rstrip("/"):
            out.append(href.split("#")[0])
        if len(out) >= limit:
            break
    return out
