"""All outbound HTTP goes through here: one seam for tests, SSRF protection, robots.txt, size limits."""
from __future__ import annotations

import ipaddress
import socket
import time
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import httpx

UA = "AIClientFinderBot/1.0 (+business-research; respects robots.txt)"
_transport: Optional[httpx.BaseTransport] = None
_robots_cache: dict[str, Optional[RobotFileParser]] = {}


def set_transport(t: Optional[httpx.BaseTransport]) -> None:
    global _transport
    _transport = t
    _robots_cache.clear()


def client(timeout: float = 15.0) -> httpx.Client:
    return httpx.Client(timeout=timeout, headers={"User-Agent": UA}, transport=_transport, follow_redirects=False)


def resolve_ips(host: str) -> list[str]:
    try:
        return list({ai[4][0] for ai in socket.getaddrinfo(host, None)})
    except socket.gaierror:
        return []


def is_public_host(host: str) -> bool:
    if not host or host.lower() in ("localhost",):
        return False
    try:
        ips = [host] if ipaddress.ip_address(host) else []
    except ValueError:
        ips = resolve_ips(host)
    if not ips:
        return False
    for ip in ips:
        a = ipaddress.ip_address(ip)
        if a.is_private or a.is_loopback or a.is_link_local or a.is_reserved or a.is_multicast or a.is_unspecified:
            return False
    return True


@dataclass
class Fetch:
    url: str
    final_url: str = ""
    status: Optional[int] = None
    text: str = ""
    headers: dict | None = None
    elapsed_ms: Optional[int] = None
    error: Optional[str] = None
    blocked_by_robots: bool = False

    @property
    def ok(self) -> bool:
        return self.status is not None and 200 <= self.status < 300 and not self.error


def normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def allowed_by_robots(url: str) -> bool:
    p = urlparse(url)
    base = f"{p.scheme}://{p.netloc}"
    if base not in _robots_cache:
        rp: Optional[RobotFileParser] = RobotFileParser()
        try:
            with client(8) as c:
                r = c.get(base + "/robots.txt")
            if r.status_code in (401, 403):
                rp.parse(["User-agent: *", "Disallow: /"])
            elif r.status_code >= 400:
                rp = None  # no robots.txt => allowed
            else:
                rp.parse(r.text.splitlines())
        except Exception:
            rp = None
        _robots_cache[base] = rp
    rp = _robots_cache[base]
    return True if rp is None else rp.can_fetch(UA, url)


def safe_get(url: str, *, max_bytes: int = 1_500_000, max_redirects: int = 3, timeout: float = 12.0,
             respect_robots: bool = True) -> Fetch:
    """GET a public web page. Rejects non-http(s), private/loopback targets, oversize bodies; honours robots.txt."""
    url = normalize_url(url)
    res = Fetch(url=url)
    current = url
    start = time.perf_counter()
    try:
        with client(timeout) as c:
            for _ in range(max_redirects + 1):
                p = urlparse(current)
                if p.scheme not in ("http", "https") or not p.hostname:
                    res.error = "Blocked: unsupported URL"
                    return res
                if _transport is None and not is_public_host(p.hostname):
                    res.error = "Blocked: host is not a public internet address"
                    return res
                if respect_robots and not allowed_by_robots(current):
                    res.error = "Skipped: disallowed by robots.txt"
                    res.blocked_by_robots = True
                    return res
                r = c.get(current)
                if r.status_code in (301, 302, 303, 307, 308) and r.headers.get("location"):
                    current = urljoin(current, r.headers["location"])
                    continue
                res.status = r.status_code
                res.final_url = current
                res.headers = dict(r.headers)
                body = r.content[:max_bytes]
                res.text = body.decode(r.encoding or "utf-8", errors="replace")
                break
            else:
                res.error = "Too many redirects"
    except httpx.TimeoutException:
        res.error = "Timed out"
    except httpx.HTTPError as e:
        res.error = f"Request failed: {type(e).__name__}"
    res.elapsed_ms = int((time.perf_counter() - start) * 1000)
    return res
